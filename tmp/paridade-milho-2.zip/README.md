
  # Cálculo de Paridade Milho

  This is a code bundle for Cálculo de Paridade Milho. The original project is available at https://www.figma.com/design/AFCtjBOtd8MbQljk6p1oAt/C%C3%A1lculo-de-Paridade-Milho.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  