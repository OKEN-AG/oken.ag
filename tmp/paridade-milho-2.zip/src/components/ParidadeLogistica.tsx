import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Loader2, TrendingUp, Calculator, Settings, AlertTriangle, MapPin, Truck, Database } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import okenLogo from 'figma:asset/42abbaa2373dc0a620697ab3c75eb6a7a6b3f682.png';
import { ESTADOS, getCidadesByUF, getArmazensByCidade, getArmazemByCDA, PORTOS, getPortoById, type Armazem, type Porto } from '../data/armazens';
import { GerenciadorArmazens } from './GerenciadorArmazens';
import { GerenciadorCommodities, type CommodityConfig } from './GerenciadorCommodities';
import { COMMODITIES_DEFAULT } from '../data/commodities';

interface ParidadeResult {
  commodity_usd_bu: number;
  cambio_usd_brl: number;
  paridade_porto_r_ton: number;
  preco_interior_r_ton: number;
  preco_produtor_r_saca: number;
}

interface MemoriaCalculo {
  commodity_nome: string;
  commodity_usd_bu: number;
  cambio_usd_brl: number;
  frete_r_ton: number;
  premio_cents: number;
  bushels_per_ton: number;
  sacas_per_ton: number;
  peso_saca_kg: number;
  commodity_usd_ton: number;
  premio_usd_ton: number;
  fob_usd_ton: number;
  paridade_porto_r_ton: number;
  preco_interior_r_ton: number;
  preco_produtor_r_saca: number;
  distancia_km?: number;
  frete_km?: number;
  origem?: string;
  destino?: string;
  porto_nome?: string;
  duracao_horas?: number;
}

export function ParidadeLogistica() {
  // Estados de commodities (carregadas do backend)
  const [todasCommodities, setTodasCommodities] = useState<CommodityConfig[]>(COMMODITIES_DEFAULT);
  const [loadingCommodities, setLoadingCommodities] = useState(true);
  const [commoditySelecionada, setCommoditySelecionada] = useState<string>('');
  const [config, setConfig] = useState<CommodityConfig | null>(null);
  
  // Estados de armazéns (carregados do backend)
  const [todosArmazens, setTodosArmazens] = useState<Armazem[]>([]);
  const [loadingArmazens, setLoadingArmazens] = useState(true);
  
  // Estados da logística
  const [ufSelecionada, setUfSelecionada] = useState<string>('');
  const [cidadeSelecionada, setCidadeSelecionada] = useState<string>('');
  const [armazemSelecionado, setArmazemSelecionado] = useState<string>('');
  const [portoSelecionado, setPortoSelecionado] = useState<string>('');
  const [custoPorKm, setCustoPorKm] = useState<string>('');
  const [premioCents, setPremioCents] = useState<string>('');
  
  // Estados para "Outro município"
  const [modoMunicipioManual, setModoMunicipioManual] = useState(false);
  const [municipioManual, setMunicipioManual] = useState<string>('');
  const [latitudeManual, setLatitudeManual] = useState<string>('');
  const [longitudeManual, setLongitudeManual] = useState<string>('');
  
  // Estados derivados
  const [cidades, setCidades] = useState<string[]>([]);
  const [armazensDisponiveis, setArmazensDisponiveis] = useState<Armazem[]>([]);
  const [distanciaKm, setDistanciaKm] = useState<number | null>(null);
  const [freteTotal, setFreteTotal] = useState<number | null>(null);
  const [calculandoDistancia, setCalculandoDistancia] = useState(false);
  const [avisoDistancia, setAvisoDistancia] = useState<string | null>(null);
  const [metodoCalculo, setMetodoCalculo] = useState<string | null>(null);
  const [duracaoHoras, setDuracaoHoras] = useState<number | null>(null);
  
  // Estados do resultado
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ParidadeResult | null>(null);
  const [memoriaCalculo, setMemoriaCalculo] = useState<MemoriaCalculo | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Carregar armazéns do backend ao iniciar
  useEffect(() => {
    carregarArmazens();
    carregarCommodities();
  }, []);

  const carregarArmazens = async () => {
    setLoadingArmazens(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-d467efec/armazens`,
        {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error('Erro ao carregar armazéns');
      }

      const data = await response.json();
      console.log('Armazéns carregados:', data.armazens.length);
      setTodosArmazens(data.armazens || []);
    } catch (err) {
      console.error('Erro ao carregar armazéns:', err);
      setTodosArmazens([]);
    } finally {
      setLoadingArmazens(false);
    }
  };

  const carregarCommodities = async () => {
    setLoadingCommodities(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-d467efec/commodities`,
        {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error('Erro ao carregar commodities');
      }

      const data = await response.json();
      console.log('Commodities carregadas:', data.commodities.length);
      if (data.commodities && data.commodities.length > 0) {
        setTodasCommodities(data.commodities);
      }
    } catch (err) {
      console.error('Erro ao carregar commodities:', err);
      // Mantém o padrão se falhar
    } finally {
      setLoadingCommodities(false);
    }
  };

  // Atualizar cidades quando UF mudar
  useEffect(() => {
    if (ufSelecionada) {
      const cidadesUF = getCidadesByUF(todosArmazens, ufSelecionada);
      setCidades(cidadesUF);
      setCidadeSelecionada('');
      setArmazemSelecionado('');
      setArmazensDisponiveis([]);
    }
  }, [ufSelecionada, todosArmazens]);

  // Atualizar armazéns quando cidade mudar
  useEffect(() => {
    if (ufSelecionada && cidadeSelecionada) {
      const armazensCidade = getArmazensByCidade(todosArmazens, ufSelecionada, cidadeSelecionada);
      
      // Ordenar por capacidade (decrescente) e pegar TOP 5
      const top5Armazens = armazensCidade
        .sort((a, b) => {
          const capacidadeA = parseFloat(a.capacidade_ton) || 0;
          const capacidadeB = parseFloat(b.capacidade_ton) || 0;
          return capacidadeB - capacidadeA;
        })
        .slice(0, 5);
      
      setArmazensDisponiveis(top5Armazens);
      setArmazemSelecionado('');
    }
  }, [ufSelecionada, cidadeSelecionada, todosArmazens]);

  // Calcular distância quando armazém e porto forem selecionados
  useEffect(() => {
    if (armazemSelecionado && portoSelecionado) {
      calcularDistancia();
    } else {
      setDistanciaKm(null);
      setFreteTotal(null);
    }
  }, [armazemSelecionado, portoSelecionado]);

  // Atualizar frete total quando distância ou custo/km mudarem
  useEffect(() => {
    if (distanciaKm !== null && custoPorKm) {
      const custo = parseFloat(custoPorKm);
      if (!isNaN(custo)) {
        setFreteTotal(distanciaKm * custo);
      }
    }
  }, [distanciaKm, custoPorKm]);

  const calcularDistancia = async () => {
    const armazem = getArmazemByCDA(todosArmazens, armazemSelecionado);
    const porto = getPortoById(portoSelecionado);

    if (!armazem || !porto) {
      return;
    }

    setCalculandoDistancia(true);
    setError(null);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-d467efec/calcular-distancia`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({
            origem_lat: armazem.latitude,
            origem_lng: armazem.longitude,
            destino_lat: porto.lat,
            destino_lng: porto.lng,
          }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Erro ao calcular distância:', errorData);
        throw new Error(errorData.error || 'Erro ao calcular distância');
      }

      const data = await response.json();
      console.log('Distância calculada:', data);
      setDistanciaKm(data.distancia_km);
      
      if (data.aviso) {
        console.warn(data.aviso);
        setAvisoDistancia(data.aviso);
      }

      setMetodoCalculo(data.metodo);
      setDuracaoHoras(data.duracao_horas);
    } catch (err) {
      console.error('Erro ao calcular distância:', err);
      setError(
        err instanceof Error
          ? err.message
          : 'Erro ao calcular distância. Tente novamente.'
      );
    } finally {
      setCalculandoDistancia(false);
    }
  };

  const handleCommodityChange = (commodity: string) => {
    setCommoditySelecionada(commodity);
    setConfig(todasCommodities.find(c => c.id === commodity) || null);
    setResult(null);
    setMemoriaCalculo(null);
    setError(null);
  };

  const handleConfigChange = (field: keyof CommodityConfig, value: string | number) => {
    setConfig(prev => ({ ...prev, [field]: value }));
  };

  const handleCalcular = async () => {
    setError(null);
    setResult(null);
    setMemoriaCalculo(null);

    console.log('=== INICIANDO CÁLCULO DE PARIDADE ===');
    console.log('Commodity selecionada:', commoditySelecionada);
    console.log('Config atual:', config);
    console.log('Frete total:', freteTotal);
    console.log('Prêmio:', premioCents);

    // Validações
    if (!ufSelecionada || !cidadeSelecionada || !armazemSelecionado || !portoSelecionado) {
      setError('Por favor, complete todos os campos de logística (origem e destino).');
      return;
    }

    if (!custoPorKm || !premioCents) {
      setError('Por favor, preencha o custo por km e o prêmio.');
      return;
    }

    if (freteTotal === null) {
      setError('Aguarde o cálculo da distância.');
      return;
    }

    if (!config) {
      setError('Por favor, selecione uma commodity.');
      return;
    }

    const premio = parseFloat(premioCents);
    if (isNaN(premio)) {
      setError('Por favor, insira um valor numérico válido para o prêmio.');
      return;
    }

    console.log('Validações passaram, enviando requisição...');
    console.log('Fonte da commodity:', config.fonte);
    console.log('Payload:', {
      frete_r_ton: freteTotal,
      premio_cents: premio,
      ticker: config.ticker,
      ticker_b3: config.ticker_b3,
      bushels_per_ton: config.bushels_per_ton,
      peso_saca_kg: config.peso_saca_kg,
    });

    setLoading(true);

    try {
      let response;
      
      // Detectar qual endpoint usar baseado na fonte
      if (config.fonte === 'b3') {
        // Endpoint B3
        console.log('Usando endpoint B3...');
        response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-d467efec/futuros-b3-multiplos`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${publicAnonKey}`,
            },
            body: JSON.stringify({
              contrato: config.ticker_b3,  // Corrigido: contrato singular
              frete_r_ton: freteTotal,
              premio_r_ton: premio,
            }),
          }
        );
      } else {
        // Endpoint Yahoo Finance
        console.log('Usando endpoint Yahoo Finance...');
        response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-d467efec/paridade-milho-yahoo`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${publicAnonKey}`,
            },
            body: JSON.stringify({
              frete_r_ton: freteTotal,
              premio_cents: premio,
              ticker: config.ticker,
              bushels_per_ton: config.bushels_per_ton,
              peso_saca_kg: config.peso_saca_kg,
            }),
          }
        );
      }

      console.log('Resposta recebida, status:', response.status);

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Erro na resposta da API:', errorData);
        throw new Error(errorData.error || 'Erro ao calcular paridade');
      }

      const data = await response.json();
      console.log('Resultado da paridade:', data);
      
      // Processar resultado baseado na fonte
      if (config.fonte === 'b3') {
        // Resposta da B3 vem em formato diferente
        console.log('Resultado B3:', data);
        
        // Usar valores já calculados pelo backend
        const preco_base_r_saca = data.preco_b3_r_saca;
        const preco_base_r_ton = data.preco_b3_r_ton;
        const preco_interior_r_ton = data.preco_final_r_ton;
        const preco_produtor_r_saca = data.preco_final_r_saca;
        const SACAS_PER_TON = 1000 / config.peso_saca_kg;
        
        setResult({
          commodity_usd_bu: 0, // B3 não usa USD/bu
          cambio_usd_brl: 0, // B3 não usa câmbio
          paridade_porto_r_ton: preco_base_r_ton,
          preco_interior_r_ton: preco_interior_r_ton,
          preco_produtor_r_saca: preco_produtor_r_saca,
        });
        
        const armazem = getArmazemByCDA(todosArmazens, armazemSelecionado);
        const porto = getPortoById(portoSelecionado);
        
        console.log('=== MEMÓRIA B3 DEBUG ===');
        console.log('armazemSelecionado:', armazemSelecionado);
        console.log('portoSelecionado:', portoSelecionado);
        console.log('Armazem encontrado:', armazem);
        console.log('Porto encontrado:', porto);
        console.log('UF:', ufSelecionada, 'Cidade:', cidadeSelecionada);
        console.log('Modo manual:', modoMunicipioManual, 'Município:', municipioManual);
        
        // Determinar origem (armazém ou município manual)
        let origemTexto = 'Origem não especificada';
        if (armazem) {
          origemTexto = `${armazem.armazenador} - ${armazem.municipio}/${armazem.uf}`;
        } else if (modoMunicipioManual && municipioManual) {
          origemTexto = `${municipioManual} (manual)`;
        } else if (cidadeSelecionada && ufSelecionada) {
          origemTexto = `${cidadeSelecionada}/${ufSelecionada}`;
        }
        
        // Determinar destino (porto ou base)
        let destinoTexto = 'Destino não especificado';
        if (porto) {
          destinoTexto = `${porto.nome}`;
        }
        
        console.log('Origem final:', origemTexto);
        console.log('Destino final:', destinoTexto);
        
        setMemoriaCalculo({
          commodity_nome: config.nome,
          commodity_usd_bu: 0,
          cambio_usd_brl: 0,
          frete_r_ton: freteTotal,
          premio_cents: 0, // B3 não usa prêmio
          bushels_per_ton: 0,
          sacas_per_ton: SACAS_PER_TON,
          peso_saca_kg: config.peso_saca_kg,
          commodity_usd_ton: 0,
          premio_usd_ton: 0,
          fob_usd_ton: 0,
          paridade_porto_r_ton: preco_base_r_ton,
          preco_interior_r_ton: preco_interior_r_ton,
          preco_produtor_r_saca: preco_produtor_r_saca,
          distancia_km: distanciaKm ?? 0,
          frete_km: custoPorKm ? parseFloat(custoPorKm) : 0,
          origem: origemTexto,
          destino: destinoTexto,
          porto_nome: porto?.nome || 'Base de entrega',
          duracao_horas: duracaoHoras ?? 0,
        });
      } else {
        // Resposta do Yahoo Finance (original)
        setResult(data);

        const BUSHELS_PER_TON = config.bushels_per_ton;
        const SACAS_PER_TON = 1000 / config.peso_saca_kg;
        
        const commodity_usd_ton = data.commodity_usd_bu * BUSHELS_PER_TON;
        const premio_usd_ton = (premio / 100) * BUSHELS_PER_TON;
        const fob_usd_ton = commodity_usd_ton + premio_usd_ton;

        const armazem = getArmazemByCDA(todosArmazens, armazemSelecionado);
        const porto = getPortoById(portoSelecionado);
        
        console.log('=== MEMÓRIA YAHOO DEBUG ===');
        console.log('armazemSelecionado:', armazemSelecionado);
        console.log('portoSelecionado:', portoSelecionado);
        console.log('Armazem encontrado:', armazem);
        console.log('Porto encontrado:', porto);
        console.log('UF:', ufSelecionada, 'Cidade:', cidadeSelecionada);
        console.log('Modo manual:', modoMunicipioManual, 'Município:', municipioManual);
        
        // Determinar origem (armazém ou município manual)
        let origemTexto = 'Origem não especificada';
        if (armazem) {
          origemTexto = `${armazem.armazenador} - ${armazem.municipio}/${armazem.uf}`;
        } else if (modoMunicipioManual && municipioManual) {
          origemTexto = `${municipioManual} (manual)`;
        } else if (cidadeSelecionada && ufSelecionada) {
          origemTexto = `${cidadeSelecionada}/${ufSelecionada}`;
        }
        
        // Determinar destino (porto ou base)
        let destinoTexto = 'Destino não especificado';
        if (porto) {
          destinoTexto = `${porto.nome}`;
        }
        
        console.log('Origem final:', origemTexto);
        console.log('Destino final:', destinoTexto);
        
        setMemoriaCalculo({
          commodity_nome: config.nome,
          commodity_usd_bu: data.commodity_usd_bu,
          cambio_usd_brl: data.cambio_usd_brl,
          frete_r_ton: freteTotal,
          premio_cents: premio,
          bushels_per_ton: BUSHELS_PER_TON,
          sacas_per_ton: SACAS_PER_TON,
          peso_saca_kg: config.peso_saca_kg,
          commodity_usd_ton,
          premio_usd_ton,
          fob_usd_ton,
          paridade_porto_r_ton: data.paridade_porto_r_ton,
          preco_interior_r_ton: data.preco_interior_r_ton,
          preco_produtor_r_saca: data.preco_produtor_r_saca,
          distancia_km: distanciaKm ?? 0,
          frete_km: custoPorKm ? parseFloat(custoPorKm) : 0,
          origem: origemTexto,
          destino: destinoTexto,
          porto_nome: porto?.nome || 'Porto de exportação',
          duracao_horas: duracaoHoras ?? 0,
        });
      }

      console.log('=== CÁLCULO CONCLUÍDO COM SUCESSO ===');
    } catch (err) {
      console.error('=== ERRO AO CALCULAR PARIDADE ===');
      console.error('Erro completo:', err);
      setError(
        err instanceof Error
          ? err.message
          : 'Erro ao conectar com o servidor. Tente novamente.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f5f6f8]">
      {/* Header Oken */}
      <div className="bg-gradient-to-r from-[#1a2332] to-[#2c3e50] shadow-lg">
        <div className="max-w-7xl mx-auto px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-semibold text-white tracking-tight">
                Calculadora de Paridade de Exportação
              </h1>
              <p className="text-[#4ecdc4] text-sm font-medium mt-1 tracking-wide">
                COMMODITIES AGRÍCOLAS · LOGÍSTICA INTEGRADA · TEMPO REAL
              </p>
            </div>
            <img 
              src={okenLogo} 
              alt="Oken" 
              className="h-14 w-auto ml-8"
            />
          </div>
        </div>
      </div>

      {/* Conteúdo Principal */}
      <div className="max-w-7xl mx-auto px-8 py-10">
        <Tabs defaultValue="calculo" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8 bg-white border-2 border-[#e0e4e8] p-1 h-auto">
            <TabsTrigger 
              value="calculo" 
              className="flex items-center gap-2 py-3 px-6 text-[#6b7280] data-[state=active]:bg-[#4ecdc4] data-[state=active]:text-white data-[state=active]:shadow-md transition-all"
            >
              <Calculator className="w-5 h-5" />
              <span className="font-semibold text-sm uppercase tracking-wide">Cálculo</span>
            </TabsTrigger>
            <TabsTrigger 
              value="parametros" 
              className="flex items-center gap-2 py-3 px-6 text-[#6b7280] data-[state=active]:bg-[#4ecdc4] data-[state=active]:text-white data-[state=active]:shadow-md transition-all"
            >
              <Settings className="w-5 h-5" />
              <span className="font-semibold text-sm uppercase tracking-wide">Parâmetros</span>
            </TabsTrigger>
            <TabsTrigger 
              value="resultados" 
              className="flex items-center gap-2 py-3 px-6 text-[#6b7280] data-[state=active]:bg-[#4ecdc4] data-[state=active]:text-white data-[state=active]:shadow-md transition-all"
            >
              <TrendingUp className="w-5 h-5" />
              <span className="font-semibold text-sm uppercase tracking-wide">Memória</span>
            </TabsTrigger>
          </TabsList>

          {/* ABA: CÁLCULO (COM LOGÍSTICA INTEGRADA) */}
          <TabsContent value="calculo">
            <div className="space-y-6">
              {/* SEÇÃO 1: LOGÍSTICA */}
              <Card className="border-2 border-[#4ecdc4] shadow-lg">
                <CardHeader className="bg-gradient-to-r from-[#4ecdc4] to-[#5dd9c1] text-white rounded-t-lg">
                  <CardTitle className="flex items-center gap-2 text-xl">
                    <Truck className="w-6 h-6" />
                    Etapa 1: Logística e Roteamento
                  </CardTitle>
                  <CardDescription className="text-white text-opacity-90">
                    Defina a origem (armazém), destino (porto) e custo de frete
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid lg:grid-cols-2 gap-6">
                    {/* Origem */}
                    <div className="space-y-5 p-5 bg-[#f5f6f8] rounded-lg border-2 border-[#e0e4e8]">
                      <div className="flex items-center gap-2 mb-3">
                        <MapPin className="w-5 h-5 text-[#4ecdc4]" />
                        <h3 className="text-[#1a2332] font-bold text-lg">Origem - Armazém</h3>
                      </div>

                      {loadingArmazens ? (
                        <div className="flex items-center justify-center p-8">
                          <Loader2 className="w-8 h-8 animate-spin text-[#4ecdc4]" />
                        </div>
                      ) : todosArmazens.length === 0 ? (
                        <div className="bg-yellow-50 border-2 border-yellow-500 rounded-lg p-4 text-center">
                          <p className="text-yellow-800 text-sm font-medium">
                            Nenhum armazém cadastrado. Vá para a aba "Armazéns" para importar.
                          </p>
                        </div>
                      ) : (
                        <>
                          <div className="space-y-2">
                            <Label className="text-[#1a2332] font-semibold text-xs uppercase tracking-wide">
                              Estado (UF)
                            </Label>
                            <Select value={ufSelecionada} onValueChange={setUfSelecionada}>
                              <SelectTrigger className="h-11 border-2 border-[#e0e4e8] bg-white">
                                <SelectValue placeholder="Selecione o estado" />
                              </SelectTrigger>
                              <SelectContent>
                                {ESTADOS.map(estado => (
                                  <SelectItem key={estado.uf} value={estado.uf}>
                                    {estado.nome} ({estado.uf})
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label className="text-[#1a2332] font-semibold text-xs uppercase tracking-wide">
                              Município
                            </Label>
                            <Select 
                              value={cidadeSelecionada} 
                              onValueChange={(value) => {
                                if (value === '🔧 Outro município (informar manualmente)') {
                                  setModoMunicipioManual(true);
                                  setCidadeSelecionada(value);
                                  setArmazensDisponiveis([]);
                                } else {
                                  setModoMunicipioManual(false);
                                  setCidadeSelecionada(value);
                                }
                              }}
                              disabled={!ufSelecionada}
                            >
                              <SelectTrigger className="h-11 border-2 border-[#e0e4e8] bg-white">
                                <SelectValue placeholder="Selecione a cidade" />
                              </SelectTrigger>
                              <SelectContent>
                                {cidades.map(cidade => (
                                  <SelectItem key={cidade} value={cidade}>
                                    {cidade}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            {!modoMunicipioManual && cidadeSelecionada && cidadeSelecionada !== '🔧 Outro município (informar manualmente)' && (
                              <p className="text-[#6b7280] text-xs">
                                Município produtor cadastrado
                              </p>
                            )}
                          </div>

                          {modoMunicipioManual && (
                            <div className="bg-[#4ecdc4] bg-opacity-10 border-2 border-[#4ecdc4] rounded-lg p-4 space-y-3">
                              <p className="text-[#1a2332] font-bold text-sm mb-2">
                                📍 Informações do Município
                              </p>
                              <div className="space-y-2">
                                <Label className="text-[#1a2332] font-semibold text-xs">Nome do Município</Label>
                                <Input
                                  value={municipioManual}
                                  onChange={(e) => setMunicipioManual(e.target.value)}
                                  placeholder="Ex: Nova Cidade"
                                  className="h-10 border-2 border-[#e0e4e8] bg-white"
                                />
                              </div>
                              <div className="grid grid-cols-2 gap-3">
                                <div className="space-y-2">
                                  <Label className="text-[#1a2332] font-semibold text-xs">Latitude</Label>
                                  <Input
                                    type="number"
                                    step="0.000001"
                                    value={latitudeManual}
                                    onChange={(e) => setLatitudeManual(e.target.value)}
                                    placeholder="-15.7942"
                                    className="h-10 border-2 border-[#e0e4e8] bg-white font-mono text-sm"
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label className="text-[#1a2332] font-semibold text-xs">Longitude</Label>
                                  <Input
                                    type="number"
                                    step="0.000001"
                                    value={longitudeManual}
                                    onChange={(e) => setLongitudeManual(e.target.value)}
                                    placeholder="-47.8822"
                                    className="h-10 border-2 border-[#e0e4e8] bg-white font-mono text-sm"
                                  />
                                </div>
                              </div>
                              <p className="text-[#6b7280] text-xs italic">
                                💡 Use o Google Maps para obter as coordenadas: clique com botão direito no mapa → "Copiar coordenadas"
                              </p>
                            </div>
                          )}

                          {!modoMunicipioManual && cidadeSelecionada && cidadeSelecionada !== '🔧 Outro município (informar manualmente)' && (
                            <div className="space-y-2">
                              <Label className="text-[#1a2332] font-semibold text-xs uppercase tracking-wide">
                                Armazém
                              </Label>
                              <Select 
                                value={armazemSelecionado} 
                                onValueChange={setArmazemSelecionado}
                                disabled={!cidadeSelecionada}
                              >
                                <SelectTrigger className="h-11 border-2 border-[#e0e4e8] bg-white">
                                  <SelectValue placeholder="Selecione o armazém" />
                                </SelectTrigger>
                                <SelectContent>
                                  {armazensDisponiveis.map(arm => (
                                    <SelectItem key={arm.cda} value={arm.cda}>
                                      {arm.armazenador} - {arm.endereco}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              {armazensDisponiveis.length > 0 && (
                                <p className="text-[#6b7280] text-xs">
                                  Exibindo TOP {armazensDisponiveis.length} por capacidade
                                </p>
                              )}
                              {armazensDisponiveis.length === 0 && (
                                <p className="text-yellow-700 text-xs bg-yellow-50 border border-yellow-500 rounded p-2">
                                  ⚠️ Nenhum armazém cadastrado neste município. Selecione "Outro município" e informe coordenadas manualmente.
                                </p>
                              )}
                            </div>
                          )}

                          {armazemSelecionado && (
                            <div className="bg-[#4ecdc4] bg-opacity-10 border border-[#4ecdc4] rounded-lg p-3">
                              {(() => {
                                const arm = getArmazemByCDA(todosArmazens, armazemSelecionado);
                                return arm ? (
                                  <div className="space-y-1">
                                    <p className="text-[#1a2332] font-bold text-sm">{arm.armazenador}</p>
                                    <p className="text-[#6b7280] text-xs">{arm.endereco} - {arm.municipio}/{arm.uf}</p>
                                  </div>
                                ) : null;
                              })()}
                            </div>
                          )}
                        </>
                      )}
                    </div>

                    {/* Destino */}
                    <div className="space-y-5 p-5 bg-[#f5f6f8] rounded-lg border-2 border-[#e0e4e8]">
                      <div className="flex items-center gap-2 mb-3">
                        <MapPin className="w-5 h-5 text-[#4ecdc4]" />
                        <h3 className="text-[#1a2332] font-bold text-lg">Destino - Porto</h3>
                      </div>

                      <div className="space-y-2">
                        <Label className="text-[#1a2332] font-semibold text-xs uppercase tracking-wide">
                          {config?.fonte === 'b3' ? 'Base de Entrega (B3)' : 'Porto de Escoamento'}
                        </Label>
                        <Select value={portoSelecionado} onValueChange={setPortoSelecionado}>
                          <SelectTrigger className="h-11 border-2 border-[#e0e4e8] bg-white">
                            <SelectValue placeholder={config?.fonte === 'b3' ? 'Selecione a base' : 'Selecione o porto'} />
                          </SelectTrigger>
                          <SelectContent>
                            {config?.fonte === 'b3' ? (
                              // Mostrar apenas BASES para contratos B3
                              <>
                                <div className="px-2 py-1.5 text-xs font-bold text-green-700 bg-green-50 uppercase tracking-wide">
                                  🇧🇷 Bases de Entrega B3
                                </div>
                                {PORTOS.filter(p => p.tipo === 'base').map(porto => (
                                  <SelectItem key={porto.id} value={porto.id}>
                                    {porto.nome} - {porto.cidade}/{porto.uf}
                                  </SelectItem>
                                ))}
                              </>
                            ) : (
                              // Mostrar apenas PORTOS para contratos Yahoo
                              <>
                                <div className="px-2 py-1.5 text-xs font-bold text-blue-700 bg-blue-50 uppercase tracking-wide">
                                  🚢 Portos Marítimos
                                </div>
                                {PORTOS.filter(p => p.tipo === 'maritimo').map(porto => (
                                  <SelectItem key={porto.id} value={porto.id}>
                                    {porto.nome} - {porto.cidade}/{porto.uf}
                                  </SelectItem>
                                ))}
                                <div className="border-t border-gray-200 my-1"></div>
                                <div className="px-2 py-1.5 text-xs font-bold text-cyan-700 bg-cyan-50 uppercase tracking-wide">
                                  🚤 Portos Fluviais
                                </div>
                                {PORTOS.filter(p => p.tipo === 'fluvial').map(porto => (
                                  <SelectItem key={porto.id} value={porto.id}>
                                    {porto.nome} - {porto.cidade}/{porto.uf}
                                  </SelectItem>
                                ))}
                              </>
                            )}
                          </SelectContent>
                        </Select>
                        {config?.fonte === 'b3' && (
                          <p className="text-xs text-green-700 bg-green-50 border border-green-200 rounded p-2">
                            ℹ️ Contratos B3 têm base de entrega específica (não porto de exportação)
                          </p>
                        )}
                        {config?.fonte === 'b3' && (
                          <p className="text-xs text-blue-700 bg-blue-50 border border-blue-200 rounded p-2 mt-2">
                            📊 Dados B3: Valores de referência do mercado spot. Para cotações em tempo real, integre com fonte de dados oficial.
                          </p>
                        )}
                      </div>

                      {portoSelecionado && (
                        <div className="bg-[#4ecdc4] bg-opacity-10 border border-[#4ecdc4] rounded-lg p-3">
                          {(() => {
                            const porto = getPortoById(portoSelecionado);
                            return porto ? (
                              <div className="space-y-1">
                                <p className="text-[#1a2332] font-bold text-sm">{porto.nome}</p>
                                <p className="text-[#6b7280] text-xs">{porto.cidade}/{porto.uf} - {porto.tipo === 'maritimo' ? 'Marítimo' : 'Fluvial'}</p>
                              </div>
                            ) : null;
                          })()}
                        </div>
                      )}

                      {calculandoDistancia && (
                        <div className="bg-white border-2 border-[#e0e4e8] rounded-lg p-4 flex items-center justify-center gap-2">
                          <Loader2 className="w-5 h-5 animate-spin text-[#4ecdc4]" />
                          <span className="text-[#6b7280] text-sm font-medium">Calculando rota...</span>
                        </div>
                      )}

                      {distanciaKm !== null && !calculandoDistancia && (
                        <div className="bg-gradient-to-br from-[#4ecdc4] to-[#5dd9c1] rounded-lg p-4 text-center">
                          <p className="text-white text-xs font-bold uppercase tracking-wider mb-1">
                            Distância Rodoviária
                          </p>
                          <p className="text-white text-3xl font-bold">
                            {distanciaKm.toLocaleString('pt-BR', { maximumFractionDigits: 0 })} km
                          </p>
                          {avisoDistancia && (
                            <p className="text-white text-sm font-medium mt-1">
                              {avisoDistancia}
                            </p>
                          )}
                          {metodoCalculo && (
                            <p className="text-white text-sm font-medium mt-1">
                              Método: {metodoCalculo}
                            </p>
                          )}
                          {duracaoHoras && (
                            <p className="text-white text-sm font-medium mt-1">
                              Duração: {duracaoHoras.toFixed(2)} horas
                            </p>
                          )}
                        </div>
                      )}

                      <div className="space-y-2">
                        <Label className="text-[#1a2332] font-semibold text-xs uppercase tracking-wide">
                          Custo Frete (R$/km)
                        </Label>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="0.25"
                          value={custoPorKm}
                          onChange={(e) => setCustoPorKm(e.target.value)}
                          className="h-11 border-2 border-[#e0e4e8] font-mono text-lg"
                        />
                      </div>

                      {freteTotal !== null && (
                        <div className="bg-white border-2 border-[#1a2332] rounded-lg p-3">
                          <p className="text-[#6b7280] text-xs font-bold uppercase tracking-wide mb-1">
                            Frete Total
                          </p>
                          <p className="text-[#1a2332] text-2xl font-bold font-mono">
                            R$ {freteTotal.toFixed(2)}/ton
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* SEÇÃO 2: PARÂMETROS COMERCIAIS */}
              <div className="grid lg:grid-cols-5 gap-6">
                <Card className="lg:col-span-2 border-2 border-[#e0e4e8] shadow-sm">
                  <CardHeader className="bg-[#1a2332] text-white rounded-t-lg">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Calculator className="w-5 h-5 text-[#4ecdc4]" />
                      Etapa 2: Parâmetros Comerciais
                    </CardTitle>
                    <CardDescription className="text-[#e0e4e8]">
                      Commodity e prêmio
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-6 space-y-5">
                    <div className="space-y-2">
                      <Label className="text-[#1a2332] font-semibold text-sm uppercase tracking-wide">
                        Commodity
                      </Label>
                      <Select value={commoditySelecionada} onValueChange={handleCommodityChange}>
                        <SelectTrigger className="h-12 border-2 border-[#e0e4e8] bg-white">
                          <SelectValue placeholder="Selecione uma commodity" />
                        </SelectTrigger>
                        <SelectContent>
                          {/* Grupo Yahoo Finance */}
                          <div className="px-2 py-1.5 text-xs font-bold text-purple-700 bg-purple-50 uppercase tracking-wide">
                            🌐 Yahoo Finance (Internacional)
                          </div>
                          {todasCommodities
                            .filter(c => c.fonte === 'yahoo')
                            .map(commodity => (
                              <SelectItem key={commodity.id} value={commodity.id}>
                                <div className="flex items-center gap-2">
                                  <span>{commodity.nome}</span>
                                  <span className="text-xs text-gray-500">({commodity.mercado})</span>
                                </div>
                              </SelectItem>
                            ))}
                          
                          {/* Separador */}
                          <div className="border-t border-gray-200 my-1"></div>
                          
                          {/* Grupo B3 */}
                          <div className="px-2 py-1.5 text-xs font-bold text-green-700 bg-green-50 uppercase tracking-wide">
                            🇧🇷 B3 (Brasil)
                          </div>
                          {todasCommodities
                            .filter(c => c.fonte === 'b3')
                            .map(commodity => (
                              <SelectItem key={commodity.id} value={commodity.id}>
                                <div className="flex items-center gap-2">
                                  <span>{commodity.nome}</span>
                                  <span className="text-xs text-gray-500">({commodity.ticker_b3})</span>
                                </div>
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-[#1a2332] font-semibold text-sm uppercase tracking-wide">
                        Prêmio {portoSelecionado && `(${getPortoById(portoSelecionado)?.nome})`}
                      </Label>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="50.00"
                        value={premioCents}
                        onChange={(e) => setPremioCents(e.target.value)}
                        className="h-12 border-2 border-[#e0e4e8] font-mono text-lg"
                      />
                      <p className="text-[#6b7280] text-xs">Em centavos de dólar por bushel (¢/bu)</p>
                    </div>

                    <Button
                      onClick={handleCalcular}
                      disabled={loading}
                      className="w-full h-14 bg-[#4ecdc4] hover:bg-[#5dd9c1] text-white font-semibold text-base uppercase tracking-wide shadow-lg"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                          Processando...
                        </>
                      ) : (
                        <>
                          <Calculator className="mr-2 h-5 w-5" />
                          Calcular Paridade
                        </>
                      )}
                    </Button>

                    {error && (
                      <div className="bg-[#dc2626] border-2 border-[#dc2626] rounded-lg p-4 flex items-start gap-3">
                        <AlertTriangle className="w-5 h-5 text-white flex-shrink-0 mt-0.5" />
                        <p className="text-white text-sm font-medium">{error}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* SEÇÃO 3: RESULTADOS */}
                <Card className="lg:col-span-3 border-2 border-[#e0e4e8] shadow-sm">
                  <CardHeader className="bg-[#1a2332] text-white rounded-t-lg">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <TrendingUp className="w-5 h-5 text-[#4ecdc4]" />
                      Resultados
                    </CardTitle>
                    <CardDescription className="text-[#e0e4e8]">
                      Valores em tempo real
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-6">
                    {!result && !error && (
                      <div className="flex flex-col items-center justify-center py-16 text-[#6b7280]">
                        <TrendingUp className="w-20 h-20 mb-4 opacity-20" />
                        <p className="text-sm uppercase tracking-wide">Aguardando cálculo</p>
                      </div>
                    )}

                    {result && (
                      <div className="space-y-5">
                        {result.preco_produtor_r_saca > 500 && (
                          <div className="bg-yellow-50 border-2 border-yellow-500 rounded-lg p-4 flex items-start gap-3">
                            <AlertTriangle className="w-6 h-6 text-yellow-600 flex-shrink-0" />
                            <div>
                              <p className="font-bold text-yellow-900 text-sm uppercase tracking-wide">Alerta de Mercado</p>
                              <p className="text-sm text-yellow-800 mt-1">
                                Valor acima do padrão (R$ {result.preco_produtor_r_saca.toFixed(2)}/saca).
                              </p>
                            </div>
                          </div>
                        )}

                        <div className="bg-gradient-to-br from-[#4ecdc4] to-[#5dd9c1] rounded-xl p-8 text-center shadow-lg">
                          <p className="text-white text-xs font-bold uppercase tracking-widest mb-2">
                            PREÇO AO PRODUTOR
                          </p>
                          <p className="text-white text-6xl font-bold mb-2 tracking-tight">
                            {result.preco_produtor_r_saca.toFixed(2)}
                          </p>
                          <p className="text-white text-sm font-medium uppercase tracking-wide">
                            R$ / SACA {config?.peso_saca_kg}KG
                          </p>
                        </div>

                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="bg-[#f5f6f8] border-2 border-[#e0e4e8] rounded-lg p-5">
                            <p className="text-[#6b7280] text-xs font-bold uppercase tracking-wide mb-2">
                              Preço no Interior
                            </p>
                            <p className="text-[#1a2332] text-3xl font-bold">
                              {result.preco_interior_r_ton.toFixed(2)}
                            </p>
                            <p className="text-[#6b7280] text-sm font-medium mt-1">R$ / tonelada</p>
                          </div>

                          <div className="bg-[#f5f6f8] border-2 border-[#e0e4e8] rounded-lg p-5">
                            <p className="text-[#6b7280] text-xs font-bold uppercase tracking-wide mb-2">
                              Paridade Porto
                            </p>
                            <p className="text-[#1a2332] text-3xl font-bold">
                              {result.paridade_porto_r_ton.toFixed(2)}
                            </p>
                            <p className="text-[#6b7280] text-sm font-medium mt-1">R$ / tonelada</p>
                          </div>
                        </div>

                        <div className="border-t-2 border-[#e0e4e8] pt-5">
                          <p className="text-[#6b7280] text-xs font-bold uppercase tracking-wider mb-3">
                            Dados de Mercado
                          </p>
                          <div className="grid md:grid-cols-2 gap-3">
                            <div className="flex justify-between items-center p-3 bg-[#f5f6f8] rounded-lg">
                              <span className="text-[#6b7280] text-sm font-medium">
                                {config?.nome} ({config?.ticker})
                              </span>
                              <span className="text-[#1a2332] font-bold font-mono">
                                ${result.commodity_usd_bu.toFixed(4)}/bu
                              </span>
                            </div>
                            <div className="flex justify-between items-center p-3 bg-[#f5f6f8] rounded-lg">
                              <span className="text-[#6b7280] text-sm font-medium">
                                Câmbio USD/BRL
                              </span>
                              <span className="text-[#1a2332] font-bold font-mono">
                                R$ {result.cambio_usd_brl.toFixed(4)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* ABA: PARÂMETROS (COMMODITIES + ARMAZÉNS) */}
          <TabsContent value="parametros">
            <div className="space-y-6">
              {/* COMMODITIES NO TOPO */}
              <GerenciadorCommodities 
                commodities={todasCommodities}
                onCommoditiesChange={(novasCommodities) => {
                  setTodasCommodities(novasCommodities);
                  carregarCommodities();
                }}
              />

              {/* ARMAZÉNS ABAIXO */}
              <GerenciadorArmazens 
                armazens={todosArmazens}
                onArmazensChange={(novosArmazens) => {
                  setTodosArmazens(novosArmazens);
                }}
              />
            </div>
          </TabsContent>

          {/* ABA: MEMÓRIA DE CÁLCULO */}
          <TabsContent value="resultados">
            {!memoriaCalculo ? (
              <Card className="border-2 border-[#e0e4e8]">
                <CardContent className="flex flex-col items-center justify-center py-20 text-[#6b7280]">
                  <Calculator className="w-20 h-20 mb-4 opacity-20" />
                  <p className="text-sm uppercase tracking-wide">Realize um cálculo para visualizar a memória detalhada</p>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-2 border-[#4ecdc4] shadow-lg">
                <CardHeader className="bg-gradient-to-r from-[#1a2332] to-[#2c3e50] text-white rounded-t-lg">
                  <CardTitle className="flex items-center gap-2 text-xl">
                    <Calculator className="w-6 h-6 text-[#4ecdc4]" />
                    Memória de Cálculo Detalhada - {memoriaCalculo.commodity_nome}
                  </CardTitle>
                  <CardDescription className="text-[#e0e4e8]">
                    Todas as etapas, conversões e variáveis do cálculo
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-8 space-y-8">
                  
                  {/* Detectar fluxo: Yahoo (bushels > 0) ou B3 (bushels = 0) */}
                  {memoriaCalculo.bushels_per_ton > 0 ? (
                    // ===== FLUXO YAHOO FINANCE =====
                    <>
                      {/* DADOS DE ENTRADA */}
                      <div>
                        <div className="flex items-center gap-3 mb-4">
                          <span className="flex items-center justify-center w-12 h-12 rounded-full bg-purple-600 text-white font-bold text-xl shadow-lg">📊</span>
                          <h3 className="text-[#1a2332] font-bold text-xl">Dados de Entrada (Mercado Internacional)</h3>
                        </div>
                        <div className="bg-purple-50 border-2 border-purple-300 rounded-xl p-6 space-y-4">
                          <div className="grid md:grid-cols-2 gap-4">
                            <div className="bg-white rounded-lg p-4 shadow-sm">
                              <p className="text-purple-700 text-xs font-bold uppercase tracking-wide mb-2">🌐 Commodity</p>
                              <p className="text-[#1a2332] font-bold text-xl mb-1">{memoriaCalculo.commodity_nome}</p>
                              <p className="text-purple-600 text-sm font-semibold">Mercado: {config?.mercado}</p>
                              <p className="text-gray-500 text-xs mt-1">Ticker: {config?.ticker}</p>
                            </div>
                            <div className="bg-white rounded-lg p-4 shadow-sm">
                              <p className="text-purple-700 text-xs font-bold uppercase tracking-wide mb-2">💵 Cotação Internacional</p>
                              <p className="text-[#1a2332] font-mono font-bold text-3xl mb-1">
                                ${memoriaCalculo.commodity_usd_bu.toFixed(4)}
                              </p>
                              <p className="text-gray-600 text-sm">USD por bushel (ou libra)</p>
                            </div>
                            <div className="bg-white rounded-lg p-4 shadow-sm">
                              <p className="text-purple-700 text-xs font-bold uppercase tracking-wide mb-2">💱 Câmbio</p>
                              <p className="text-[#1a2332] font-mono font-bold text-3xl mb-1">
                                R$ {memoriaCalculo.cambio_usd_brl.toFixed(4)}
                              </p>
                              <p className="text-gray-600 text-sm">BRL por 1 USD</p>
                              <p className="text-blue-600 text-xs mt-1">Fonte: Yahoo Finance (BRL=X)</p>
                            </div>
                            <div className="bg-white rounded-lg p-4 shadow-sm">
                              <p className="text-purple-700 text-xs font-bold uppercase tracking-wide mb-2">🎯 Prêmio no Porto</p>
                              <p className="text-[#1a2332] font-mono font-bold text-3xl mb-1">
                                {memoriaCalculo.premio_cents.toFixed(2)}¢
                              </p>
                              <p className="text-gray-600 text-sm">centavos USD/bushel</p>
                              <p className="text-purple-600 text-xs mt-1">Porto: {memoriaCalculo.porto_nome}</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* PASSO 1: CONVERSÕES */}
                      <div>
                        <div className="flex items-center gap-3 mb-4">
                          <span className="flex items-center justify-center w-12 h-12 rounded-full bg-[#4ecdc4] text-white font-bold text-xl shadow-lg">1</span>
                          <h3 className="text-[#1a2332] font-bold text-xl">Conversão de Unidades (Bushel/Libra → Tonelada)</h3>
                        </div>
                        <div className="bg-[#f5f6f8] border-2 border-[#e0e4e8] rounded-xl p-6 space-y-5">
                          <div className="grid md:grid-cols-3 gap-4">
                            <div className="bg-white rounded-lg p-4 border-l-4 border-blue-500">
                              <p className="text-blue-700 text-xs font-bold uppercase mb-2">⚖️ Fator Conversão</p>
                              <p className="text-[#1a2332] font-mono font-bold text-2xl">
                                {memoriaCalculo.bushels_per_ton.toFixed(4)}
                              </p>
                              <p className="text-gray-600 text-sm">bushels por tonelada</p>
                            </div>
                            <div className="bg-white rounded-lg p-4 border-l-4 border-green-500">
                              <p className="text-green-700 text-xs font-bold uppercase mb-2">📦 Peso da Saca</p>
                              <p className="text-[#1a2332] font-mono font-bold text-2xl">
                                {memoriaCalculo.peso_saca_kg} kg
                              </p>
                              <p className="text-gray-600 text-sm">peso unitário</p>
                            </div>
                            <div className="bg-white rounded-lg p-4 border-l-4 border-purple-500">
                              <p className="text-purple-700 text-xs font-bold uppercase mb-2">🔢 Sacas/Tonelada</p>
                              <p className="text-[#1a2332] font-mono font-bold text-2xl">
                                {memoriaCalculo.sacas_per_ton.toFixed(4)}
                              </p>
                              <p className="text-gray-600 text-sm">1000kg ÷ {memoriaCalculo.peso_saca_kg}kg</p>
                            </div>
                          </div>
                          
                          {/* Commodity USD/ton */}
                          <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-5">
                            <p className="text-blue-900 font-bold mb-3 text-lg">
                              📐 Fórmula: Commodity (USD/ton) = Cotação × Fator Conversão
                            </p>
                            <div className="bg-white rounded-lg p-4 font-mono text-lg">
                              <p className="text-gray-700 mb-2">
                                <span className="text-blue-600 font-bold">${memoriaCalculo.commodity_usd_bu.toFixed(4)}</span>/bu 
                                × <span className="text-blue-600 font-bold">{memoriaCalculo.bushels_per_ton.toFixed(4)}</span> bu/ton
                              </p>
                              <p className="text-[#4ecdc4] font-bold text-2xl">
                                = ${memoriaCalculo.commodity_usd_ton.toFixed(2)}/ton
                              </p>
                            </div>
                          </div>

                          {/* Prêmio USD/ton */}
                          <div className="bg-purple-50 border-2 border-purple-300 rounded-lg p-5">
                            <p className="text-purple-900 font-bold mb-3 text-lg">
                              📐 Fórmula: Prêmio (USD/ton) = (Prêmio ¢ ÷ 100) × Fator Conversão
                            </p>
                            <div className="bg-white rounded-lg p-4 font-mono text-lg">
                              <p className="text-gray-700 mb-2">
                                (<span className="text-purple-600 font-bold">{memoriaCalculo.premio_cents.toFixed(2)}¢</span> ÷ 100) 
                                × <span className="text-purple-600 font-bold">{memoriaCalculo.bushels_per_ton.toFixed(4)}</span> bu/ton
                              </p>
                              <p className="text-[#4ecdc4] font-bold text-2xl">
                                = ${memoriaCalculo.premio_usd_ton.toFixed(2)}/ton
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* PASSO 2: FOB */}
                      <div>
                        <div className="flex items-center gap-3 mb-4">
                          <span className="flex items-center justify-center w-12 h-12 rounded-full bg-[#4ecdc4] text-white font-bold text-xl shadow-lg">2</span>
                          <h3 className="text-[#1a2332] font-bold text-xl">Preço FOB (Free On Board)</h3>
                        </div>
                        <div className="bg-green-50 border-2 border-green-400 rounded-xl p-6">
                          <p className="text-green-900 font-bold mb-4 text-lg">
                            🚢 Fórmula: FOB = Commodity + Prêmio
                          </p>
                          <div className="bg-white rounded-lg p-6 font-mono space-y-3">
                            <p className="text-gray-700 text-xl">
                              FOB = <span className="text-blue-600 font-bold">${memoriaCalculo.commodity_usd_ton.toFixed(2)}</span>/ton 
                              + <span className="text-purple-600 font-bold">${memoriaCalculo.premio_usd_ton.toFixed(2)}</span>/ton
                            </p>
                            <div className="border-t-2 border-green-300 pt-3">
                              <p className="text-green-600 font-bold text-3xl">
                                = ${memoriaCalculo.fob_usd_ton.toFixed(2)}/ton
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* PASSO 3: CÂMBIO */}
                      <div>
                        <div className="flex items-center gap-3 mb-4">
                          <span className="flex items-center justify-center w-12 h-12 rounded-full bg-[#4ecdc4] text-white font-bold text-xl shadow-lg">3</span>
                          <h3 className="text-[#1a2332] font-bold text-xl">Conversão Câmbio (USD → BRL)</h3>
                        </div>
                        <div className="bg-yellow-50 border-2 border-yellow-400 rounded-xl p-6">
                          <p className="text-yellow-900 font-bold mb-4 text-lg">
                            💱 Fórmula: Paridade Porto (R$/ton) = FOB × Câmbio
                          </p>
                          <div className="bg-white rounded-lg p-6 font-mono space-y-3">
                            <p className="text-gray-700 text-xl">
                              <span className="text-green-600 font-bold">${memoriaCalculo.fob_usd_ton.toFixed(2)}</span>/ton 
                              × <span className="text-blue-600 font-bold">R$ {memoriaCalculo.cambio_usd_brl.toFixed(4)}</span>
                            </p>
                            <div className="border-t-2 border-yellow-400 pt-3">
                              <p className="text-[#4ecdc4] font-bold text-3xl">
                                = R$ {memoriaCalculo.paridade_porto_r_ton.toFixed(2)}/ton
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* PASSO 4: FRETE */}
                      {memoriaCalculo.distancia_km && memoriaCalculo.frete_km && (
                        <div>
                          <div className="flex items-center gap-3 mb-4">
                            <span className="flex items-center justify-center w-12 h-12 rounded-full bg-[#4ecdc4] text-white font-bold text-xl shadow-lg">4</span>
                            <h3 className="text-[#1a2332] font-bold text-xl">Logística e Frete Rodoviário</h3>
                          </div>
                          <div className="bg-[#f5f6f8] border-2 border-[#e0e4e8] rounded-xl p-6 space-y-5">
                            <div className="grid md:grid-cols-2 gap-4">
                              <div className="bg-white rounded-lg p-4 shadow-sm">
                                <p className="text-gray-600 text-xs font-bold uppercase mb-2">📍 Origem</p>
                                <p className="text-[#1a2332] font-bold text-lg">{memoriaCalculo.origem}</p>
                              </div>
                              <div className="bg-white rounded-lg p-4 shadow-sm">
                                <p className="text-gray-600 text-xs font-bold uppercase mb-2">🎯 Destino</p>
                                <p className="text-[#1a2332] font-bold text-lg">{memoriaCalculo.destino}</p>
                              </div>
                              <div className="bg-white rounded-lg p-4 shadow-sm border-l-4 border-orange-500">
                                <p className="text-orange-700 text-xs font-bold uppercase mb-2">🛣️ Distância</p>
                                <p className="text-[#1a2332] font-mono font-bold text-2xl">
                                  {memoriaCalculo.distancia_km.toFixed(2)} km
                                </p>
                              </div>
                              <div className="bg-white rounded-lg p-4 shadow-sm border-l-4 border-red-500">
                                <p className="text-red-700 text-xs font-bold uppercase mb-2">💰 Custo por km</p>
                                <p className="text-[#1a2332] font-mono font-bold text-2xl">
                                  R$ {memoriaCalculo.frete_km.toFixed(2)}/km
                                </p>
                              </div>
                            </div>
                            
                            <div className="bg-orange-50 border-2 border-orange-400 rounded-lg p-5">
                              <p className="text-orange-900 font-bold mb-4 text-lg">
                                🚚 Fórmula: Frete = Distância × Custo/km
                              </p>
                              <div className="bg-white rounded-lg p-4 font-mono text-lg">
                                <p className="text-gray-700 mb-2">
                                  <span className="text-orange-600 font-bold">{memoriaCalculo.distancia_km.toFixed(2)}</span> km 
                                  × <span className="text-red-600 font-bold">R$ {memoriaCalculo.frete_km.toFixed(2)}</span>/km
                                </p>
                                <p className="text-[#4ecdc4] font-bold text-2xl">
                                  = R$ {memoriaCalculo.frete_r_ton.toFixed(2)}/ton
                                </p>
                              </div>
                            </div>

                            {memoriaCalculo.duracao_horas && (
                              <div className="bg-blue-50 border border-blue-300 rounded-lg p-3">
                                <p className="text-blue-800 text-sm">
                                  ⏱️ Tempo de viagem: <span className="font-bold">{memoriaCalculo.duracao_horas.toFixed(2)} horas</span>
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* PASSO 5: PREÇO INTERIOR */}
                      <div>
                        <div className="flex items-center gap-3 mb-4">
                          <span className="flex items-center justify-center w-12 h-12 rounded-full bg-[#4ecdc4] text-white font-bold text-xl shadow-lg">5</span>
                          <h3 className="text-[#1a2332] font-bold text-xl">Preço no Interior (Descontando Frete)</h3>
                        </div>
                        <div className="bg-red-50 border-2 border-red-400 rounded-xl p-6">
                          <p className="text-red-900 font-bold mb-4 text-lg">
                            🏭 Fórmula: Preço Interior = Paridade Porto - Frete
                          </p>
                          <div className="bg-white rounded-lg p-6 font-mono space-y-3">
                            <p className="text-gray-700 text-xl">
                              <span className="text-blue-600 font-bold">R$ {memoriaCalculo.paridade_porto_r_ton.toFixed(2)}</span>/ton 
                              - <span className="text-red-600 font-bold">R$ {memoriaCalculo.frete_r_ton.toFixed(2)}</span>/ton
                            </p>
                            <div className="border-t-2 border-red-400 pt-3">
                              <p className="text-[#4ecdc4] font-bold text-3xl">
                                = R$ {memoriaCalculo.preco_interior_r_ton.toFixed(2)}/ton
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* PASSO 6: SACA */}
                      <div>
                        <div className="flex items-center gap-3 mb-4">
                          <span className="flex items-center justify-center w-12 h-12 rounded-full bg-[#4ecdc4] text-white font-bold text-xl shadow-lg">6</span>
                          <h3 className="text-[#1a2332] font-bold text-xl">Conversão para Saca (Preço ao Produtor)</h3>
                        </div>
                        <div className="bg-gradient-to-br from-green-50 to-emerald-100 border-2 border-green-500 rounded-xl p-6">
                          <p className="text-green-900 font-bold mb-4 text-lg">
                            📦 Fórmula: Preço/Saca = Preço Interior ÷ Sacas/Tonelada
                          </p>
                          <div className="bg-white rounded-lg p-6 font-mono space-y-3">
                            <p className="text-gray-700 text-xl">
                              <span className="text-blue-600 font-bold">R$ {memoriaCalculo.preco_interior_r_ton.toFixed(2)}</span>/ton 
                              ÷ <span className="text-purple-600 font-bold">{memoriaCalculo.sacas_per_ton.toFixed(4)}</span> sacas/ton
                            </p>
                            <div className="border-t-2 border-green-500 pt-3">
                              <p className="text-green-600 font-bold text-4xl">
                                = R$ {memoriaCalculo.preco_produtor_r_saca.toFixed(2)}/saca
                              </p>
                            </div>
                          </div>
                          <div className="bg-green-100 border border-green-400 rounded-lg p-3 mt-4">
                            <p className="text-green-800 text-sm font-semibold">
                              ✅ Saca de {memoriaCalculo.peso_saca_kg}kg
                            </p>
                          </div>
                        </div>
                      </div>
                    </>
                  ) : (
                    // ===== FLUXO B3 =====
                    <>
                      {/* DADOS DE ENTRADA B3 */}
                      <div>
                        <div className="flex items-center gap-3 mb-4">
                          <span className="flex items-center justify-center w-12 h-12 rounded-full bg-green-600 text-white font-bold text-xl shadow-lg">🇧🇷</span>
                          <h3 className="text-[#1a2332] font-bold text-xl">Dados de Entrada (Mercado B3 - Brasil)</h3>
                        </div>
                        <div className="bg-green-50 border-2 border-green-400 rounded-xl p-6 space-y-4">
                          <div className="grid md:grid-cols-2 gap-4">
                            <div className="bg-white rounded-lg p-4 shadow-sm">
                              <p className="text-green-700 text-xs font-bold uppercase tracking-wide mb-2">🌾 Commodity</p>
                              <p className="text-[#1a2332] font-bold text-xl mb-1">{memoriaCalculo.commodity_nome}</p>
                              <p className="text-green-600 text-sm font-semibold">Contrato B3: {config?.ticker_b3}</p>
                              <p className="text-gray-500 text-xs mt-1">Mercado: Bolsa Brasileira</p>
                            </div>
                            <div className="bg-white rounded-lg p-4 shadow-sm">
                              <p className="text-green-700 text-xs font-bold uppercase tracking-wide mb-2">💵 Cotação B3</p>
                              <p className="text-[#1a2332] font-mono font-bold text-3xl mb-1">
                                R$ {memoriaCalculo.paridade_porto_r_ton.toFixed(2)}
                              </p>
                              <p className="text-gray-600 text-sm">R$ por tonelada na base</p>
                            </div>
                            <div className="bg-white rounded-lg p-4 shadow-sm border-l-4 border-green-500">
                              <p className="text-green-700 text-xs font-bold uppercase tracking-wide mb-2">🏛️ Mercado</p>
                              <p className="text-green-700 font-bold text-xl mb-1">B3 - Brasil</p>
                              <p className="text-gray-600 text-sm">Bolsa de Valores Brasileira</p>
                              <p className="text-blue-600 text-xs mt-1">Cotação já em R$ (sem câmbio)</p>
                            </div>
                            <div className="bg-white rounded-lg p-4 shadow-sm border-l-4 border-purple-500">
                              <p className="text-purple-700 text-xs font-bold uppercase tracking-wide mb-2">📦 Peso da Saca</p>
                              <p className="text-[#1a2332] font-mono font-bold text-3xl mb-1">
                                {memoriaCalculo.peso_saca_kg} kg
                              </p>
                              <p className="text-gray-600 text-sm">
                                = {memoriaCalculo.sacas_per_ton.toFixed(4)} sacas/ton
                              </p>
                            </div>
                          </div>
                          
                          <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-4">
                            <p className="text-blue-800 text-sm font-semibold">
                              ℹ️ <strong>Importante:</strong> Contratos B3 são cotados diretamente em R$/ton ou R$/saca, sem necessidade de conversão de câmbio USD→BRL.
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* PASSO 1: PREÇO BASE */}
                      <div>
                        <div className="flex items-center gap-3 mb-4">
                          <span className="flex items-center justify-center w-12 h-12 rounded-full bg-green-600 text-white font-bold text-xl shadow-lg">1</span>
                          <h3 className="text-[#1a2332] font-bold text-xl">Preço na Base de Entrega</h3>
                        </div>
                        <div className="bg-green-50 border-2 border-green-400 rounded-xl p-6">
                          <p className="text-green-900 font-bold mb-4 text-lg">
                            📍 Base de Entrega: {memoriaCalculo.destino}
                          </p>
                          <div className="bg-white rounded-lg p-6">
                            <div className="grid md:grid-cols-2 gap-6">
                              <div className="text-center p-4 bg-green-50 rounded-lg">
                                <p className="text-gray-600 text-xs font-bold uppercase mb-2">Preço Base (R$/ton)</p>
                                <p className="text-green-600 font-mono font-bold text-3xl">
                                  R$ {memoriaCalculo.paridade_porto_r_ton.toFixed(2)}
                                </p>
                              </div>
                              <div className="text-center p-4 bg-green-50 rounded-lg">
                                <p className="text-gray-600 text-xs font-bold uppercase mb-2">Preço Base (R$/saca)</p>
                                <p className="text-green-600 font-mono font-bold text-3xl">
                                  R$ {(memoriaCalculo.paridade_porto_r_ton / memoriaCalculo.sacas_per_ton).toFixed(2)}
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* PASSO 2: FRETE B3 */}
                      {memoriaCalculo.distancia_km && memoriaCalculo.frete_km && (
                        <div>
                          <div className="flex items-center gap-3 mb-4">
                            <span className="flex items-center justify-center w-12 h-12 rounded-full bg-green-600 text-white font-bold text-xl shadow-lg">2</span>
                            <h3 className="text-[#1a2332] font-bold text-xl">Logística e Frete Rodoviário</h3>
                          </div>
                          <div className="bg-[#f5f6f8] border-2 border-[#e0e4e8] rounded-xl p-6 space-y-5">
                            <div className="grid md:grid-cols-2 gap-4">
                              <div className="bg-white rounded-lg p-4 shadow-sm">
                                <p className="text-gray-600 text-xs font-bold uppercase mb-2">📍 Origem (Produtor)</p>
                                <p className="text-[#1a2332] font-bold text-lg">{memoriaCalculo.origem}</p>
                              </div>
                              <div className="bg-white rounded-lg p-4 shadow-sm">
                                <p className="text-gray-600 text-xs font-bold uppercase mb-2">🎯 Destino (Base)</p>
                                <p className="text-[#1a2332] font-bold text-lg">{memoriaCalculo.destino}</p>
                              </div>
                              <div className="bg-white rounded-lg p-4 shadow-sm border-l-4 border-orange-500">
                                <p className="text-orange-700 text-xs font-bold uppercase mb-2">🛣️ Distância</p>
                                <p className="text-[#1a2332] font-mono font-bold text-2xl">
                                  {memoriaCalculo.distancia_km.toFixed(2)} km
                                </p>
                              </div>
                              <div className="bg-white rounded-lg p-4 shadow-sm border-l-4 border-red-500">
                                <p className="text-red-700 text-xs font-bold uppercase mb-2">💰 Custo/km</p>
                                <p className="text-[#1a2332] font-mono font-bold text-2xl">
                                  R$ {memoriaCalculo.frete_km.toFixed(2)}/km
                                </p>
                              </div>
                            </div>
                            
                            <div className="bg-orange-50 border-2 border-orange-400 rounded-lg p-5">
                              <p className="text-orange-900 font-bold mb-4 text-lg">
                                🚚 Fórmula: Frete = Distância × Custo/km
                              </p>
                              <div className="bg-white rounded-lg p-4 font-mono text-lg">
                                <p className="text-gray-700 mb-2">
                                  <span className="text-orange-600 font-bold">{memoriaCalculo.distancia_km.toFixed(2)}</span> km 
                                  × <span className="text-red-600 font-bold">R$ {memoriaCalculo.frete_km.toFixed(2)}</span>/km
                                </p>
                                <p className="text-green-600 font-bold text-2xl">
                                  = R$ {memoriaCalculo.frete_r_ton.toFixed(2)}/ton
                                </p>
                              </div>
                            </div>

                            {memoriaCalculo.duracao_horas && (
                              <div className="bg-blue-50 border border-blue-300 rounded-lg p-3">
                                <p className="text-blue-800 text-sm">
                                  ⏱️ Tempo de viagem: <span className="font-bold">{memoriaCalculo.duracao_horas.toFixed(2)} horas</span>
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* PASSO 3: PREÇO PRODUTOR */}
                      <div>
                        <div className="flex items-center gap-3 mb-4">
                          <span className="flex items-center justify-center w-12 h-12 rounded-full bg-green-600 text-white font-bold text-xl shadow-lg">3</span>
                          <h3 className="text-[#1a2332] font-bold text-xl">Preço ao Produtor (Descontando Frete)</h3>
                        </div>
                        <div className="bg-gradient-to-br from-green-50 to-emerald-100 border-2 border-green-500 rounded-xl p-6 space-y-5">
                          {/* Cálculo em R$/ton */}
                          <div className="bg-white rounded-lg p-6">
                            <p className="text-green-900 font-bold mb-4 text-lg">
                              🏭 Fórmula: Preço Interior = Preço Base - Frete
                            </p>
                            <div className="font-mono space-y-3">
                              <p className="text-gray-700 text-xl">
                                <span className="text-blue-600 font-bold">R$ {memoriaCalculo.paridade_porto_r_ton.toFixed(2)}</span>/ton 
                                - <span className="text-red-600 font-bold">R$ {memoriaCalculo.frete_r_ton.toFixed(2)}</span>/ton
                              </p>
                              <div className="border-t-2 border-green-400 pt-3">
                                <p className="text-green-600 font-bold text-3xl">
                                  = R$ {memoriaCalculo.preco_interior_r_ton.toFixed(2)}/ton
                                </p>
                              </div>
                            </div>
                          </div>

                          {/* Cálculo em R$/saca */}
                          <div className="bg-white rounded-lg p-6">
                            <p className="text-green-900 font-bold mb-4 text-lg">
                              📦 Fórmula: Preço/Saca = Preço Interior ÷ Sacas/Tonelada
                            </p>
                            <div className="font-mono space-y-3">
                              <p className="text-gray-700 text-xl">
                                <span className="text-blue-600 font-bold">R$ {memoriaCalculo.preco_interior_r_ton.toFixed(2)}</span>/ton 
                                ÷ <span className="text-purple-600 font-bold">{memoriaCalculo.sacas_per_ton.toFixed(4)}</span> sacas/ton
                              </p>
                              <div className="border-t-2 border-green-500 pt-3">
                                <p className="text-green-600 font-bold text-4xl">
                                  = R$ {memoriaCalculo.preco_produtor_r_saca.toFixed(2)}/saca
                                </p>
                              </div>
                            </div>
                          </div>

                          <div className="bg-green-100 border-2 border-green-500 rounded-lg p-4">
                            <p className="text-green-800 text-sm font-bold">
                              ✅ Saca de {memoriaCalculo.peso_saca_kg}kg
                            </p>
                          </div>
                        </div>
                      </div>
                    </>
                  )}

                  {/* RESULTADO FINAL DESTAQUE */}
                  <div className="bg-gradient-to-br from-[#1a2332] via-[#2c3e50] to-[#1a2332] rounded-2xl p-10 text-center shadow-2xl border-4 border-[#4ecdc4]">
                    <p className="text-[#4ecdc4] text-sm font-bold uppercase tracking-widest mb-3">
                      ✨ RESULTADO FINAL ✨
                    </p>
                    <p className="text-white text-7xl font-bold mb-3 tracking-tight">
                      R$ {memoriaCalculo.preco_produtor_r_saca.toFixed(2)}
                    </p>
                    <p className="text-white text-xl font-semibold uppercase tracking-wide mb-6">
                      por saca de {memoriaCalculo.peso_saca_kg}kg
                    </p>
                    <div className="border-t-2 border-white border-opacity-20 pt-6 mt-6">
                      <div className="grid md:grid-cols-4 gap-4 text-white">
                        <div className="bg-white bg-opacity-10 rounded-lg p-4">
                          <p className="text-xs text-[#4ecdc4] uppercase font-bold mb-2">📍 Origem</p>
                          <p className="text-sm font-medium break-words">{memoriaCalculo.origem || 'Origem não especificada'}</p>
                        </div>
                        <div className="bg-white bg-opacity-10 rounded-lg p-4">
                          <p className="text-xs text-[#4ecdc4] uppercase font-bold mb-2">🎯 Destino</p>
                          <p className="text-sm font-medium break-words">{memoriaCalculo.destino || 'Destino não especificado'}</p>
                        </div>
                        <div className="bg-white bg-opacity-10 rounded-lg p-4">
                          <p className="text-xs text-[#4ecdc4] uppercase font-bold mb-2">🛣️ Distância</p>
                          <p className="text-lg font-bold">{memoriaCalculo.distancia_km ? memoriaCalculo.distancia_km.toFixed(0) : '0'} km</p>
                        </div>
                        <div className="bg-white bg-opacity-10 rounded-lg p-4">
                          <p className="text-xs text-[#4ecdc4] uppercase font-bold mb-2">⏱️ Duração</p>
                          <p className="text-lg font-bold">{memoriaCalculo.duracao_horas ? memoriaCalculo.duracao_horas.toFixed(1) : '0'} h</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <div className="bg-white border-t-2 border-[#e0e4e8] mt-16">
        <div className="max-w-7xl mx-auto px-8 py-6 flex items-center justify-between">
          <p className="text-[#6b7280] text-sm">
            © 2024 Oken. Todos os direitos reservados.
          </p>
          <img 
            src={okenLogo} 
            alt="Oken" 
            className="h-8 w-auto opacity-60"
          />
        </div>
      </div>
    </div>
  );
}