import { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Loader2, Upload, Download, Plus, Trash2, Edit2, Save, X, Database } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { type Armazem, parseCSV, exportToCSV } from '../data/armazens';

interface GerenciadorArmazensProps {
  armazens: Armazem[];
  onArmazensChange: (armazens: Armazem[]) => void;
}

export function GerenciadorArmazens({ armazens, onArmazensChange }: GerenciadorArmazensProps) {
  const [loading, setLoading] = useState(false);
  const [editando, setEditando] = useState<string | null>(null);
  const [novoArmazem, setNovoArmazem] = useState<Partial<Armazem> | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [confirmandoExclusaoTotal, setConfirmandoExclusaoTotal] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSalvarArmazem = async (armazem: Armazem) => {
    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-d467efec/armazens`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify(armazem),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erro ao salvar armazém');
      }

      // Atualizar lista local
      const index = armazens.findIndex(a => a.cda === armazem.cda);
      if (index >= 0) {
        const novosArmazens = [...armazens];
        novosArmazens[index] = armazem;
        onArmazensChange(novosArmazens);
      } else {
        onArmazensChange([...armazens, armazem]);
      }

      setSuccess(`Armazém ${armazem.cda} salvo com sucesso!`);
      setEditando(null);
      setNovoArmazem(null);
    } catch (err) {
      console.error('Erro ao salvar armazém:', err);
      setError(err instanceof Error ? err.message : 'Erro ao salvar armazém');
    } finally {
      setLoading(false);
    }
  };

  const handleDeletarArmazem = async (cda: string) => {
    if (!confirm(`Tem certeza que deseja deletar o armazém ${cda}?`)) {
      return;
    }

    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-d467efec/armazens/${cda}`,
        {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erro ao deletar armazém');
      }

      // Atualizar lista local
      onArmazensChange(armazens.filter(a => a.cda !== cda));
      setSuccess(`Armazém ${cda} deletado com sucesso!`);
    } catch (err) {
      console.error('Erro ao deletar armazém:', err);
      setError(err instanceof Error ? err.message : 'Erro ao deletar armazém');
    } finally {
      setLoading(false);
    }
  };

  const handleExcluirTodos = async () => {
    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-d467efec/armazens/all`,
        {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erro ao excluir armazéns');
      }

      const data = await response.json();
      onArmazensChange([]);
      setSuccess(`${data.deletados} armazéns excluídos com sucesso!`);
      setConfirmandoExclusaoTotal(false);
    } catch (err) {
      console.error('Erro ao excluir todos armazéns:', err);
      setError(err instanceof Error ? err.message : 'Erro ao excluir armazéns');
    } finally {
      setLoading(false);
    }
  };

  const handleUploadCSV = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      // Ler arquivo com encoding UTF-8 explícito
      const text = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result;
          if (typeof result === 'string') {
            resolve(result);
          } else {
            reject(new Error('Erro ao ler arquivo'));
          }
        };
        reader.onerror = () => reject(new Error('Erro ao ler arquivo'));
        // Ler como UTF-8 explicitamente
        reader.readAsText(file, 'UTF-8');
      });

      const armazensCSV = parseCSV(text);

      if (armazensCSV.length === 0) {
        throw new Error('Nenhum armazém válido encontrado no arquivo CSV');
      }

      // Upload em lote
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-d467efec/armazens/upload`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ armazens: armazensCSV }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erro ao fazer upload');
      }

      const data = await response.json();
      
      // Atualizar lista local
      onArmazensChange(armazensCSV);
      setSuccess(`${data.count} armazéns importados com sucesso!`);
    } catch (err) {
      console.error('Erro ao importar CSV:', err);
      setError(err instanceof Error ? err.message : 'Erro ao importar CSV');
    } finally {
      setLoading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDownloadCSV = () => {
    const csv = exportToCSV(armazens);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'armazens.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const iniciarNovoArmazem = () => {
    setNovoArmazem({
      cda: '',
      armazenador: '',
      endereco: '',
      municipio: '',
      uf: '',
      tipo: '',
      telefone: '',
      email: '',
      capacidade: 0,
      latitude: 0,
      longitude: 0,
    });
  };

  return (
    <div className="space-y-6">
      {/* Mensagens */}
      {error && (
        <div className="bg-[#dc2626] border-2 border-[#dc2626] rounded-lg p-4">
          <p className="text-white text-sm font-medium">{error}</p>
        </div>
      )}

      {success && (
        <div className="bg-green-500 bg-opacity-10 border-2 border-green-500 rounded-lg p-4">
          <p className="text-green-700 text-sm font-medium">{success}</p>
        </div>
      )}

      {/* Toolbar */}
      <div className="flex gap-3 flex-wrap">
        <Button
          onClick={iniciarNovoArmazem}
          className="bg-[#4ecdc4] hover:bg-[#5dd9c1] text-white"
          disabled={loading || novoArmazem !== null}
        >
          <Plus className="w-4 h-4 mr-2" />
          Novo Armazém
        </Button>

        <Button
          onClick={() => fileInputRef.current?.click()}
          variant="outline"
          className="border-2 border-[#4ecdc4] text-[#4ecdc4] hover:bg-[#4ecdc4] hover:text-white"
          disabled={loading}
        >
          <Upload className="w-4 h-4 mr-2" />
          Importar CSV
        </Button>

        <Button
          onClick={handleDownloadCSV}
          variant="outline"
          className="border-2 border-[#1a2332] text-[#1a2332] hover:bg-[#1a2332] hover:text-white"
          disabled={armazens.length === 0}
        >
          <Download className="w-4 h-4 mr-2" />
          Exportar CSV
        </Button>

        <Button
          onClick={() => setConfirmandoExclusaoTotal(true)}
          variant="outline"
          className="border-2 border-[#dc2626] text-[#dc2626] hover:bg-[#dc2626] hover:text-white"
          disabled={loading || armazens.length === 0}
        >
          <Trash2 className="w-4 h-4 mr-2" />
          Excluir Todos
        </Button>

        <input
          ref={fileInputRef}
          type="file"
          accept=".csv"
          onChange={handleUploadCSV}
          className="hidden"
        />

        <div className="ml-auto flex items-center gap-2 text-[#6b7280] text-sm">
          <Database className="w-4 h-4" />
          <span className="font-medium">{armazens.length} armazéns cadastrados</span>
        </div>
      </div>

      {/* Modal de Confirmação de Exclusão Total */}
      {confirmandoExclusaoTotal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="max-w-md w-full border-2 border-[#dc2626] shadow-2xl">
            <CardHeader className="bg-[#dc2626] text-white">
              <CardTitle className="flex items-center gap-2">
                <Trash2 className="w-6 h-6" />
                Confirmar Exclusão Total
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <p className="text-[#1a2332] font-semibold">
                Tem certeza que deseja excluir TODOS os {armazens.length} armazéns cadastrados?
              </p>
              <p className="text-[#6b7280] text-sm">
                ⚠️ Esta ação é irreversível e não pode ser desfeita!
              </p>
              
              <div className="flex gap-3 pt-4">
                <Button
                  onClick={() => setConfirmandoExclusaoTotal(false)}
                  variant="outline"
                  disabled={loading}
                  className="flex-1 border-2 border-[#6b7280] text-[#6b7280] hover:bg-[#6b7280] hover:text-white"
                >
                  <X className="w-4 h-4 mr-2" />
                  Cancelar
                </Button>
                <Button
                  onClick={handleExcluirTodos}
                  disabled={loading}
                  className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c] text-white"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Excluindo...
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-4 h-4 mr-2" />
                      Sim, Excluir Todos
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Formulário de Novo Armazém */}
      {novoArmazem && (
        <Card className="border-2 border-[#4ecdc4]">
          <CardHeader className="bg-[#4ecdc4] bg-opacity-10">
            <CardTitle className="text-[#1a2332] text-lg">Novo Armazém</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <FormularioArmazem
              armazem={novoArmazem}
              onChange={setNovoArmazem}
              onSalvar={() => handleSalvarArmazem(novoArmazem as Armazem)}
              onCancelar={() => setNovoArmazem(null)}
              loading={loading}
            />
          </CardContent>
        </Card>
      )}

      {/* Tabela de Armazéns */}
      <Card className="border-2 border-[#e0e4e8]">
        <CardHeader className="bg-[#1a2332] text-white rounded-t-lg">
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5 text-[#4ecdc4]" />
            Armazéns Cadastrados
          </CardTitle>
          <CardDescription className="text-[#e0e4e8]">
            CDA · Armazenador · Endereço · Município · UF · Tipo · Telefone · Email · Capacidade (t) · Latitude · Longitude
          </CardDescription>
          <div className="mt-3 bg-[#4ecdc4] bg-opacity-20 border border-[#4ecdc4] rounded-lg p-3">
            <p className="text-white text-xs font-medium">
              ℹ️ Formato CSV com codificação UTF-8, Latin-1 ou Windows-1252. Suporta acentuação brasileira (á, é, í, ó, ú, ã, õ, ç). Sistema detecta e corrige automaticamente problemas de encoding.
            </p>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-[#f5f6f8] border-b-2 border-[#e0e4e8]">
                <tr>
                  <th className="text-left p-3 text-[#1a2332] text-xs font-bold uppercase">CDA</th>
                  <th className="text-left p-3 text-[#1a2332] text-xs font-bold uppercase">Armazenador</th>
                  <th className="text-left p-3 text-[#1a2332] text-xs font-bold uppercase">Município</th>
                  <th className="text-left p-3 text-[#1a2332] text-xs font-bold uppercase">UF</th>
                  <th className="text-left p-3 text-[#1a2332] text-xs font-bold uppercase">Capacidade</th>
                  <th className="text-right p-3 text-[#1a2332] text-xs font-bold uppercase">Ações</th>
                </tr>
              </thead>
              <tbody>
                {armazens.length === 0 && (
                  <tr>
                    <td colSpan={6} className="text-center p-12 text-[#6b7280]">
                      <Database className="w-16 h-16 mx-auto mb-4 opacity-20" />
                      <p className="text-sm">Nenhum armazém cadastrado</p>
                      <p className="text-xs mt-2">Importe um CSV ou adicione manualmente</p>
                    </td>
                  </tr>
                )}

                {armazens.map((arm) => (
                  editando === arm.cda ? (
                    <tr key={arm.cda} className="border-b border-[#e0e4e8] bg-[#4ecdc4] bg-opacity-5">
                      <td colSpan={6} className="p-4">
                        <FormularioArmazem
                          armazem={arm}
                          onChange={(updated) => {
                            const index = armazens.findIndex(a => a.cda === arm.cda);
                            const novos = [...armazens];
                            novos[index] = { ...arm, ...updated };
                            onArmazensChange(novos);
                          }}
                          onSalvar={() => handleSalvarArmazem(arm)}
                          onCancelar={() => setEditando(null)}
                          loading={loading}
                        />
                      </td>
                    </tr>
                  ) : (
                    <tr key={arm.cda} className="border-b border-[#e0e4e8] hover:bg-[#f5f6f8]">
                      <td className="p-3 font-mono text-sm font-bold text-[#1a2332]">{arm.cda}</td>
                      <td className="p-3 text-sm text-[#1a2332]">{arm.armazenador}</td>
                      <td className="p-3 text-sm text-[#6b7280]">{arm.municipio}</td>
                      <td className="p-3 text-sm text-[#6b7280] font-bold">{arm.uf}</td>
                      <td className="p-3 text-sm text-[#6b7280]">{arm.capacidade.toLocaleString('pt-BR')} t</td>
                      <td className="p-3 text-right">
                        <div className="flex gap-2 justify-end">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setEditando(arm.cda)}
                            disabled={loading}
                            className="border-[#4ecdc4] text-[#4ecdc4] hover:bg-[#4ecdc4] hover:text-white"
                          >
                            <Edit2 className="w-3 h-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDeletarArmazem(arm.cda)}
                            disabled={loading}
                            className="border-[#dc2626] text-[#dc2626] hover:bg-[#dc2626] hover:text-white"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  )
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

interface FormularioArmazemProps {
  armazem: Partial<Armazem>;
  onChange: (armazem: Partial<Armazem>) => void;
  onSalvar: () => void;
  onCancelar: () => void;
  loading: boolean;
}

function FormularioArmazem({ armazem, onChange, onSalvar, onCancelar, loading }: FormularioArmazemProps) {
  const handleChange = (field: keyof Armazem, value: string | number) => {
    onChange({ ...armazem, [field]: value });
  };

  const isValid = armazem.cda && armazem.armazenador && armazem.municipio && armazem.uf;

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
      <div className="space-y-2">
        <Label className="text-[#1a2332] text-xs font-semibold uppercase">CDA *</Label>
        <Input
          value={armazem.cda || ''}
          onChange={(e) => handleChange('cda', e.target.value)}
          className="h-10 border-2 border-[#e0e4e8]"
          placeholder="Ex: MT-001"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-[#1a2332] text-xs font-semibold uppercase">Armazenador *</Label>
        <Input
          value={armazem.armazenador || ''}
          onChange={(e) => handleChange('armazenador', e.target.value)}
          className="h-10 border-2 border-[#e0e4e8]"
          placeholder="Nome do armazém"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-[#1a2332] text-xs font-semibold uppercase">Endereço</Label>
        <Input
          value={armazem.endereco || ''}
          onChange={(e) => handleChange('endereco', e.target.value)}
          className="h-10 border-2 border-[#e0e4e8]"
          placeholder="Rod. BR-163, Km 100"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-[#1a2332] text-xs font-semibold uppercase">Município *</Label>
        <Input
          value={armazem.municipio || ''}
          onChange={(e) => handleChange('municipio', e.target.value)}
          className="h-10 border-2 border-[#e0e4e8]"
          placeholder="Sinop"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-[#1a2332] text-xs font-semibold uppercase">UF *</Label>
        <Input
          value={armazem.uf || ''}
          onChange={(e) => handleChange('uf', e.target.value.toUpperCase())}
          className="h-10 border-2 border-[#e0e4e8]"
          placeholder="MT"
          maxLength={2}
        />
      </div>

      <div className="space-y-2">
        <Label className="text-[#1a2332] text-xs font-semibold uppercase">Tipo</Label>
        <Input
          value={armazem.tipo || ''}
          onChange={(e) => handleChange('tipo', e.target.value)}
          className="h-10 border-2 border-[#e0e4e8]"
          placeholder="Convencional"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-[#1a2332] text-xs font-semibold uppercase">Telefone</Label>
        <Input
          value={armazem.telefone || ''}
          onChange={(e) => handleChange('telefone', e.target.value)}
          className="h-10 border-2 border-[#e0e4e8]"
          placeholder="(66) 9999-9999"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-[#1a2332] text-xs font-semibold uppercase">Email</Label>
        <Input
          type="email"
          value={armazem.email || ''}
          onChange={(e) => handleChange('email', e.target.value)}
          className="h-10 border-2 border-[#e0e4e8]"
          placeholder="contato@armazem.com"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-[#1a2332] text-xs font-semibold uppercase">Capacidade (t)</Label>
        <Input
          type="number"
          value={armazem.capacidade || ''}
          onChange={(e) => handleChange('capacidade', parseFloat(e.target.value) || 0)}
          className="h-10 border-2 border-[#e0e4e8]"
          placeholder="50000"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-[#1a2332] text-xs font-semibold uppercase">Latitude</Label>
        <Input
          type="number"
          step="0.000001"
          value={armazem.latitude || ''}
          onChange={(e) => handleChange('latitude', parseFloat(e.target.value) || 0)}
          className="h-10 border-2 border-[#e0e4e8]"
          placeholder="-11.8644"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-[#1a2332] text-xs font-semibold uppercase">Longitude</Label>
        <Input
          type="number"
          step="0.000001"
          value={armazem.longitude || ''}
          onChange={(e) => handleChange('longitude', parseFloat(e.target.value) || 0)}
          className="h-10 border-2 border-[#e0e4e8]"
          placeholder="-55.5050"
        />
      </div>

      <div className="md:col-span-2 lg:col-span-3 flex gap-3 justify-end pt-4 border-t-2 border-[#e0e4e8]">
        <Button
          onClick={onCancelar}
          variant="outline"
          disabled={loading}
          className="border-2 border-[#6b7280] text-[#6b7280] hover:bg-[#6b7280] hover:text-white"
        >
          <X className="w-4 h-4 mr-2" />
          Cancelar
        </Button>
        <Button
          onClick={onSalvar}
          disabled={loading || !isValid}
          className="bg-[#4ecdc4] hover:bg-[#5dd9c1] text-white"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Salvando...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              Salvar
            </>
          )}
        </Button>
      </div>
    </div>
  );
}