import image_e36e3d7e57f0ae2a7d82a8bd2f2e8b237a8bc053 from 'figma:asset/e36e3d7e57f0ae2a7d82a8bd2f2e8b237a8bc053.png';
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Loader2, TrendingUp, Calculator, Settings, AlertTriangle } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import okenLogo from 'figma:asset/42abbaa2373dc0a620697ab3c75eb6a7a6b3f682.png';

interface CommodityConfig {
  nome: string;
  ticker: string;
  bushels_per_ton: number;
  peso_saca_kg: number;
  moeda_origem: string;
  moeda_destino: string;
}

interface ParidadeResult {
  commodity_usd_bu: number;
  cambio_usd_brl: number;
  paridade_porto_r_ton: number;
  preco_interior_r_ton: number;
  preco_produtor_r_saca: number;
}

interface MemoriaCalculo {
  commodity_nome: string;
  commodity_usd_bu: number;
  cambio_usd_brl: number;
  frete_r_ton: number;
  premio_cents: number;
  bushels_per_ton: number;
  sacas_per_ton: number;
  peso_saca_kg: number;
  commodity_usd_ton: number;
  premio_usd_ton: number;
  fob_usd_ton: number;
  paridade_porto_r_ton: number;
  preco_interior_r_ton: number;
  preco_produtor_r_saca: number;
}

const COMMODITIES_PRESET: Record<string, CommodityConfig> = {
  milho: {
    nome: 'Milho',
    ticker: 'ZC=F',
    bushels_per_ton: 39.368,
    peso_saca_kg: 60,
    moeda_origem: 'USD',
    moeda_destino: 'BRL',
  },
  soja: {
    nome: 'Soja',
    ticker: 'ZS=F',
    bushels_per_ton: 36.744,
    peso_saca_kg: 60,
    moeda_origem: 'USD',
    moeda_destino: 'BRL',
  },
  trigo: {
    nome: 'Trigo',
    ticker: 'ZW=F',
    bushels_per_ton: 36.744,
    peso_saca_kg: 60,
    moeda_origem: 'USD',
    moeda_destino: 'BRL',
  },
};

export function ParidadeOken() {
  const [commoditySelecionada, setCommoditySelecionada] = useState<string>('milho');
  const [config, setConfig] = useState<CommodityConfig>(COMMODITIES_PRESET.milho);
  const [freteRTon, setFreteRTon] = useState<string>('');
  const [premioCents, setPremioCents] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ParidadeResult | null>(null);
  const [memoriaCalculo, setMemoriaCalculo] = useState<MemoriaCalculo | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleCommodityChange = (commodity: string) => {
    setCommoditySelecionada(commodity);
    setConfig(COMMODITIES_PRESET[commodity]);
    setResult(null);
    setMemoriaCalculo(null);
    setError(null);
  };

  const handleConfigChange = (field: keyof CommodityConfig, value: string | number) => {
    setConfig(prev => ({ ...prev, [field]: value }));
  };

  const handleCalcular = async () => {
    setError(null);
    setResult(null);
    setMemoriaCalculo(null);

    if (!freteRTon || !premioCents) {
      setError('Por favor, preencha todos os campos.');
      return;
    }

    const frete = parseFloat(freteRTon);
    const premio = parseFloat(premioCents);

    if (isNaN(frete) || isNaN(premio)) {
      setError('Por favor, insira valores numéricos válidos.');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-d467efec/paridade-milho-yahoo`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({
            frete_r_ton: frete,
            premio_cents: premio,
            ticker: config.ticker,
            bushels_per_ton: config.bushels_per_ton,
            peso_saca_kg: config.peso_saca_kg,
          }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Erro na resposta da API:', errorData);
        throw new Error(errorData.error || 'Erro ao calcular paridade');
      }

      const data = await response.json();
      console.log('Resultado da paridade:', data);
      setResult(data);

      const BUSHELS_PER_TON = config.bushels_per_ton;
      const SACAS_PER_TON = 1000 / config.peso_saca_kg;
      
      const commodity_usd_ton = data.commodity_usd_bu * BUSHELS_PER_TON;
      const premio_usd_ton = (premio / 100) * BUSHELS_PER_TON;
      const fob_usd_ton = commodity_usd_ton + premio_usd_ton;
      
      setMemoriaCalculo({
        commodity_nome: config.nome,
        commodity_usd_bu: data.commodity_usd_bu,
        cambio_usd_brl: data.cambio_usd_brl,
        frete_r_ton: frete,
        premio_cents: premio,
        bushels_per_ton: BUSHELS_PER_TON,
        sacas_per_ton: SACAS_PER_TON,
        peso_saca_kg: config.peso_saca_kg,
        commodity_usd_ton,
        premio_usd_ton,
        fob_usd_ton,
        paridade_porto_r_ton: data.paridade_porto_r_ton,
        preco_interior_r_ton: data.preco_interior_r_ton,
        preco_produtor_r_saca: data.preco_produtor_r_saca,
      });
    } catch (err) {
      console.error('Erro ao calcular paridade:', err);
      setError(
        err instanceof Error
          ? err.message
          : 'Erro ao conectar com o servidor. Tente novamente.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f5f6f8]">
      {/* Header Oken - Azul escuro institucional */}
      <div className="bg-gradient-to-r from-[#1a2332] to-[#2c3e50] shadow-lg">
        <div className="max-w-7xl mx-auto px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-semibold text-white tracking-tight">
                Calculadora de Paridade de Exportação
              </h1>
              <p className="text-[#4ecdc4] text-sm font-medium mt-1 tracking-wide">
                COMMODITIES AGRÍCOLAS · TEMPO REAL
              </p>
            </div>
            <img 
              src={image_e36e3d7e57f0ae2a7d82a8bd2f2e8b237a8bc053} 
              alt="Oken" 
              className="h-14 w-auto ml-8"
            />
          </div>
        </div>
      </div>

      {/* Conteúdo Principal */}
      <div className="max-w-7xl mx-auto px-8 py-10">
        <Tabs defaultValue="calculo" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8 bg-white border-2 border-[#e0e4e8] p-1 h-auto">
            <TabsTrigger 
              value="calculo" 
              className="flex items-center gap-2 py-3 px-6 text-[#6b7280] data-[state=active]:bg-[#4ecdc4] data-[state=active]:text-white data-[state=active]:shadow-md transition-all"
            >
              <Calculator className="w-5 h-5" />
              <span className="font-semibold text-sm uppercase tracking-wide">Cálculo</span>
            </TabsTrigger>
            <TabsTrigger 
              value="parametros" 
              className="flex items-center gap-2 py-3 px-6 text-[#6b7280] data-[state=active]:bg-[#4ecdc4] data-[state=active]:text-white data-[state=active]:shadow-md transition-all"
            >
              <Settings className="w-5 h-5" />
              <span className="font-semibold text-sm uppercase tracking-wide">Parâmetros</span>
            </TabsTrigger>
            <TabsTrigger 
              value="resultados" 
              className="flex items-center gap-2 py-3 px-6 text-[#6b7280] data-[state=active]:bg-[#4ecdc4] data-[state=active]:text-white data-[state=active]:shadow-md transition-all"
            >
              <TrendingUp className="w-5 h-5" />
              <span className="font-semibold text-sm uppercase tracking-wide">Memória</span>
            </TabsTrigger>
          </TabsList>

          {/* ABA: CÁLCULO */}
          <TabsContent value="calculo">
            <div className="grid lg:grid-cols-5 gap-6">
              {/* Card de Entrada - 2 colunas */}
              <Card className="lg:col-span-2 border-2 border-[#e0e4e8] shadow-sm">
                <CardHeader className="bg-[#1a2332] text-white rounded-t-lg">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Calculator className="w-5 h-5 text-[#4ecdc4]" />
                    Parâmetros de Entrada
                  </CardTitle>
                  <CardDescription className="text-[#e0e4e8]">
                    Dados da operação
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  {/* Seleção de Commodity */}
                  <div className="space-y-2">
                    <Label className="text-[#1a2332] font-semibold text-sm uppercase tracking-wide">
                      Commodity
                    </Label>
                    <Select value={commoditySelecionada} onValueChange={handleCommodityChange}>
                      <SelectTrigger className="h-12 border-2 border-[#e0e4e8] bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="milho">🌽 Milho</SelectItem>
                        <SelectItem value="soja">🫘 Soja</SelectItem>
                        <SelectItem value="trigo">🌾 Trigo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Frete */}
                  <div className="space-y-2">
                    <Label className="text-[#1a2332] font-semibold text-sm uppercase tracking-wide">
                      Frete (R$/ton)
                    </Label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="150.00"
                      value={freteRTon}
                      onChange={(e) => setFreteRTon(e.target.value)}
                      className="h-12 border-2 border-[#e0e4e8] font-mono text-lg"
                    />
                  </div>

                  {/* Prêmio */}
                  <div className="space-y-2">
                    <Label className="text-[#1a2332] font-semibold text-sm uppercase tracking-wide">
                      Prêmio (¢/bushel)
                    </Label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="50.00"
                      value={premioCents}
                      onChange={(e) => setPremioCents(e.target.value)}
                      className="h-12 border-2 border-[#e0e4e8] font-mono text-lg"
                    />
                  </div>

                  {/* Botão Calcular */}
                  <Button
                    onClick={handleCalcular}
                    disabled={loading}
                    className="w-full h-14 bg-[#4ecdc4] hover:bg-[#5dd9c1] text-white font-semibold text-base uppercase tracking-wide shadow-lg"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Processando...
                      </>
                    ) : (
                      <>
                        <Calculator className="mr-2 h-5 w-5" />
                        Calcular Paridade
                      </>
                    )}
                  </Button>

                  {error && (
                    <div className="bg-[#dc2626] border-2 border-[#dc2626] rounded-lg p-4 flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-white flex-shrink-0 mt-0.5" />
                      <p className="text-white text-sm font-medium">{error}</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Card de Resultados - 3 colunas */}
              <Card className="lg:col-span-3 border-2 border-[#e0e4e8] shadow-sm">
                <CardHeader className="bg-[#1a2332] text-white rounded-t-lg">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <TrendingUp className="w-5 h-5 text-[#4ecdc4]" />
                    Resultados Calculados
                  </CardTitle>
                  <CardDescription className="text-[#e0e4e8]">
                    Valores com base em dados de mercado em tempo real
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  {!result && !error && (
                    <div className="flex flex-col items-center justify-center py-16 text-[#6b7280]">
                      <TrendingUp className="w-20 h-20 mb-4 opacity-20" />
                      <p className="text-sm uppercase tracking-wide">Aguardando cálculo</p>
                    </div>
                  )}

                  {result && (
                    <div className="space-y-5">
                      {/* Alerta de Sanidade */}
                      {result.preco_produtor_r_saca > 500 && (
                        <div className="bg-yellow-50 border-2 border-yellow-500 rounded-lg p-4 flex items-start gap-3">
                          <AlertTriangle className="w-6 h-6 text-yellow-600 flex-shrink-0" />
                          <div>
                            <p className="font-bold text-yellow-900 text-sm uppercase tracking-wide">Alerta de Mercado</p>
                            <p className="text-sm text-yellow-800 mt-1">
                              Valor acima do padrão (R$ {result.preco_produtor_r_saca.toFixed(2)}/saca). Verificar parâmetros.
                            </p>
                          </div>
                        </div>
                      )}

                      {/* Destaque Principal - Verde-água Oken */}
                      <div className="bg-gradient-to-br from-[#4ecdc4] to-[#5dd9c1] rounded-xl p-8 text-center shadow-lg">
                        <p className="text-white text-xs font-bold uppercase tracking-widest mb-2">
                          PREÇO AO PRODUTOR
                        </p>
                        <p className="text-white text-6xl font-bold mb-2 tracking-tight">
                          {result.preco_produtor_r_saca.toFixed(2)}
                        </p>
                        <p className="text-white text-sm font-medium uppercase tracking-wide">
                          R$ / SACA 60KG
                        </p>
                      </div>

                      {/* Grid de Valores Intermediários */}
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="bg-[#f5f6f8] border-2 border-[#e0e4e8] rounded-lg p-5">
                          <p className="text-[#6b7280] text-xs font-bold uppercase tracking-wide mb-2">
                            Preço no Interior
                          </p>
                          <p className="text-[#1a2332] text-3xl font-bold">
                            {result.preco_interior_r_ton.toFixed(2)}
                          </p>
                          <p className="text-[#6b7280] text-sm font-medium mt-1">R$ / tonelada</p>
                        </div>

                        <div className="bg-[#f5f6f8] border-2 border-[#e0e4e8] rounded-lg p-5">
                          <p className="text-[#6b7280] text-xs font-bold uppercase tracking-wide mb-2">
                            Paridade Porto
                          </p>
                          <p className="text-[#1a2332] text-3xl font-bold">
                            {result.paridade_porto_r_ton.toFixed(2)}
                          </p>
                          <p className="text-[#6b7280] text-sm font-medium mt-1">R$ / tonelada</p>
                        </div>
                      </div>

                      {/* Dados de Mercado */}
                      <div className="border-t-2 border-[#e0e4e8] pt-5">
                        <p className="text-[#6b7280] text-xs font-bold uppercase tracking-wider mb-3">
                          Dados de Mercado
                        </p>
                        <div className="grid md:grid-cols-2 gap-3">
                          <div className="flex justify-between items-center p-3 bg-[#f5f6f8] rounded-lg">
                            <span className="text-[#6b7280] text-sm font-medium">
                              {config.nome} ({config.ticker})
                            </span>
                            <span className="text-[#1a2332] font-bold font-mono">
                              ${result.commodity_usd_bu.toFixed(4)}/bu
                            </span>
                          </div>
                          <div className="flex justify-between items-center p-3 bg-[#f5f6f8] rounded-lg">
                            <span className="text-[#6b7280] text-sm font-medium">
                              Câmbio USD/BRL
                            </span>
                            <span className="text-[#1a2332] font-bold font-mono">
                              R$ {result.cambio_usd_brl.toFixed(4)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* ABA: PARÂMETROS */}
          <TabsContent value="parametros">
            <Card className="border-2 border-[#e0e4e8] shadow-sm">
              <CardHeader className="bg-[#1a2332] text-white rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5 text-[#4ecdc4]" />
                  Configuração Avançada
                </CardTitle>
                <CardDescription className="text-[#e0e4e8]">
                  Defina taxas de conversão e unidades de medida
                </CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <Label className="text-[#1a2332] font-semibold uppercase text-sm tracking-wide">
                      Ticker Yahoo Finance
                    </Label>
                    <Input
                      type="text"
                      value={config.ticker}
                      onChange={(e) => handleConfigChange('ticker', e.target.value)}
                      className="h-12 border-2 border-[#e0e4e8] font-mono text-lg"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label className="text-[#1a2332] font-semibold uppercase text-sm tracking-wide">
                      Bushels por Tonelada
                    </Label>
                    <Input
                      type="number"
                      step="0.001"
                      value={config.bushels_per_ton}
                      onChange={(e) => handleConfigChange('bushels_per_ton', parseFloat(e.target.value))}
                      className="h-12 border-2 border-[#e0e4e8] font-mono text-lg"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label className="text-[#1a2332] font-semibold uppercase text-sm tracking-wide">
                      Peso da Saca (kg)
                    </Label>
                    <Input
                      type="number"
                      value={config.peso_saca_kg}
                      onChange={(e) => handleConfigChange('peso_saca_kg', parseFloat(e.target.value))}
                      className="h-12 border-2 border-[#e0e4e8] font-mono text-lg"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label className="text-[#1a2332] font-semibold uppercase text-sm tracking-wide">
                      Par de Moedas
                    </Label>
                    <div className="flex gap-2 items-center">
                      <Input
                        type="text"
                        value={config.moeda_origem}
                        onChange={(e) => handleConfigChange('moeda_origem', e.target.value)}
                        className="h-12 border-2 border-[#e0e4e8] font-mono"
                      />
                      <span className="text-[#4ecdc4] font-bold">→</span>
                      <Input
                        type="text"
                        value={config.moeda_destino}
                        onChange={(e) => handleConfigChange('moeda_destino', e.target.value)}
                        className="h-12 border-2 border-[#e0e4e8] font-mono"
                      />
                    </div>
                  </div>
                </div>

                {/* Resumo de Configuração */}
                <div className="mt-8 bg-[#4ecdc4] bg-opacity-10 border-2 border-[#4ecdc4] rounded-lg p-6">
                  <h3 className="text-[#1a2332] font-bold text-sm uppercase tracking-wide mb-4">
                    Resumo da Configuração
                  </h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <p className="text-[#6b7280] text-xs uppercase tracking-wider mb-1">Commodity</p>
                      <p className="text-[#1a2332] font-bold">{config.nome}</p>
                    </div>
                    <div>
                      <p className="text-[#6b7280] text-xs uppercase tracking-wider mb-1">Ticker</p>
                      <p className="text-[#1a2332] font-mono font-bold">{config.ticker}</p>
                    </div>
                    <div>
                      <p className="text-[#6b7280] text-xs uppercase tracking-wider mb-1">Conversão</p>
                      <p className="text-[#1a2332] font-bold">{config.bushels_per_ton} bu/ton</p>
                    </div>
                    <div>
                      <p className="text-[#6b7280] text-xs uppercase tracking-wider mb-1">Peso Saca</p>
                      <p className="text-[#1a2332] font-bold">{config.peso_saca_kg} kg</p>
                    </div>
                    <div>
                      <p className="text-[#6b7280] text-xs uppercase tracking-wider mb-1">Sacas/Ton</p>
                      <p className="text-[#1a2332] font-bold">{(1000 / config.peso_saca_kg).toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-[#6b7280] text-xs uppercase tracking-wider mb-1">Moedas</p>
                      <p className="text-[#1a2332] font-bold">{config.moeda_origem} → {config.moeda_destino}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ABA: MEMÓRIA DE CÁLCULO */}
          <TabsContent value="resultados">
            {!memoriaCalculo && (
              <Card className="border-2 border-[#e0e4e8]">
                <CardContent className="flex flex-col items-center justify-center py-20 text-[#6b7280]">
                  <Calculator className="w-20 h-20 mb-4 opacity-20" />
                  <p className="text-sm uppercase tracking-wide">Realize um cálculo para visualizar a memória detalhada</p>
                </CardContent>
              </Card>
            )}

            {memoriaCalculo && (
              <div className="space-y-6">
                {/* Card Principal de Memória */}
                <Card className="border-2 border-[#4ecdc4] shadow-lg">
                  <CardHeader className="bg-gradient-to-r from-[#1a2332] to-[#2c3e50] text-white rounded-t-lg">
                    <CardTitle className="flex items-center gap-2 text-xl">
                      <Calculator className="w-6 h-6 text-[#4ecdc4]" />
                      Memória de Cálculo Detalhada
                    </CardTitle>
                    <CardDescription className="text-[#e0e4e8]">
                      Passo a passo completo do cálculo de paridade
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-8 space-y-8">
                    {/* Passo 1 */}
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <span className="flex items-center justify-center w-10 h-10 rounded-full bg-[#4ecdc4] text-white font-bold text-lg">1</span>
                        <h3 className="text-[#1a2332] font-bold text-lg">Dados de Mercado</h3>
                      </div>
                      <div className="bg-[#f5f6f8] border-2 border-[#e0e4e8] rounded-lg p-5 space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-[#6b7280] font-medium">Cotação {memoriaCalculo.commodity_nome} CBOT ({config.ticker})</span>
                          <span className="text-[#1a2332] font-mono font-bold text-lg">
                            ${memoriaCalculo.commodity_usd_bu.toFixed(4)} USD/bu
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-[#6b7280] font-medium">Câmbio USD/BRL</span>
                          <span className="text-[#1a2332] font-mono font-bold text-lg">
                            R$ {memoriaCalculo.cambio_usd_brl.toFixed(4)}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-[#6b7280] font-medium">Prêmio</span>
                          <span className="text-[#1a2332] font-mono font-bold text-lg">
                            {memoriaCalculo.premio_cents.toFixed(2)} ¢/bu
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-[#6b7280] font-medium">Frete</span>
                          <span className="text-[#1a2332] font-mono font-bold text-lg">
                            R$ {memoriaCalculo.frete_r_ton.toFixed(2)}/ton
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Passo 2 */}
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <span className="flex items-center justify-center w-10 h-10 rounded-full bg-[#4ecdc4] text-white font-bold text-lg">2</span>
                        <h3 className="text-[#1a2332] font-bold text-lg">Conversão: USD/bu → USD/ton</h3>
                      </div>
                      <div className="bg-[#4ecdc4] bg-opacity-5 border-2 border-[#4ecdc4] rounded-lg p-5">
                        <p className="text-[#1a2332] font-semibold mb-3">
                          Fórmula: Preço (USD/ton) = Preço (USD/bu) × {memoriaCalculo.bushels_per_ton}
                        </p>
                        <div className="bg-white rounded-lg p-4">
                          <p className="text-[#1a2332] font-mono font-bold text-xl">
                            ${memoriaCalculo.commodity_usd_bu.toFixed(4)} × {memoriaCalculo.bushels_per_ton} = ${memoriaCalculo.commodity_usd_ton.toFixed(2)} USD/ton
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Passo 3 */}
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <span className="flex items-center justify-center w-10 h-10 rounded-full bg-[#4ecdc4] text-white font-bold text-lg">3</span>
                        <h3 className="text-[#1a2332] font-bold text-lg">Conversão: Prêmio</h3>
                      </div>
                      <div className="bg-[#4ecdc4] bg-opacity-5 border-2 border-[#4ecdc4] rounded-lg p-5">
                        <p className="text-[#1a2332] font-semibold mb-3">
                          Fórmula: Prêmio (USD/ton) = (Prêmio ¢/bu ÷ 100) × {memoriaCalculo.bushels_per_ton}
                        </p>
                        <div className="bg-white rounded-lg p-4">
                          <p className="text-[#1a2332] font-mono font-bold text-xl">
                            ({memoriaCalculo.premio_cents.toFixed(2)} ÷ 100) × {memoriaCalculo.bushels_per_ton} = ${memoriaCalculo.premio_usd_ton.toFixed(2)} USD/ton
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Passo 4 */}
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <span className="flex items-center justify-center w-10 h-10 rounded-full bg-[#4ecdc4] text-white font-bold text-lg">4</span>
                        <h3 className="text-[#1a2332] font-bold text-lg">Cálculo: FOB</h3>
                      </div>
                      <div className="bg-[#4ecdc4] bg-opacity-5 border-2 border-[#4ecdc4] rounded-lg p-5">
                        <p className="text-[#1a2332] font-semibold mb-3">
                          Fórmula: FOB = Preço Commodity + Prêmio
                        </p>
                        <div className="bg-white rounded-lg p-4">
                          <p className="text-[#1a2332] font-mono font-bold text-xl">
                            ${memoriaCalculo.commodity_usd_ton.toFixed(2)} + ${memoriaCalculo.premio_usd_ton.toFixed(2)} = ${memoriaCalculo.fob_usd_ton.toFixed(2)} USD/ton
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Passo 5 */}
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <span className="flex items-center justify-center w-10 h-10 rounded-full bg-[#4ecdc4] text-white font-bold text-lg">5</span>
                        <h3 className="text-[#1a2332] font-bold text-lg">Conversão: Paridade Porto</h3>
                      </div>
                      <div className="bg-[#4ecdc4] bg-opacity-5 border-2 border-[#4ecdc4] rounded-lg p-5">
                        <p className="text-[#1a2332] font-semibold mb-3">
                          Fórmula: Paridade Porto (BRL/ton) = FOB (USD/ton) × Câmbio
                        </p>
                        <div className="bg-white rounded-lg p-4">
                          <p className="text-[#1a2332] font-mono font-bold text-xl">
                            ${memoriaCalculo.fob_usd_ton.toFixed(2)} × R$ {memoriaCalculo.cambio_usd_brl.toFixed(4)} = R$ {memoriaCalculo.paridade_porto_r_ton.toFixed(2)}/ton
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Passo 6 */}
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <span className="flex items-center justify-center w-10 h-10 rounded-full bg-[#4ecdc4] text-white font-bold text-lg">6</span>
                        <h3 className="text-[#1a2332] font-bold text-lg">Cálculo: Preço Interior</h3>
                      </div>
                      <div className="bg-[#4ecdc4] bg-opacity-5 border-2 border-[#4ecdc4] rounded-lg p-5">
                        <p className="text-[#1a2332] font-semibold mb-3">
                          Fórmula: Preço Interior = Paridade Porto - Frete
                        </p>
                        <div className="bg-white rounded-lg p-4">
                          <p className="text-[#1a2332] font-mono font-bold text-xl">
                            R$ {memoriaCalculo.paridade_porto_r_ton.toFixed(2)} - R$ {memoriaCalculo.frete_r_ton.toFixed(2)} = R$ {memoriaCalculo.preco_interior_r_ton.toFixed(2)}/ton
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Passo 7 - Resultado Final */}
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <span className="flex items-center justify-center w-10 h-10 rounded-full bg-[#4ecdc4] text-white font-bold text-lg">7</span>
                        <h3 className="text-[#1a2332] font-bold text-lg">Conversão Final: Preço ao Produtor</h3>
                      </div>
                      <div className="bg-gradient-to-br from-[#4ecdc4] to-[#5dd9c1] border-2 border-[#4ecdc4] rounded-lg p-6">
                        <p className="text-white font-semibold text-lg mb-3">
                          Fórmula: Preço (R$/saca) = Preço (R$/ton) ÷ {memoriaCalculo.sacas_per_ton.toFixed(4)}
                        </p>
                        <div className="bg-white rounded-lg p-5 text-center">
                          <p className="text-[#1a2332] font-mono font-bold text-2xl mb-2">
                            R$ {memoriaCalculo.preco_interior_r_ton.toFixed(2)} ÷ {memoriaCalculo.sacas_per_ton.toFixed(4)} = R$ {memoriaCalculo.preco_produtor_r_saca.toFixed(2)}/saca
                          </p>
                          <p className="text-[#6b7280] text-sm font-medium">
                            Fator: 1 tonelada = {memoriaCalculo.sacas_per_ton.toFixed(2)} sacas de {memoriaCalculo.peso_saca_kg}kg
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Resultado Destacado */}
                    <div className="bg-gradient-to-r from-[#1a2332] to-[#2c3e50] rounded-xl p-8 text-center">
                      <p className="text-[#4ecdc4] text-xs font-bold uppercase tracking-widest mb-2">
                        RESULTADO FINAL
                      </p>
                      <p className="text-white text-5xl font-bold mb-2">
                        R$ {memoriaCalculo.preco_produtor_r_saca.toFixed(2)}
                      </p>
                      <p className="text-white text-sm font-medium uppercase tracking-wide">
                        por saca de {memoriaCalculo.peso_saca_kg}kg
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer com logo Oken */}
      <div className="bg-white border-t-2 border-[#e0e4e8] mt-16">
        <div className="max-w-7xl mx-auto px-8 py-6 flex items-center justify-between">
          <p className="text-[#6b7280] text-sm">
            © 2024 Oken. Todos os direitos reservados.
          </p>
          <img 
            src={okenLogo} 
            alt="Oken" 
            className="h-8 w-auto opacity-60"
          />
        </div>
      </div>
    </div>
  );
}