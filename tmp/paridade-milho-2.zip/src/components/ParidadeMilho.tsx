import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Loader2, TrendingUp, Calculator, Settings } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import okenLogo from 'figma:asset/42abbaa2373dc0a620697ab3c75eb6a7a6b3f682.png';

interface CommodityConfig {
  nome: string;
  ticker: string;
  bushels_per_ton: number;
  peso_saca_kg: number;
  moeda_origem: string;
  moeda_destino: string;
}

interface ParidadeResult {
  commodity_usd_bu: number;
  cambio_usd_brl: number;
  paridade_porto_r_ton: number;
  preco_interior_r_ton: number;
  preco_produtor_r_saca: number;
}

interface MemoriaCalculo {
  // Configurações
  commodity_nome: string;
  commodity_usd_bu: number;
  cambio_usd_brl: number;
  frete_r_ton: number;
  premio_cents: number;
  
  // Conversões
  bushels_per_ton: number;
  sacas_per_ton: number;
  peso_saca_kg: number;
  commodity_usd_ton: number;
  premio_usd_ton: number;
  fob_usd_ton: number;
  paridade_porto_r_ton: number;
  preco_interior_r_ton: number;
  preco_produtor_r_saca: number;
}

// Configurações pré-definidas de commodities
const COMMODITIES_PRESET: Record<string, CommodityConfig> = {
  milho: {
    nome: 'Milho',
    ticker: 'ZC=F',
    bushels_per_ton: 39.368,
    peso_saca_kg: 60,
    moeda_origem: 'USD',
    moeda_destino: 'BRL',
  },
  soja: {
    nome: 'Soja',
    ticker: 'ZS=F',
    bushels_per_ton: 36.744,
    peso_saca_kg: 60,
    moeda_origem: 'USD',
    moeda_destino: 'BRL',
  },
  trigo: {
    nome: 'Trigo',
    ticker: 'ZW=F',
    bushels_per_ton: 36.744,
    peso_saca_kg: 60,
    moeda_origem: 'USD',
    moeda_destino: 'BRL',
  },
};

export function ParidadeMilho() {
  // Estados de configuração
  const [commoditySelecionada, setCommoditySelecionada] = useState<string>('milho');
  const [config, setConfig] = useState<CommodityConfig>(COMMODITIES_PRESET.milho);
  
  // Estados do cálculo
  const [freteRTon, setFreteRTon] = useState<string>('');
  const [premioCents, setPremioCents] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ParidadeResult | null>(null);
  const [memoriaCalculo, setMemoriaCalculo] = useState<MemoriaCalculo | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Atualizar configuração ao mudar commodity
  const handleCommodityChange = (commodity: string) => {
    setCommoditySelecionada(commodity);
    setConfig(COMMODITIES_PRESET[commodity]);
    // Limpar resultados ao trocar commodity
    setResult(null);
    setMemoriaCalculo(null);
    setError(null);
  };

  // Atualizar parâmetros customizados
  const handleConfigChange = (field: keyof CommodityConfig, value: string | number) => {
    setConfig(prev => ({
      ...prev,
      [field]: value,
    }));
  };

  // IMPORTANTE: Esta função só é executada quando o usuário clica no botão "Calcular Paridade"
  // Nenhuma requisição é feita automaticamente no carregamento ou em background
  const handleCalcular = async () => {
    // Limpar resultados anteriores
    setError(null);
    setResult(null);
    setMemoriaCalculo(null);

    // Validação básica dos inputs
    if (!freteRTon || !premioCents) {
      setError('Por favor, preencha todos os campos.');
      return;
    }

    const frete = parseFloat(freteRTon);
    const premio = parseFloat(premioCents);

    if (isNaN(frete) || isNaN(premio)) {
      setError('Por favor, insira valores numéricos válidos.');
      return;
    }

    // Iniciar loading apenas quando o usuário solicitar o cálculo
    setLoading(true);

    try {
      // REQUISIÇÃO SOB DEMANDA: Esta chamada ao backend só acontece aqui,
      // quando o usuário clica explicitamente no botão
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-d467efec/paridade-milho-yahoo`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({
            frete_r_ton: frete,
            premio_cents: premio,
            ticker: config.ticker,
            bushels_per_ton: config.bushels_per_ton,
            peso_saca_kg: config.peso_saca_kg,
          }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Erro na resposta da API:', errorData);
        throw new Error(errorData.error || 'Erro ao calcular paridade');
      }

      const data = await response.json();
      console.log('Resultado da paridade:', data);
      setResult(data);

      // Calcular memória de cálculo completa
      const BUSHELS_PER_TON = config.bushels_per_ton;
      const SACAS_PER_TON = 1000 / config.peso_saca_kg;
      
      const commodity_usd_ton = data.commodity_usd_bu * BUSHELS_PER_TON;
      const premio_usd_ton = (premio / 100) * BUSHELS_PER_TON;
      const fob_usd_ton = commodity_usd_ton + premio_usd_ton;
      
      setMemoriaCalculo({
        commodity_nome: config.nome,
        commodity_usd_bu: data.commodity_usd_bu,
        cambio_usd_brl: data.cambio_usd_brl,
        frete_r_ton: frete,
        premio_cents: premio,
        bushels_per_ton: BUSHELS_PER_TON,
        sacas_per_ton: SACAS_PER_TON,
        peso_saca_kg: config.peso_saca_kg,
        commodity_usd_ton: commodity_usd_ton,
        premio_usd_ton: premio_usd_ton,
        fob_usd_ton: fob_usd_ton,
        paridade_porto_r_ton: data.paridade_porto_r_ton,
        preco_interior_r_ton: data.preco_interior_r_ton,
        preco_produtor_r_saca: data.preco_produtor_r_saca,
      });
    } catch (err) {
      console.error('Erro ao calcular paridade do milho:', err);
      setError(
        err instanceof Error
          ? err.message
          : 'Erro ao conectar com o servidor. Tente novamente.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f5f6f8]">
      {/* Header Institucional Oken */}
      <div className="bg-gradient-to-r from-[#1a2332] to-[#2c3e50] border-b border-[#e0e4e8]">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-white mb-1">
                Calculadora de Paridade de Exportação
              </h1>
              <p className="text-[#4ecdc4] text-sm font-medium">
                Commodities Agrícolas · Dados em Tempo Real
              </p>
            </div>
            <div className="flex items-center gap-6">
              <img 
                src={okenLogo} 
                alt="Oken" 
                className="h-12 w-auto"
                style={{ objectFit: 'contain' }}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <Tabs defaultValue="calculo" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6 bg-white border border-[#e0e4e8]">
            <TabsTrigger 
              value="calculo" 
              className="flex items-center gap-2 data-[state=active]:bg-[#4ecdc4] data-[state=active]:text-white"
            >
              <Calculator className="w-4 h-4" />
              <span className="font-medium">Cálculo</span>
            </TabsTrigger>
            <TabsTrigger 
              value="parametros" 
              className="flex items-center gap-2 data-[state=active]:bg-[#4ecdc4] data-[state=active]:text-white"
            >
              <Settings className="w-4 h-4" />
              <span className="font-medium">Parâmetros</span>
            </TabsTrigger>
            <TabsTrigger 
              value="resultados" 
              className="flex items-center gap-2 data-[state=active]:bg-[#4ecdc4] data-[state=active]:text-white"
            >
              <TrendingUp className="w-4 h-4" />
              <span className="font-medium">Memória de Cálculo</span>
            </TabsTrigger>
          </TabsList>

          {/* ABA 1: PARÂMETROS */}
          <TabsContent value="parametros">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-green-800 flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Configuração de Parâmetros
                </CardTitle>
                <CardDescription>
                  Configure a commodity, taxas de conversão e unidades de medida
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Seleção de Commodity */}
                <div className="space-y-2">
                  <Label htmlFor="commodity" className="text-base font-semibold">
                    Commodity
                  </Label>
                  <Select value={commoditySelecionada} onValueChange={handleCommodityChange}>
                    <SelectTrigger className="text-lg">
                      <SelectValue placeholder="Selecione a commodity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="milho">🌽 Milho</SelectItem>
                      <SelectItem value="soja">🫘 Soja</SelectItem>
                      <SelectItem value="trigo">🌾 Trigo</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-gray-500">
                    Commodity agrícola para cálculo de paridade
                  </p>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  {/* Ticker Yahoo Finance */}
                  <div className="space-y-2">
                    <Label htmlFor="ticker" className="text-base font-semibold">
                      Ticker Yahoo Finance
                    </Label>
                    <Input
                      id="ticker"
                      type="text"
                      value={config.ticker}
                      onChange={(e) => handleConfigChange('ticker', e.target.value)}
                      className="text-lg font-mono"
                    />
                    <p className="text-sm text-gray-500">
                      Símbolo da commodity (ex: ZC=F para milho)
                    </p>
                  </div>

                  {/* Bushels por Tonelada */}
                  <div className="space-y-2">
                    <Label htmlFor="bushels" className="text-base font-semibold">
                      Bushels por Tonelada
                    </Label>
                    <Input
                      id="bushels"
                      type="number"
                      step="0.001"
                      value={config.bushels_per_ton}
                      onChange={(e) => handleConfigChange('bushels_per_ton', parseFloat(e.target.value))}
                      className="text-lg"
                    />
                    <p className="text-sm text-gray-500">
                      Fator de conversão bushels → tonelada
                    </p>
                  </div>

                  {/* Peso da Saca */}
                  <div className="space-y-2">
                    <Label htmlFor="peso-saca" className="text-base font-semibold">
                      Peso da Saca (kg)
                    </Label>
                    <Input
                      id="peso-saca"
                      type="number"
                      step="1"
                      value={config.peso_saca_kg}
                      onChange={(e) => handleConfigChange('peso_saca_kg', parseFloat(e.target.value))}
                      className="text-lg"
                    />
                    <p className="text-sm text-gray-500">
                      Peso padrão da saca em quilogramas
                    </p>
                  </div>

                  {/* Moedas */}
                  <div className="space-y-2">
                    <Label className="text-base font-semibold">
                      Moedas
                    </Label>
                    <div className="flex gap-2 items-center">
                      <Input
                        type="text"
                        value={config.moeda_origem}
                        onChange={(e) => handleConfigChange('moeda_origem', e.target.value)}
                        className="text-lg"
                        placeholder="USD"
                      />
                      <span className="text-gray-500">→</span>
                      <Input
                        type="text"
                        value={config.moeda_destino}
                        onChange={(e) => handleConfigChange('moeda_destino', e.target.value)}
                        className="text-lg"
                        placeholder="BRL"
                      />
                    </div>
                    <p className="text-sm text-gray-500">
                      Conversão de moeda (origem → destino)
                    </p>
                  </div>
                </div>

                {/* Card de Resumo dos Parâmetros */}
                <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4 mt-6">
                  <h3 className="font-bold text-blue-900 mb-3">📋 Resumo da Configuração</h3>
                  <div className="grid md:grid-cols-2 gap-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-700">Commodity:</span>
                      <span className="font-semibold text-gray-900">{config.nome}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Ticker:</span>
                      <span className="font-mono font-semibold text-gray-900">{config.ticker}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Conversão:</span>
                      <span className="font-semibold text-gray-900">{config.bushels_per_ton} bu/ton</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Peso da saca:</span>
                      <span className="font-semibold text-gray-900">{config.peso_saca_kg} kg</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Sacas por ton:</span>
                      <span className="font-semibold text-gray-900">{(1000 / config.peso_saca_kg).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Moedas:</span>
                      <span className="font-semibold text-gray-900">{config.moeda_origem} → {config.moeda_destino}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ABA 2: CÁLCULO */}
          <TabsContent value="calculo">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Card de Entrada */}
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="text-green-800">Parâmetros de Cálculo</CardTitle>
                  <CardDescription>
                    Insira o frete e o prêmio para calcular a paridade
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="frete" className="text-base font-semibold">
                      Frete (R$/ton)
                    </Label>
                    <Input
                      id="frete"
                      type="number"
                      step="0.01"
                      placeholder="Ex: 150.00"
                      value={freteRTon}
                      onChange={(e) => setFreteRTon(e.target.value)}
                      className="text-lg"
                    />
                    <p className="text-sm text-gray-500">
                      Custo do frete do interior até o porto
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="premio" className="text-base font-semibold">
                      Prêmio (¢/bushel)
                    </Label>
                    <Input
                      id="premio"
                      type="number"
                      step="0.01"
                      placeholder="Ex: 50.00"
                      value={premioCents}
                      onChange={(e) => setPremioCents(e.target.value)}
                      className="text-lg"
                    />
                    <p className="text-sm text-gray-500">
                      Prêmio em centavos de dólar por bushel
                    </p>
                  </div>

                  <Button
                    onClick={handleCalcular}
                    disabled={loading}
                    className="w-full bg-green-700 hover:bg-green-800 text-lg h-12"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Calculando...
                      </>
                    ) : (
                      'Calcular Paridade'
                    )}
                  </Button>

                  {error && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                      <p className="text-red-700 text-sm font-medium">{error}</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Card de Resultados */}
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="text-green-800">Resultados</CardTitle>
                  <CardDescription>
                    Valores calculados com base nos dados de mercado
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {!result && !error && (
                    <div className="flex items-center justify-center h-64 text-gray-400">
                      <div className="text-center">
                        <TrendingUp className="w-16 h-16 mx-auto mb-3 opacity-30" />
                        <p>Preencha os campos e clique em Calcular</p>
                      </div>
                    </div>
                  )}

                  {result && (
                    <div className="space-y-4">
                      {/* Validação de Sanidade */}
                      {result.preco_produtor_r_saca > 500 && (
                        <div className="bg-yellow-50 border-2 border-yellow-400 rounded-lg p-4 flex items-start gap-3">
                          <span className="text-2xl">⚠️</span>
                          <div>
                            <p className="font-bold text-yellow-900">Valor fora do padrão de mercado</p>
                            <p className="text-sm text-yellow-800">
                              O preço calculado (R$ {result.preco_produtor_r_saca.toFixed(2)}/saca) está acima do esperado. 
                              Verifique os parâmetros informados e as cotações de mercado.
                            </p>
                          </div>
                        </div>
                      )}

                      {/* Valor Principal */}
                      <div className="bg-green-100 border-2 border-green-600 rounded-lg p-6 text-center">
                        <p className="text-sm font-semibold text-green-800 mb-1">
                          PREÇO AO PRODUTOR
                        </p>
                        <p className="text-4xl font-bold text-green-900">
                          R$ {result.preco_produtor_r_saca.toFixed(2)}
                        </p>
                        <p className="text-sm text-green-700 mt-1">por saca de 60kg</p>
                      </div>

                      {/* Valores Intermediários */}
                      <div className="space-y-3">
                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                          <span className="font-medium text-gray-700">
                            Preço no Interior
                          </span>
                          <span className="font-bold text-gray-900">
                            R$ {result.preco_interior_r_ton.toFixed(2)}/ton
                          </span>
                        </div>

                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                          <span className="font-medium text-gray-700">
                            Paridade no Porto
                          </span>
                          <span className="font-bold text-gray-900">
                            R$ {result.paridade_porto_r_ton.toFixed(2)}/ton
                          </span>
                        </div>

                        <div className="border-t pt-3 mt-3">
                          <p className="text-xs font-semibold text-gray-600 mb-2">
                            DADOS DE MERCADO
                          </p>
                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">
                                {config.nome} ({config.ticker})
                              </span>
                              <span className="text-sm font-semibold text-gray-900">
                                $ {result.commodity_usd_bu.toFixed(2)}/bu
                              </span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">
                                Câmbio USD/BRL
                              </span>
                              <span className="text-sm font-semibold text-gray-900">
                                R$ {result.cambio_usd_brl.toFixed(2)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* ABA 3: RESULTADOS */}
          <TabsContent value="resultados">
            {/* Informações Adicionais */}
            <Card className="mt-6 shadow-lg">
              <CardContent className="pt-6">
                <div className="grid md:grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-2xl font-bold text-green-700">39.368</p>
                    <p className="text-sm text-gray-600">bushels por tonelada</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-green-700">16.67</p>
                    <p className="text-sm text-gray-600">sacas de 60kg por tonelada</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-green-700">CBOT + Yahoo</p>
                    <p className="text-sm text-gray-600">Dados em tempo real</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Memória de Cálculo Detalhada */}
            {memoriaCalculo && (
              <Card className="mt-6 shadow-lg border-2 border-blue-200">
                <CardHeader className="bg-blue-50">
                  <div className="flex items-center gap-2">
                    <Calculator className="w-6 h-6 text-blue-700" />
                    <CardTitle className="text-blue-900">Memória de Cálculo Detalhada</CardTitle>
                  </div>
                  <CardDescription>
                    Passo a passo completo do cálculo de paridade
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="space-y-6">
                    {/* Passo 1: Dados Obtidos */}
                    <div>
                      <h3 className="font-bold text-lg text-gray-900 mb-3 flex items-center gap-2">
                        <span className="bg-blue-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm">1</span>
                        Dados de Mercado (Obtidos do Yahoo Finance)
                      </h3>
                      <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                        <div className="flex justify-between">
                          <span className="text-gray-700">Cotação {memoriaCalculo.commodity_nome} CBOT ({config.ticker}):</span>
                          <span className="font-mono font-bold text-gray-900">
                            ${memoriaCalculo.commodity_usd_bu.toFixed(4)} USD/bushel
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-700">Câmbio USD/BRL:</span>
                          <span className="font-mono font-bold text-gray-900">
                            R$ {memoriaCalculo.cambio_usd_brl.toFixed(4)} BRL/USD
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-700">Prêmio informado:</span>
                          <span className="font-mono font-bold text-gray-900">
                            {memoriaCalculo.premio_cents.toFixed(2)} ¢/bushel
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-700">Frete informado:</span>
                          <span className="font-mono font-bold text-gray-900">
                            R$ {memoriaCalculo.frete_r_ton.toFixed(2)}/ton
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Passo 2: Conversão do Milho para USD/ton */}
                    <div>
                      <h3 className="font-bold text-lg text-gray-900 mb-3 flex items-center gap-2">
                        <span className="bg-blue-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm">2</span>
                        Conversão: Preço do Milho de USD/bushel para USD/ton
                      </h3>
                      <div className="bg-blue-50 rounded-lg p-4 space-y-2">
                        <div className="text-sm text-gray-700 mb-2">
                          <span className="font-semibold">Fórmula:</span> Preço (USD/ton) = Preço (USD/bu) × 39.368
                        </div>
                        <div className="flex justify-between items-center bg-white rounded p-2">
                          <span className="text-gray-700">Preço Milho (USD/ton):</span>
                          <span className="font-mono font-bold text-blue-900">
                            ${memoriaCalculo.commodity_usd_bu.toFixed(4)} × {memoriaCalculo.bushels_per_ton} = ${memoriaCalculo.commodity_usd_ton.toFixed(2)} USD/ton
                          </span>
                        </div>
                        <div className="text-xs text-gray-600 italic">
                          * Fator de conversão: 1 tonelada métrica = 39.368 bushels
                        </div>
                      </div>
                    </div>

                    {/* Passo 3: Conversão do Prêmio */}
                    <div>
                      <h3 className="font-bold text-lg text-gray-900 mb-3 flex items-center gap-2">
                        <span className="bg-blue-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm">3</span>
                        Conversão: Prêmio de ¢/bushel para USD/ton
                      </h3>
                      <div className="bg-blue-50 rounded-lg p-4 space-y-2">
                        <div className="text-sm text-gray-700 mb-2">
                          <span className="font-semibold">Fórmula:</span> Prêmio (USD/ton) = (Prêmio ¢/bu ÷ 100) × 39.368
                        </div>
                        <div className="flex justify-between items-center bg-white rounded p-2">
                          <span className="text-gray-700">Prêmio (USD/ton):</span>
                          <span className="font-mono font-bold text-blue-900">
                            ({memoriaCalculo.premio_cents.toFixed(2)} ÷ 100) × {memoriaCalculo.bushels_per_ton} = ${memoriaCalculo.premio_usd_ton.toFixed(2)} USD/ton
                          </span>
                        </div>
                        <div className="text-xs text-gray-600 italic">
                          * Convertendo centavos para dólares e multiplicando pelo fator bushel/ton
                        </div>
                      </div>
                    </div>

                    {/* Passo 4: Cálculo FOB */}
                    <div>
                      <h3 className="font-bold text-lg text-gray-900 mb-3 flex items-center gap-2">
                        <span className="bg-blue-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm">4</span>
                        Cálculo: Preço FOB (Free On Board) em USD/ton
                      </h3>
                      <div className="bg-blue-50 rounded-lg p-4 space-y-2">
                        <div className="text-sm text-gray-700 mb-2">
                          <span className="font-semibold">Fórmula:</span> FOB = Preço Milho + Prêmio
                        </div>
                        <div className="flex justify-between items-center bg-white rounded p-2">
                          <span className="text-gray-700">FOB (USD/ton):</span>
                          <span className="font-mono font-bold text-blue-900">
                            ${memoriaCalculo.commodity_usd_ton.toFixed(2)} + ${memoriaCalculo.premio_usd_ton.toFixed(2)} = ${memoriaCalculo.fob_usd_ton.toFixed(2)} USD/ton
                          </span>
                        </div>
                        <div className="text-xs text-gray-600 italic">
                          * FOB representa o preço no porto de exportação em dólares
                        </div>
                      </div>
                    </div>

                    {/* Passo 5: Conversão para BRL */}
                    <div>
                      <h3 className="font-bold text-lg text-gray-900 mb-3 flex items-center gap-2">
                        <span className="bg-blue-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm">5</span>
                        Conversão: Paridade no Porto de USD/ton para BRL/ton
                      </h3>
                      <div className="bg-blue-50 rounded-lg p-4 space-y-2">
                        <div className="text-sm text-gray-700 mb-2">
                          <span className="font-semibold">Fórmula:</span> Paridade Porto (BRL/ton) = FOB (USD/ton) × Câmbio
                        </div>
                        <div className="flex justify-between items-center bg-white rounded p-2">
                          <span className="text-gray-700">Paridade Porto (R$/ton):</span>
                          <span className="font-mono font-bold text-blue-900">
                            ${memoriaCalculo.fob_usd_ton.toFixed(2)} × R$ {memoriaCalculo.cambio_usd_brl.toFixed(4)} = R$ {memoriaCalculo.paridade_porto_r_ton.toFixed(2)}/ton
                          </span>
                        </div>
                        <div className="text-xs text-gray-600 italic">
                          * Paridade no porto representa o valor em reais que o exportador recebe no porto brasileiro
                        </div>
                      </div>
                    </div>

                    {/* Passo 6: Desconto do Frete */}
                    <div>
                      <h3 className="font-bold text-lg text-gray-900 mb-3 flex items-center gap-2">
                        <span className="bg-blue-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm">6</span>
                        Cálculo: Preço no Interior (descontando frete)
                      </h3>
                      <div className="bg-blue-50 rounded-lg p-4 space-y-2">
                        <div className="text-sm text-gray-700 mb-2">
                          <span className="font-semibold">Fórmula:</span> Preço Interior = Paridade Porto - Frete
                        </div>
                        <div className="flex justify-between items-center bg-white rounded p-2">
                          <span className="text-gray-700">Preço Interior (R$/ton):</span>
                          <span className="font-mono font-bold text-blue-900">
                            R$ {memoriaCalculo.paridade_porto_r_ton.toFixed(2)} - R$ {memoriaCalculo.frete_r_ton.toFixed(2)} = R$ {memoriaCalculo.preco_interior_r_ton.toFixed(2)}/ton
                          </span>
                        </div>
                        <div className="text-xs text-gray-600 italic">
                          * Preço que o produtor recebe no interior, já descontado o custo de transporte até o porto
                        </div>
                      </div>
                    </div>

                    {/* Passo 7: Conversão para Saca */}
                    <div>
                      <h3 className="font-bold text-lg text-gray-900 mb-3 flex items-center gap-2">
                        <span className="bg-green-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm">7</span>
                        Conversão Final: Preço ao Produtor em R$/saca de 60kg
                      </h3>
                      <div className="bg-green-50 rounded-lg p-4 space-y-2 border-2 border-green-400">
                        <div className="text-sm text-gray-700 mb-2">
                          <span className="font-semibold">Fórmula:</span> Preço (R$/saca) = Preço (R$/ton) ÷ 16.6667
                        </div>
                        <div className="flex justify-between items-center bg-white rounded p-3">
                          <span className="text-gray-700 font-semibold">Preço ao Produtor (R$/saca):</span>
                          <span className="font-mono font-bold text-green-900 text-xl">
                            R$ {memoriaCalculo.preco_interior_r_ton.toFixed(2)} ÷ {memoriaCalculo.sacas_per_ton.toFixed(4)} = R$ {memoriaCalculo.preco_produtor_r_saca.toFixed(2)}/saca
                          </span>
                        </div>
                        <div className="text-xs text-gray-600 italic">
                          * Fator de conversão: 1 tonelada = 16.6667 sacas de 60kg
                        </div>
                        <div className="text-xs text-gray-600 italic">
                          * Este é o valor que o produtor receberá por saca de 60kg na fazenda
                        </div>
                      </div>
                    </div>

                    {/* Resumo Final */}
                    <div className="bg-gradient-to-r from-green-100 to-yellow-100 rounded-lg p-4 border-2 border-green-500">
                      <h3 className="font-bold text-lg text-green-900 mb-3 text-center">
                        📊 RESULTADO FINAL
                      </h3>
                      <div className="text-center">
                        <p className="text-sm text-gray-700 mb-1">Preço ao Produtor:</p>
                        <p className="text-4xl font-bold text-green-900">
                          R$ {memoriaCalculo.preco_produtor_r_saca.toFixed(2)}
                        </p>
                        <p className="text-sm text-gray-700 mt-1">por saca de 60kg</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}