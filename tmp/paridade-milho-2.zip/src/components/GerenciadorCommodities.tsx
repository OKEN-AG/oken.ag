import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Loader2, RefreshCw, Wheat, Edit2, Check, X } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

export interface CommodityConfig {
  id: string;
  nome: string;
  ticker: string;
  ticker_b3?: string;
  bushels_per_ton: number;
  peso_saca_kg: number;
  moeda: 'USc' | 'USD' | 'BRL';
  fonte: 'yahoo' | 'b3';
  unidade_medida: string;  // Ex: "saca 60kg", "arroba 15kg", "ton"
  unidade?: string;  // Deprecated - usar unidade_medida
  mercado?: string;
}

interface GerenciadorCommoditiesProps {
  commodities: CommodityConfig[];
  onCommoditiesChange: (commodities: CommodityConfig[]) => void;
}

export function GerenciadorCommodities({ commodities, onCommoditiesChange }: GerenciadorCommoditiesProps) {
  const [loading, setLoading] = useState(false);
  const [editando, setEditando] = useState<string | null>(null);
  const [valoresEditados, setValoresEditados] = useState<Partial<CommodityConfig>>({});
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [inicializando, setInicializando] = useState(false);

  // Inicializar commodities padrão ao carregar
  useEffect(() => {
    if (commodities.length === 0) {
      inicializarCommoditiesPadrao();
    }
  }, []);

  const inicializarCommoditiesPadrao = async () => {
    setInicializando(true);
    setError(null);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-d467efec/commodities/init`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error('Erro ao inicializar commodities padrão');
      }

      // Recarregar lista
      await recarregarCommodities();
      setSuccess('Commodities padrão inicializadas com sucesso!');
    } catch (err) {
      console.error('Erro ao inicializar commodities:', err);
      setError(err instanceof Error ? err.message : 'Erro ao inicializar commodities');
    } finally {
      setInicializando(false);
    }
  };

  const recarregarCommodities = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-d467efec/commodities`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error('Erro ao carregar commodities');
      }

      const data = await response.json();
      onCommoditiesChange(data.commodities || []);
    } catch (err) {
      console.error('Erro ao recarregar commodities:', err);
    }
  };

  const handleEditar = (commodity: CommodityConfig) => {
    setEditando(commodity.id);
    setValoresEditados(commodity);
  };

  const handleSalvar = async () => {
    if (!editando || !valoresEditados) return;

    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-d467efec/commodities`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify(valoresEditados),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erro ao salvar commodity');
      }

      // Atualizar lista local
      const index = commodities.findIndex(c => c.id === editando);
      if (index >= 0) {
        const novas = [...commodities];
        novas[index] = valoresEditados as CommodityConfig;
        onCommoditiesChange(novas);
      }

      setSuccess(`${valoresEditados.nome} atualizada com sucesso!`);
      setEditando(null);
      setValoresEditados({});
    } catch (err) {
      console.error('Erro ao salvar commodity:', err);
      setError(err instanceof Error ? err.message : 'Erro ao salvar commodity');
    } finally {
      setLoading(false);
    }
  };

  const handleCancelar = () => {
    setEditando(null);
    setValoresEditados({});
    setError(null);
  };

  return (
    <div className="space-y-6">
      {/* Mensagens */}
      {error && (
        <div className="bg-[#dc2626] border-2 border-[#dc2626] rounded-lg p-4">
          <p className="text-white text-sm font-medium">{error}</p>
        </div>
      )}

      {success && (
        <div className="bg-green-500 bg-opacity-10 border-2 border-green-500 rounded-lg p-4">
          <p className="text-green-700 text-sm font-medium">{success}</p>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Wheat className="w-6 h-6 text-[#4ecdc4]" />
          <div>
            <h3 className="text-lg font-bold text-[#1a2332]">Parâmetros de Commodities</h3>
            <p className="text-sm text-[#6b7280]">Configurações de conversão e taxas</p>
          </div>
        </div>
        <div className="flex gap-2">
          {commodities.length === 0 && (
            <Button
              onClick={inicializarCommoditiesPadrao}
              disabled={inicializando}
              className="bg-[#4ecdc4] hover:bg-[#5dd9c1] text-white"
            >
              {inicializando ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Inicializando...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Carregar Padrões
                </>
              )}
            </Button>
          )}
        </div>
      </div>

      {/* Tabela de Commodities */}
      <Card className="border-2 border-[#e0e4e8]">
        <CardHeader className="bg-[#1a2332] text-white">
          <CardTitle className="text-lg">Tabela de Conversões e Parâmetros</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {commodities.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-[#6b7280]">
              <Wheat className="w-16 h-16 mb-4 opacity-20" />
              <p className="text-sm font-medium">Nenhuma commodity configurada</p>
              <p className="text-xs mt-2">Clique em "Carregar Padrões" para inicializar Milho, Soja e Trigo</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-[#f5f6f8] border-b-2 border-[#e0e4e8]">
                  <tr>
                    <th className="text-left px-6 py-3 text-xs font-bold text-[#6b7280] uppercase tracking-wider">
                      Commodity
                    </th>
                    <th className="text-center px-6 py-3 text-xs font-bold text-[#6b7280] uppercase tracking-wider">
                      Fonte
                    </th>
                    <th className="text-left px-6 py-3 text-xs font-bold text-[#6b7280] uppercase tracking-wider">
                      Ticker Yahoo
                    </th>
                    <th className="text-left px-6 py-3 text-xs font-bold text-[#6b7280] uppercase tracking-wider">
                      Ticker B3
                    </th>
                    <th className="text-center px-6 py-3 text-xs font-bold text-[#6b7280] uppercase tracking-wider">
                      Unidade
                    </th>
                    <th className="text-center px-6 py-3 text-xs font-bold text-[#6b7280] uppercase tracking-wider">
                      Bu/Ton
                    </th>
                    <th className="text-center px-6 py-3 text-xs font-bold text-[#6b7280] uppercase tracking-wider">
                      Peso (kg)
                    </th>
                    <th className="text-center px-6 py-3 text-xs font-bold text-[#6b7280] uppercase tracking-wider">
                      Moeda
                    </th>
                    <th className="text-center px-6 py-3 text-xs font-bold text-[#6b7280] uppercase tracking-wider">
                      Ações
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-[#e0e4e8]">
                  {commodities.map((commodity) => {
                    const isEditando = editando === commodity.id;
                    const valores = isEditando ? valoresEditados : commodity;

                    return (
                      <tr key={commodity.id} className={isEditando ? 'bg-[#4ecdc4] bg-opacity-5' : 'hover:bg-[#f5f6f8]'}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <span className="text-sm font-bold text-[#1a2332]">{commodity.nome}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          {isEditando ? (
                            <Select
                              value={valores.fonte || 'yahoo'}
                              onValueChange={(value) => setValoresEditados({ ...valores, fonte: value as 'yahoo' | 'b3' })}
                            >
                              <SelectTrigger className="h-8 w-24 text-xs border-2 border-[#4ecdc4]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="yahoo">Yahoo</SelectItem>
                                <SelectItem value="b3">B3</SelectItem>
                              </SelectContent>
                            </Select>
                          ) : (
                            <span className={`text-xs px-3 py-1 rounded-full font-semibold ${
                              commodity.fonte === 'yahoo' 
                                ? 'bg-purple-100 text-purple-700' 
                                : 'bg-green-100 text-green-700'
                            }`}>
                              {commodity.fonte === 'yahoo' ? '🌐 Yahoo' : '🇧🇷 B3'}
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-left">
                          {isEditando ? (
                            <Input
                              type="text"
                              value={valores.ticker || ''}
                              onChange={(e) => setValoresEditados({ ...valores, ticker: e.target.value })}
                              className="h-8 text-xs border-2 border-[#4ecdc4]"
                              placeholder="ZC=F"
                            />
                          ) : (
                            <code className="text-xs font-mono px-2 py-1 bg-gray-100 rounded">
                              {commodity.ticker || '-'}
                            </code>
                          )}
                        </td>

                        <td className="px-6 py-4 whitespace-nowrap text-left">
                          {isEditando ? (
                            <Input
                              type="text"
                              value={valores.ticker_b3 || ''}
                              onChange={(e) => setValoresEditados({ ...valores, ticker_b3: e.target.value })}
                              className="h-8 text-xs border-2 border-[#4ecdc4]"
                              placeholder="CCM"
                            />
                          ) : (
                            <code className="text-xs font-mono px-2 py-1 bg-gray-100 rounded">
                              {commodity.ticker_b3 || '-'}
                            </code>
                          )}
                        </td>

                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          {isEditando ? (
                            <Input
                              type="text"
                              value={valores.unidade_medida || ''}
                              onChange={(e) => setValoresEditados({ ...valores, unidade_medida: e.target.value })}
                              className="h-8 text-xs border-2 border-[#4ecdc4]"
                              placeholder="bushel"
                            />
                          ) : (
                            <span className="text-sm text-gray-700">
                              {commodity.unidade_medida || '-'}
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          {isEditando ? (
                            <Input
                              type="number"
                              step="0.001"
                              value={valores.bushels_per_ton || ''}
                              onChange={(e) => setValoresEditados({ ...valores, bushels_per_ton: parseFloat(e.target.value) })}
                              className="h-8 text-xs font-mono text-center border-2 border-[#4ecdc4]"
                            />
                          ) : (
                            <span className="text-sm font-mono text-[#1a2332]">{commodity.bushels_per_ton}</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          {isEditando ? (
                            <Input
                              type="number"
                              value={valores.peso_saca_kg || ''}
                              onChange={(e) => setValoresEditados({ ...valores, peso_saca_kg: parseFloat(e.target.value) })}
                              className="h-8 text-xs font-mono text-center border-2 border-[#4ecdc4]"
                            />
                          ) : (
                            <span className="text-sm font-mono text-[#1a2332]">{commodity.peso_saca_kg}</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          {isEditando ? (
                            <Select
                              value={valores.moeda || 'USD'}
                              onValueChange={(value) => setValoresEditados({ ...valores, moeda: value as 'USc' | 'USD' | 'BRL' })}
                            >
                              <SelectTrigger className="h-8 w-20 text-xs border-2 border-[#4ecdc4]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="USc">USc</SelectItem>
                                <SelectItem value="USD">USD</SelectItem>
                                <SelectItem value="BRL">BRL</SelectItem>
                              </SelectContent>
                            </Select>
                          ) : (
                            <span className="text-xs bg-[#1a2332] text-white px-2 py-1 rounded font-mono">
                              {commodity.moeda || 'USD'}
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          {isEditando ? (
                            <div className="flex gap-2 justify-center">
                              <Button
                                size="sm"
                                onClick={handleSalvar}
                                disabled={loading}
                                className="h-8 bg-green-600 hover:bg-green-700 text-white"
                              >
                                {loading ? (
                                  <Loader2 className="w-3 h-3 animate-spin" />
                                ) : (
                                  <Check className="w-3 h-3" />
                                )}
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={handleCancelar}
                                disabled={loading}
                                className="h-8 border-[#6b7280]"
                              >
                                <X className="w-3 h-3" />
                              </Button>
                            </div>
                          ) : (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditar(commodity)}
                              className="h-8 border-[#4ecdc4] text-[#4ecdc4] hover:bg-[#4ecdc4] hover:text-white"
                            >
                              <Edit2 className="w-3 h-3 mr-1" />
                              Editar
                            </Button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Informações */}
      <div className="bg-[#f5f6f8] border border-[#e0e4e8] rounded-lg p-4">
        <p className="text-xs text-[#6b7280]">
          <strong className="text-[#1a2332]">Bu/Ton:</strong> Bushels por tonelada métrica (conversão padrão internacional)
          <br />
          <strong className="text-[#1a2332]">Ticker:</strong> Código do Yahoo Finance para cotação em tempo real
          <br />
          <strong className="text-[#1a2332]">Sacas/Ton:</strong> Calculado automaticamente (1000 kg ÷ peso da saca)
          <br />
          <strong className="text-[#1a2332]">Moeda:</strong> USc = Centavos de dólar (÷100), USD = Dólares, BRL = Reais
          <br />
          <span className="text-[#4ecdc4] font-semibold">💡 Dica:</span> Milho e Soja CBOT são cotados em centavos (USc). Algodão e Café ICE também em centavos (USc).
        </p>
      </div>
    </div>
  );
}