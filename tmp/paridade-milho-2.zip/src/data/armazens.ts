// Base de dados de armazéns - Formato padrão
// CDA;Armazenador;Endereço;Município;UF;Tipo;Telefone;Email;Capacidade (t);Latitude;Longitude

export interface Armazem {
  cda: string; // Código único do armazém
  armazenador: string;
  endereco: string;
  municipio: string;
  uf: string;
  tipo: string;
  telefone: string;
  email: string;
  capacidade: number; // em toneladas
  latitude: number;
  longitude: number;
}

export interface Porto {
  id: string;
  nome: string;
  cidade: string;
  uf: string;
  lat: number;
  lng: number;
  tipo: 'maritimo' | 'fluvial' | 'base';  // Adicionado 'base' para bases de entrega B3
}

// Portos de Escoamento do Brasil + Bases B3
export const PORTOS: Porto[] = [
  // ========== BASES B3 (Entrega de Contratos Futuros) ==========
  {
    id: 'base-campinas',
    nome: 'Base Campinas (Milho B3)',
    cidade: 'Campinas',
    uf: 'SP',
    lat: -22.9099,
    lng: -47.0626,
    tipo: 'base',
  },
  {
    id: 'base-sao-paulo',
    nome: 'Base São Paulo (Café B3)',
    cidade: 'São Paulo',
    uf: 'SP',
    lat: -23.5505,
    lng: -46.6333,
    tipo: 'base',
  },
  {
    id: 'base-paranagua',
    nome: 'Base Paranaguá (Soja B3)',
    cidade: 'Paranaguá',
    uf: 'PR',
    lat: -25.5163,
    lng: -48.5291,
    tipo: 'base',
  },
  
  // ========== PORTOS MARÍTIMOS ==========
  {
    id: 'santos',
    nome: 'Porto de Santos',
    cidade: 'Santos',
    uf: 'SP',
    lat: -23.9618,
    lng: -46.3322,
    tipo: 'maritimo',
  },
  {
    id: 'paranagua',
    nome: 'Porto de Paranaguá',
    cidade: 'Paranaguá',
    uf: 'PR',
    lat: -25.5163,
    lng: -48.5291,
    tipo: 'maritimo',
  },
  {
    id: 'rio-grande',
    nome: 'Porto de Rio Grande',
    cidade: 'Rio Grande',
    uf: 'RS',
    lat: -32.0850,
    lng: -52.0986,
    tipo: 'maritimo',
  },
  {
    id: 'itaqui',
    nome: 'Porto de Itaqui',
    cidade: 'São Luís',
    uf: 'MA',
    lat: -2.5706,
    lng: -44.3656,
    tipo: 'maritimo',
  },
  {
    id: 'santarem',
    nome: 'Porto de Santarém',
    cidade: 'Santarém',
    uf: 'PA',
    lat: -2.4372,
    lng: -54.7083,
    tipo: 'fluvial',
  },
  {
    id: 'vitoria',
    nome: 'Porto de Vitória',
    cidade: 'Vitória',
    uf: 'ES',
    lat: -20.3155,
    lng: -40.2925,
    tipo: 'maritimo',
  },
  {
    id: 'barcarena',
    nome: 'Porto de Barcarena (Vila do Conde)',
    cidade: 'Barcarena',
    uf: 'PA',
    lat: -1.5186,
    lng: -48.6211,
    tipo: 'fluvial',
  },
  {
    id: 'miritituba',
    nome: 'Porto de Miritituba',
    cidade: 'Itaituba',
    uf: 'PA',
    lat: -4.2778,
    lng: -55.9950,
    tipo: 'fluvial',
  },
];

// Estados do Brasil
export const ESTADOS = [
  { uf: 'AC', nome: 'Acre' },
  { uf: 'AL', nome: 'Alagoas' },
  { uf: 'AP', nome: 'Amapá' },
  { uf: 'AM', nome: 'Amazonas' },
  { uf: 'BA', nome: 'Bahia' },
  { uf: 'CE', nome: 'Ceará' },
  { uf: 'DF', nome: 'Distrito Federal' },
  { uf: 'ES', nome: 'Espírito Santo' },
  { uf: 'GO', nome: 'Goiás' },
  { uf: 'MA', nome: 'Maranhão' },
  { uf: 'MT', nome: 'Mato Grosso' },
  { uf: 'MS', nome: 'Mato Grosso do Sul' },
  { uf: 'MG', nome: 'Minas Gerais' },
  { uf: 'PA', nome: 'Pará' },
  { uf: 'PB', nome: 'Paraíba' },
  { uf: 'PR', nome: 'Paraná' },
  { uf: 'PE', nome: 'Pernambuco' },
  { uf: 'PI', nome: 'Piauí' },
  { uf: 'RJ', nome: 'Rio de Janeiro' },
  { uf: 'RN', nome: 'Rio Grande do Norte' },
  { uf: 'RS', nome: 'Rio Grande do Sul' },
  { uf: 'RO', nome: 'Rondônia' },
  { uf: 'RR', nome: 'Roraima' },
  { uf: 'SC', nome: 'Santa Catarina' },
  { uf: 'SP', nome: 'São Paulo' },
  { uf: 'SE', nome: 'Sergipe' },
  { uf: 'TO', nome: 'Tocantins' },
];

// Principais municípios produtores de commodities agrícolas por estado
export interface MunicipioProdutor {
  nome: string;
  uf: string;
  lat: number;
  lng: number;
}

export const MUNICIPIOS_PRODUTORES: MunicipioProdutor[] = [
  // Mato Grosso - Maior produtor de grãos
  { nome: 'Sorriso', uf: 'MT', lat: -12.5406, lng: -55.7136 },
  { nome: 'Sinop', uf: 'MT', lat: -11.8644, lng: -55.5050 },
  { nome: 'Lucas do Rio Verde', uf: 'MT', lat: -13.0535, lng: -55.9085 },
  { nome: 'Nova Mutum', uf: 'MT', lat: -13.8361, lng: -56.0863 },
  { nome: 'Sapezal', uf: 'MT', lat: -13.5478, lng: -58.7669 },
  { nome: 'Campo Novo do Parecis', uf: 'MT', lat: -13.6686, lng: -57.8908 },
  { nome: 'Querência', uf: 'MT', lat: -12.6261, lng: -52.1836 },
  { nome: 'Primavera do Leste', uf: 'MT', lat: -15.5561, lng: -54.2958 },
  { nome: 'Rondonópolis', uf: 'MT', lat: -16.4708, lng: -54.6354 },
  { nome: 'Campo Verde', uf: 'MT', lat: -15.5456, lng: -55.1639 },
  { nome: 'Diamantino', uf: 'MT', lat: -14.4086, lng: -56.4458 },
  { nome: 'Tangará da Serra', uf: 'MT', lat: -14.6226, lng: -57.4931 },
  { nome: 'Canarana', uf: 'MT', lat: -13.5547, lng: -52.2711 },
  { nome: 'Nova Ubiratã', uf: 'MT', lat: -12.9789, lng: -55.2569 },
  
  // Paraná
  { nome: 'Cascavel', uf: 'PR', lat: -24.9558, lng: -53.4552 },
  { nome: 'Toledo', uf: 'PR', lat: -24.7136, lng: -53.7428 },
  { nome: 'Londrina', uf: 'PR', lat: -23.3045, lng: -51.1696 },
  { nome: 'Ponta Grossa', uf: 'PR', lat: -25.0916, lng: -50.1668 },
  { nome: 'Guarapuava', uf: 'PR', lat: -25.3906, lng: -51.4625 },
  { nome: 'Castro', uf: 'PR', lat: -24.7889, lng: -50.0119 },
  { nome: 'Tibagi', uf: 'PR', lat: -24.5103, lng: -50.4144 },
  { nome: 'Palotina', uf: 'PR', lat: -24.2842, lng: -53.8400 },
  
  // Rio Grande do Sul
  { nome: 'Cruz Alta', uf: 'RS', lat: -28.6389, lng: -53.6061 },
  { nome: 'Ijuí', uf: 'RS', lat: -28.3878, lng: -53.9147 },
  { nome: 'Passo Fundo', uf: 'RS', lat: -28.2628, lng: -52.4067 },
  { nome: 'Santa Rosa', uf: 'RS', lat: -27.8717, lng: -54.4811 },
  { nome: 'Não-Me-Toque', uf: 'RS', lat: -28.4597, lng: -52.8192 },
  { nome: 'Tupanciretã', uf: 'RS', lat: -29.0806, lng: -53.8361 },
  
  // Goiás
  { nome: 'Rio Verde', uf: 'GO', lat: -17.7978, lng: -50.9211 },
  { nome: 'Jataí', uf: 'GO', lat: -17.8806, lng: -51.7142 },
  { nome: 'Cristalina', uf: 'GO', lat: -16.7689, lng: -47.6136 },
  { nome: 'Catalão', uf: 'GO', lat: -18.1656, lng: -47.9464 },
  { nome: 'Mineiros', uf: 'GO', lat: -17.5692, lng: -52.5511 },
  { nome: 'Montividiu', uf: 'GO', lat: -17.4328, lng: -51.1711 },
  { nome: 'Chapadão do Céu', uf: 'GO', lat: -18.4103, lng: -52.5403 },
  
  // Mato Grosso do Sul
  { nome: 'Maracaju', uf: 'MS', lat: -21.6136, lng: -55.1684 },
  { nome: 'Dourados', uf: 'MS', lat: -22.2211, lng: -54.8056 },
  { nome: 'Sidrolândia', uf: 'MS', lat: -20.9314, lng: -54.9603 },
  { nome: 'São Gabriel do Oeste', uf: 'MS', lat: -19.3942, lng: -54.5658 },
  { nome: 'Ponta Porã', uf: 'MS', lat: -22.5361, lng: -55.7256 },
  
  // Bahia
  { nome: 'Luís Eduardo Magalhães', uf: 'BA', lat: -12.0981, lng: -45.7850 },
  { nome: 'Barreiras', uf: 'BA', lat: -12.1528, lng: -44.9900 },
  { nome: 'Formosa do Rio Preto', uf: 'BA', lat: -11.0486, lng: -45.1936 },
  { nome: 'São Desidério', uf: 'BA', lat: -12.3611, lng: -44.9797 },
  
  // Maranhão
  { nome: 'Balsas', uf: 'MA', lat: -7.5328, lng: -46.0358 },
  { nome: 'Tasso Fragoso', uf: 'MA', lat: -8.4689, lng: -46.2042 },
  { nome: 'Alto Parnaíba', uf: 'MA', lat: -9.1089, lng: -45.9328 },
  
  // Piauí
  { nome: 'Uruçuí', uf: 'PI', lat: -7.2422, lng: -44.5586 },
  { nome: 'Baixa Grande do Ribeiro', uf: 'PI', lat: -7.8614, lng: -45.2358 },
  
  // Tocantins
  { nome: 'Pedro Afonso', uf: 'TO', lat: -8.9700, lng: -48.1736 },
  { nome: 'Campos Lindos', uf: 'TO', lat: -7.9914, lng: -46.8689 },
  
  // Minas Gerais
  { nome: 'Uberaba', uf: 'MG', lat: -19.7478, lng: -47.9389 },
  { nome: 'Uberlândia', uf: 'MG', lat: -18.9189, lng: -48.2769 },
  { nome: 'Paracatu', uf: 'MG', lat: -17.2222, lng: -46.8747 },
  
  // São Paulo
  { nome: 'Ribeirão Preto', uf: 'SP', lat: -21.1704, lng: -47.8103 },
  { nome: 'Ituverava', uf: 'SP', lat: -20.3392, lng: -47.7828 },
  
  // Santa Catarina
  { nome: 'Chapecó', uf: 'SC', lat: -27.0964, lng: -52.6147 },
  { nome: 'Campos Novos', uf: 'SC', lat: -27.4006, lng: -51.2258 },
  
  // Pará
  { nome: 'Santarém', uf: 'PA', lat: -2.4372, lng: -54.7083 },
  { nome: 'Paragominas', uf: 'PA', lat: -2.9953, lng: -47.3539 },
  
  // Rondônia
  { nome: 'Vilhena', uf: 'RO', lat: -12.7406, lng: -60.1458 },
];

// Funções auxiliares
export function getCidadesByUF(armazens: Armazem[], uf: string): string[] {
  // Combinar cidades com armazéns + municípios produtores
  const cidadesComArmazens = armazens
    .filter(arm => arm.uf === uf)
    .map(arm => arm.municipio);
  
  const cidadesProdutoras = MUNICIPIOS_PRODUTORES
    .filter(mun => mun.uf === uf)
    .map(mun => mun.nome);
  
  // Combinar e remover duplicatas
  const todasCidades = [...cidadesComArmazens, ...cidadesProdutoras]
    .filter((cidade, index, self) => self.indexOf(cidade) === index)
    .sort();
  
  // Adicionar opção "Outro município" no final
  todasCidades.push('🔧 Outro município (informar manualmente)');
  
  return todasCidades;
}

export function getArmazensByCidade(armazens: Armazem[], uf: string, cidade: string): Armazem[] {
  return armazens.filter(arm => arm.uf === uf && arm.municipio === cidade);
}

export function getArmazemByCDA(armazens: Armazem[], cda: string): Armazem | undefined {
  return armazens.find(arm => arm.cda === cda);
}

export function getPortoById(id: string): Porto | undefined {
  return PORTOS.find(porto => porto.id === id);
}

// Obter coordenadas de um município
export function getMunicipioCoords(uf: string, cidade: string): { lat: number; lng: number } | undefined {
  const municipio = MUNICIPIOS_PRODUTORES.find(m => m.uf === uf && m.nome === cidade);
  if (municipio) {
    return { lat: municipio.lat, lng: municipio.lng };
  }
  return undefined;
}

// Parser CSV para importação
export function parseCSV(csvText: string): Armazem[] {
  // Remover BOM UTF-8 se existir
  let cleanText = csvText.replace(/^\uFEFF/, '');
  
  // Detectar e corrigir problemas de encoding comuns (Latin-1/Windows-1252 lido como UTF-8)
  // Esses são os caracteres mal-formados mais comuns:
  cleanText = cleanText
    .replace(/MunicÃ­pio/gi, 'Município')  // Município
    .replace(/Ã¡/g, 'á')  // á
    .replace(/Ã©/g, 'é')  // é
    .replace(/Ã­/g, 'í')  // í
    .replace(/Ã³/g, 'ó')  // ó
    .replace(/Ãº/g, 'ú')  // ú
    .replace(/Ã /g, 'à')  // à
    .replace(/Ã¢/g, 'â')  // â
    .replace(/Ãª/g, 'ê')  // ê
    .replace(/Ã´/g, 'ô')  // ô
    .replace(/Ã£/g, 'ã')  // ã
    .replace(/Ãµ/g, 'õ')  // õ
    .replace(/Ã§/g, 'ç')  // ç
    .replace(/Ã‡/g, 'Ç')  // Ç
    .replace(/Ã/g, 'Á')   // Á
    .replace(/Ã‰/g, 'É')  // É
    .replace(/Ã/g, 'Í')   // Í
    .replace(/Ã"/g, 'Ó')  // Ó
    .replace(/Ãš/g, 'Ú')  // Ú
    .replace(/Ã€/g, 'À')  // À
    .replace(/Ã‚/g, 'Â')  // Â
    .replace(/ÃŠ/g, 'Ê')  // Ê
    .replace(/Ã"/g, 'Ô')  // Ô
    .replace(/Ãƒ/g, 'Ã')  // Ã
    .replace(/Ã•/g, 'Õ')  // Õ
    // Padrões especiais do Windows-1252
    .replace(/Ã­pia/g, 'ípio')  // Município
    .replace(/Ã\u00AD/g, 'í')    // í com soft hyphen
    .replace(/\u00AD/g, '');     // remover soft hyphens
  
  const lines = cleanText.trim().split('\n');
  const armazens: Armazem[] = [];
  
  // Pular header se existir (detectar variações)
  const firstLine = lines[0].toLowerCase();
  const startIndex = (firstLine.includes('cda') || firstLine.includes('armazenador') || firstLine.includes('municip')) ? 1 : 0;
  
  for (let i = startIndex; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    const parts = line.split(';');
    if (parts.length < 11) continue;
    
    // Normalizar cada campo para remover caracteres invisíveis
    const normalize = (str: string) => str.trim().replace(/[\u00AD\u200B-\u200D\uFEFF]/g, '');
    
    const armazem: Armazem = {
      cda: normalize(parts[0]),
      armazenador: normalize(parts[1]),
      endereco: normalize(parts[2]),
      municipio: normalize(parts[3]),
      uf: normalize(parts[4]),
      tipo: normalize(parts[5]),
      telefone: normalize(parts[6]),
      email: normalize(parts[7]),
      capacidade: parseFloat(parts[8].trim().replace(/\./g, '').replace(',', '.')) || 0,
      latitude: parseFloat(parts[9].trim().replace(',', '.')) || 0,
      longitude: parseFloat(parts[10].trim().replace(',', '.')) || 0,
    };
    
    armazens.push(armazem);
  }
  
  return armazens;
}

// Exportar para CSV
export function exportToCSV(armazens: Armazem[]): string {
  // Adicionar BOM UTF-8 para garantir compatibilidade com Excel/Windows
  const BOM = '\uFEFF';
  const header = 'CDA;Armazenador;Endereço;Município;UF;Tipo;Telefone;Email;Capacidade (t);Latitude;Longitude\n';
  const rows = armazens.map(arm => 
    `${arm.cda};${arm.armazenador};${arm.endereco};${arm.municipio};${arm.uf};${arm.tipo};${arm.telefone};${arm.email};${arm.capacidade};${arm.latitude};${arm.longitude}`
  ).join('\n');
  
  return BOM + header + rows;
}