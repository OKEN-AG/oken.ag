import { CommodityConfig } from '../components/GerenciadorCommodities';

export const COMMODITIES_DEFAULT: CommodityConfig[] = [
  // ========== SOJA ==========
  {
    id: 'soja-yahoo',
    nome: 'Soja',
    ticker: 'ZS=F',
    ticker_b3: '-',
    bushels_per_ton: 36.744,
    peso_saca_kg: 60,
    moeda: 'USc',  // Centavos de dólar por bushel
    fonte: 'yahoo',
    unidade_medida: 'bushel',
    mercado: 'CBOT'
  },
  {
    id: 'soja-b3',
    nome: 'Soja',
    ticker: '-',
    ticker_b3: 'SJC',
    bushels_per_ton: 0,  // Não usado na B3
    peso_saca_kg: 60,
    moeda: 'BRL',  // Reais por saca
    fonte: 'b3',
    unidade_medida: 'saca 60kg',
    mercado: 'B3'
  },
  
  // ========== MILHO ==========
  {
    id: 'milho-yahoo',
    nome: 'Milho',
    ticker: 'ZC=F',
    ticker_b3: '-',
    bushels_per_ton: 39.368,
    peso_saca_kg: 60,
    moeda: 'USc',  // Centavos de dólar por bushel
    fonte: 'yahoo',
    unidade_medida: 'bushel',
    mercado: 'CBOT'
  },
  {
    id: 'milho-b3',
    nome: 'Milho',
    ticker: '-',
    ticker_b3: 'CCM',
    bushels_per_ton: 0,  // Não usado na B3
    peso_saca_kg: 60,
    moeda: 'BRL',  // Reais por saca
    fonte: 'b3',
    unidade_medida: 'saca 60kg',
    mercado: 'B3'
  },
  
  // ========== ALGODÃO ==========
  {
    id: 'algodao-yahoo',
    nome: 'Algodão',
    ticker: 'CT=F',
    ticker_b3: '-',
    bushels_per_ton: 22.046,  // Libras por tonelada na verdade
    peso_saca_kg: 15,
    moeda: 'USc',  // Centavos de dólar por libra
    fonte: 'yahoo',
    unidade_medida: 'libra',
    mercado: 'ICE'
  },
  // Algodão não tem contrato futuro na B3
  
  // ========== CAFÉ ==========
  {
    id: 'cafe-yahoo',
    nome: 'Café',
    ticker: 'KC=F',
    ticker_b3: '-',
    bushels_per_ton: 132.277,  // Libras por tonelada
    peso_saca_kg: 60,
    moeda: 'USc',  // Centavos de dólar por libra
    fonte: 'yahoo',
    unidade_medida: 'libra',
    mercado: 'ICE'
  },
  {
    id: 'cafe-b3',
    nome: 'Café',
    ticker: '-',
    ticker_b3: 'ICF',
    bushels_per_ton: 0,  // Não usado na B3
    peso_saca_kg: 60,
    moeda: 'BRL',  // Reais por saca
    fonte: 'b3',
    unidade_medida: 'saca 60kg',
    mercado: 'B3'
  }
];