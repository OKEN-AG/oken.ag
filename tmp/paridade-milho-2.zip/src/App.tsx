import { ParidadeLogistica } from './components/ParidadeLogistica';

export default function App() {
  return <ParidadeLogistica />;
}