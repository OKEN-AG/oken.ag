import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-d467efec/health", (c) => {
  return c.json({ status: "ok" });
});

// Inicializar commodities padrão (soja, milho, algodão, café) se não existirem
app.post("/make-server-d467efec/commodities/init", async (c) => {
  try {
    console.log('Inicializando commodities padrão...');
    
    const commoditiesPadrao = [
      // ========== SOJA ==========
      {
        id: 'soja-yahoo',
        nome: 'Soja',
        ticker: 'ZS=F',
        ticker_b3: '-',
        bushels_per_ton: 36.744,
        peso_saca_kg: 60,
        moeda: 'USc',
        fonte: 'yahoo',
        unidade_medida: 'bushel',
        mercado: 'CBOT'
      },
      {
        id: 'soja-b3',
        nome: 'Soja',
        ticker: '-',
        ticker_b3: 'SJC',
        bushels_per_ton: 0,
        peso_saca_kg: 60,
        moeda: 'BRL',
        fonte: 'b3',
        unidade_medida: 'saca 60kg',
        mercado: 'B3'
      },
      
      // ========== MILHO ==========
      {
        id: 'milho-yahoo',
        nome: 'Milho',
        ticker: 'ZC=F',
        ticker_b3: '-',
        bushels_per_ton: 39.368,
        peso_saca_kg: 60,
        moeda: 'USc',
        fonte: 'yahoo',
        unidade_medida: 'bushel',
        mercado: 'CBOT'
      },
      {
        id: 'milho-b3',
        nome: 'Milho',
        ticker: '-',
        ticker_b3: 'CCM',
        bushels_per_ton: 0,
        peso_saca_kg: 60,
        moeda: 'BRL',
        fonte: 'b3',
        unidade_medida: 'saca 60kg',
        mercado: 'B3'
      },
      
      // ========== ALGODÃO ==========
      {
        id: 'algodao-yahoo',
        nome: 'Algodão',
        ticker: 'CT=F',
        ticker_b3: '-',
        bushels_per_ton: 22.046,
        peso_saca_kg: 15,
        moeda: 'USc',
        fonte: 'yahoo',
        unidade_medida: 'libra',
        mercado: 'ICE'
      },
      
      // ========== CAFÉ ==========
      {
        id: 'cafe-yahoo',
        nome: 'Café',
        ticker: 'KC=F',
        ticker_b3: '-',
        bushels_per_ton: 132.277,
        peso_saca_kg: 60,
        moeda: 'USc',
        fonte: 'yahoo',
        unidade_medida: 'libra',
        mercado: 'ICE'
      },
      {
        id: 'cafe-b3',
        nome: 'Café',
        ticker: '-',
        ticker_b3: 'ICF',
        bushels_per_ton: 0,
        peso_saca_kg: 60,
        moeda: 'BRL',
        fonte: 'b3',
        unidade_medida: 'saca 60kg',
        mercado: 'B3'
      }
    ];

    // Verificar quais já existem
    const existentes = await kv.getByPrefix('commodity:');
    const idsExistentes = existentes.map(c => c.id);
    
    // Salvar apenas as que não existem
    let adicionadas = 0;
    for (const commodity of commoditiesPadrao) {
      if (!idsExistentes.includes(commodity.id)) {
        await kv.set(`commodity:${commodity.id}`, commodity);
        adicionadas++;
        console.log(`Commodity ${commodity.nome} inicializada`);
      }
    }

    console.log(`${adicionadas} commodities padrão inicializadas`);
    
    return c.json({ 
      success: true, 
      adicionadas,
      total: commoditiesPadrao.length 
    });
  } catch (error) {
    console.log(`Erro ao inicializar commodities: ${error}`);
    return c.json({ error: `Erro ao inicializar: ${error.message}` }, 500);
  }
});

// ===== ROTAS DE CONFIGURAÇÕES DE COMMODITIES =====

// Listar todas as configurações de commodities
app.get("/make-server-d467efec/commodities", async (c) => {
  try {
    console.log('Listando configurações de commodities...');
    const commodities = await kv.getByPrefix('commodity:');
    console.log(`Encontradas ${commodities.length} commodities`);
    return c.json({ commodities });
  } catch (error) {
    console.log(`Erro ao listar commodities: ${error}`);
    return c.json({ error: `Erro ao listar commodities: ${error.message}` }, 500);
  }
});

// Criar ou atualizar commodity
app.post("/make-server-d467efec/commodities", async (c) => {
  try {
    const commodity = await c.req.json();
    console.log('Salvando commodity:', commodity);
    
    if (!commodity.id) {
      return c.json({ error: 'ID da commodity é obrigatório' }, 400);
    }
    
    await kv.set(`commodity:${commodity.id}`, commodity);
    console.log(`Commodity ${commodity.id} salva com sucesso`);
    
    return c.json({ success: true, commodity });
  } catch (error) {
    console.log(`Erro ao salvar commodity: ${error}`);
    return c.json({ error: `Erro ao salvar commodity: ${error.message}` }, 500);
  }
});

// Deletar commodity
app.delete("/make-server-d467efec/commodities/:id", async (c) => {
  try {
    const id = c.req.param('id');
    console.log(`Deletando commodity ${id}...`);
    
    await kv.del(`commodity:${id}`);
    console.log(`Commodity ${id} deletada com sucesso`);
    
    return c.json({ success: true });
  } catch (error) {
    console.log(`Erro ao deletar commodity: ${error}`);
    return c.json({ error: `Erro ao deletar commodity: ${error.message}` }, 500);
  }
});

// ===== ROTAS DE ARMAZÉNS =====

// Listar todos os armazéns
app.get("/make-server-d467efec/armazens", async (c) => {
  try {
    console.log('Listando armazéns...');
    const armazens = await kv.getByPrefix('armazem:');
    console.log(`Encontrados ${armazens.length} armazéns`);
    return c.json({ armazens });
  } catch (error) {
    console.log(`Erro ao listar armazéns: ${error}`);
    return c.json({ error: `Erro ao listar armazéns: ${error.message}` }, 500);
  }
});

// Criar ou atualizar armazém
app.post("/make-server-d467efec/armazens", async (c) => {
  try {
    const armazem = await c.req.json();
    console.log('Salvando armazém:', armazem);
    
    if (!armazem.cda) {
      return c.json({ error: 'CDA é obrigatório' }, 400);
    }
    
    await kv.set(`armazem:${armazem.cda}`, armazem);
    console.log(`Armazém ${armazem.cda} salvo com sucesso`);
    
    return c.json({ success: true, armazem });
  } catch (error) {
    console.log(`Erro ao salvar armazém: ${error}`);
    return c.json({ error: `Erro ao salvar armazém: ${error.message}` }, 500);
  }
});

// Upload em lote (CSV)
app.post("/make-server-d467efec/armazens/upload", async (c) => {
  try {
    const { armazens } = await c.req.json();
    console.log(`Upload em lote: ${armazens.length} armazéns`);
    
    if (!Array.isArray(armazens)) {
      return c.json({ error: 'Formato inválido. Esperado array de armazéns' }, 400);
    }
    
    // Salvar cada armazém
    const keys = armazens.map(arm => `armazem:${arm.cda}`);
    await kv.mset(keys, armazens);
    
    console.log(`${armazens.length} armazéns salvos com sucesso`);
    
    return c.json({ success: true, count: armazens.length });
  } catch (error) {
    console.log(`Erro ao fazer upload de armazéns: ${error}`);
    return c.json({ error: `Erro ao fazer upload: ${error.message}` }, 500);
  }
});

// Deletar armazém
app.delete("/make-server-d467efec/armazens/:cda", async (c) => {
  try {
    const cda = c.req.param('cda');
    console.log(`Deletando armazém ${cda}...`);
    
    await kv.del(`armazem:${cda}`);
    console.log(`Armazém ${cda} deletado com sucesso`);
    
    return c.json({ success: true });
  } catch (error) {
    console.log(`Erro ao deletar armazém: ${error}`);
    return c.json({ error: `Erro ao deletar armazém: ${error.message}` }, 500);
  }
});

// Deletar TODOS os armazéns
app.delete("/make-server-d467efec/armazens/all", async (c) => {
  try {
    console.log('Deletando TODOS os armazéns...');
    const armazens = await kv.getByPrefix('armazem:');
    const keys = armazens.map(arm => `armazem:${arm.cda}`);
    
    if (keys.length > 0) {
      await kv.mdel(keys);
    }
    
    console.log(`${keys.length} armazéns deletados`);
    
    return c.json({ success: true, deletados: keys.length });
  } catch (error) {
    console.log(`Erro ao deletar todos armazéns: ${error}`);
    return c.json({ error: `Erro ao deletar armazéns: ${error.message}` }, 500);
  }
});

// ===== ROTAS EXISTENTES =====

// Calcular distância entre origem e destino
app.post("/make-server-d467efec/calcular-distancia", async (c) => {
  try {
    const { origem_lat, origem_lng, destino_lat, destino_lng } = await c.req.json();
    
    console.log('Calculando distância:', { origem_lat, origem_lng, destino_lat, destino_lng });
    
    if (!origem_lat || !origem_lng || !destino_lat || !destino_lng) {
      return c.json({ error: 'Parâmetros de origem e destino são obrigatórios' }, 400);
    }

    // Tentar usar OSRM (Open Source Routing Machine) - API gratuita sem key
    try {
      // OSRM API pública: http://router.project-osrm.org/route/v1/{profile}/{coordinates}
      // Formato: lon,lat;lon,lat (longitude primeiro!)
      const url = `http://router.project-osrm.org/route/v1/driving/${origem_lng},${origem_lat};${destino_lng},${destino_lat}?overview=false`;
      
      console.log('Chamando OSRM API (gratuita)...');
      const response = await fetch(url);
      const data = await response.json();
      
      console.log('Resposta da OSRM API:', JSON.stringify(data));

      if (data.code === 'Ok' && data.routes && data.routes.length > 0) {
        const route = data.routes[0];
        const distanciaMetros = route.distance;
        const duracaoSegundos = route.duration;
        const distanciaKm = distanciaMetros / 1000;

        console.log(`Rota encontrada: ${distanciaKm.toFixed(2)} km, ${(duracaoSegundos / 3600).toFixed(2)} horas`);

        return c.json({
          distancia_km: Math.round(distanciaKm * 100) / 100,
          metodo: 'osrm',
          duracao_segundos: Math.round(duracaoSegundos),
          duracao_horas: Math.round((duracaoSegundos / 3600) * 100) / 100
        });
      } else {
        console.warn('OSRM não encontrou rota, usando Haversine como fallback');
        const distanciaKm = calcularDistanciaHaversine(origem_lat, origem_lng, destino_lat, destino_lng);
        
        return c.json({
          distancia_km: Math.round(distanciaKm * 100) / 100,
          metodo: 'haversine',
          aviso: 'Rota rodoviária não encontrada. Distância calculada em linha reta (estimativa +30%).'
        });
      }
    } catch (osrmError) {
      // Se a OSRM API falhar, usa Haversine como fallback
      console.warn('Erro ao chamar OSRM API, usando Haversine:', osrmError);
      const distanciaKm = calcularDistanciaHaversine(origem_lat, origem_lng, destino_lat, destino_lng);
      
      return c.json({
        distancia_km: Math.round(distanciaKm * 100) / 100,
        metodo: 'haversine',
        aviso: 'Serviço de rotas temporariamente indisponível. Distância estimada em linha reta (+30%).'
      });
    }
  } catch (error) {
    console.log(`Erro geral ao calcular distância: ${error}`);
    return c.json({ error: `Erro ao calcular distância: ${error.message}` }, 500);
  }
});

// Função auxiliar para calcular distância usando fórmula de Haversine
function calcularDistanciaHaversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Raio da Terra em km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distancia = R * c;
  
  // Adicionar ~30% para compensar que rotas rodoviárias não são em linha reta
  return distancia * 1.3;
}

// Endpoint de cálculo de paridade com Yahoo Finance
app.post("/make-server-d467efec/paridade-milho-yahoo", async (c) => {
  try {
    const { frete_r_ton, premio_cents, ticker, bushels_per_ton, peso_saca_kg, moeda } = await c.req.json();
    
    console.log('=== RECEBIDA REQUISIÇÃO DE PARIDADE ===');
    console.log('Payload recebido:', { frete_r_ton, premio_cents, ticker, bushels_per_ton, peso_saca_kg, moeda });

    // Validações
    if (frete_r_ton === undefined || premio_cents === undefined) {
      console.log('Erro: Parâmetros obrigatórios faltando');
      return c.json({ error: 'Parâmetros frete_r_ton e premio_cents são obrigatórios' }, 400);
    }

    const tickerFinal = ticker || 'ZC=F';
    const bushelsTon = bushels_per_ton || 39.368;
    const pesoSaca = peso_saca_kg || 60;
    const moedaCommodity = moeda || 'USc';  // USc (centavos), USD (dólares), BRL (reais)

    console.log('Parâmetros finais:', { tickerFinal, bushelsTon, pesoSaca, moedaCommodity });
    console.log('Buscando cotação do Yahoo Finance para:', tickerFinal);

    // 1. Buscar cotação da commodity no Yahoo Finance (ex: ZC=F para milho)
    const commodityResponse = await fetch(
      `https://query1.finance.yahoo.com/v8/finance/chart/${tickerFinal}?interval=1d`,
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'application/json',
        }
      }
    );
    
    console.log('Status resposta Yahoo (commodity):', commodityResponse.status);
    
    if (!commodityResponse.ok) {
      const errorText = await commodityResponse.text();
      console.log('Erro ao buscar commodity no Yahoo Finance, status:', commodityResponse.status);
      console.log('Resposta de erro:', errorText);
      throw new Error(`Erro ao buscar cotação da commodity (${tickerFinal}) no Yahoo Finance. Status: ${commodityResponse.status}`);
    }

    const commodityData = await commodityResponse.json();
    console.log('Dados recebidos do Yahoo (commodity):', JSON.stringify(commodityData).substring(0, 500));

    // Usar meta.regularMarketPrice
    let commodityPriceRaw = commodityData.chart?.result?.[0]?.meta?.regularMarketPrice;
    
    if (!commodityPriceRaw) {
      console.log('Erro: Preço não encontrado na resposta do Yahoo');
      console.log('Estrutura da resposta:', JSON.stringify(commodityData, null, 2));
      throw new Error(`Cotação não disponível para ${tickerFinal}`);
    }

    // Converter conforme a moeda
    let commodityPrice;  // Sempre em USD/bushel para cálculos
    if (moedaCommodity === 'USc') {
      // Centavos de dólar → Dólares
      commodityPrice = commodityPriceRaw / 100;
      console.log(`Cotação bruta (centavos): ${commodityPriceRaw} USc/bushel`);
      console.log(`Convertido para: ${commodityPrice} USD/bushel`);
    } else if (moedaCommodity === 'USD') {
      // Já está em dólares
      commodityPrice = commodityPriceRaw;
      console.log(`Cotação em: ${commodityPrice} USD/bushel`);
    } else if (moedaCommodity === 'BRL') {
      // Reais → precisaria converter, mas commodities normalmente não vêm em BRL
      commodityPrice = commodityPriceRaw;
      console.log(`Cotação em: ${commodityPrice} BRL/bushel (conversão necessária)`);
    }

    console.log('Cotação final para cálculos:', commodityPrice, 'USD/bushel');
    console.log('Buscando câmbio USD/BRL...');

    // 2. Buscar câmbio USD/BRL no Yahoo Finance (USDBRL=X)
    const cambioResponse = await fetch(
      'https://query1.finance.yahoo.com/v8/finance/chart/USDBRL=X?interval=1d',
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'application/json',
        }
      }
    );
    
    console.log('Status resposta Yahoo (câmbio):', cambioResponse.status);
    
    if (!cambioResponse.ok) {
      const errorText = await cambioResponse.text();
      console.log('Erro ao buscar câmbio no Yahoo Finance, status:', cambioResponse.status);
      console.log('Resposta de erro:', errorText);
      throw new Error(`Erro ao buscar cotação do câmbio USD/BRL. Status: ${cambioResponse.status}`);
    }

    const cambioData = await cambioResponse.json();
    console.log('Dados recebidos do Yahoo (câmbio):', JSON.stringify(cambioData).substring(0, 500));
    
    // Usar meta.regularMarketPrice (BRL por USD)
    const cambio = cambioData.chart?.result?.[0]?.meta?.regularMarketPrice;

    if (!cambio) {
      console.log('Erro: Câmbio não encontrado');
      console.log('Estrutura da resposta:', JSON.stringify(cambioData, null, 2));
      throw new Error('Cotação do câmbio não disponível');
    }

    console.log('Câmbio encontrado:', cambio, 'BRL/USD');
    console.log('Iniciando cálculos...');

    // 3. Cálculos de paridade
    const BUSHELS_PER_TON = bushelsTon;  // 39.368 para milho
    const SACAS_PER_TON = 1000 / pesoSaca;  // 16.6667 para saca de 60kg

    console.log('Constantes:', { BUSHELS_PER_TON, SACAS_PER_TON });

    // Passo 1: Converter de USD/bushel para USD/tonelada
    const commodity_usd_ton = commodityPrice * BUSHELS_PER_TON;
    console.log(`1. Commodity USD/ton = ${commodityPrice} × ${BUSHELS_PER_TON} = ${commodity_usd_ton}`);

    // Passo 2: Adicionar prêmio (em cents/bushel → USD/tonelada)
    const premio_usd_ton = (premio_cents / 100) * BUSHELS_PER_TON;
    console.log(`2. Prêmio USD/ton = (${premio_cents}/100) × ${BUSHELS_PER_TON} = ${premio_usd_ton}`);

    // Passo 3: FOB = Commodity + Prêmio
    const fob_usd_ton = commodity_usd_ton + premio_usd_ton;
    console.log(`3. FOB USD/ton = ${commodity_usd_ton} + ${premio_usd_ton} = ${fob_usd_ton}`);

    // Passo 4: Paridade no Porto (FOB × Câmbio)
    const paridade_porto_r_ton = fob_usd_ton * cambio;
    console.log(`4. Paridade Porto = ${fob_usd_ton} × ${cambio} = ${paridade_porto_r_ton} R$/ton`);

    // Passo 5: Preço no Interior (Paridade - Frete)
    const preco_interior_r_ton = paridade_porto_r_ton - frete_r_ton;
    console.log(`5. Preço Interior = ${paridade_porto_r_ton} - ${frete_r_ton} = ${preco_interior_r_ton} R$/ton`);

    // Passo 6: Preço ao Produtor (Preço Interior / Sacas por Ton)
    const preco_produtor_r_saca = preco_interior_r_ton / SACAS_PER_TON;
    console.log(`6. Preço Produtor = ${preco_interior_r_ton} / ${SACAS_PER_TON} = ${preco_produtor_r_saca} R$/saca`);

    // 4. Retornar resultado
    const resultado = {
      commodity_usd_bu: commodityPrice,
      cambio_usd_brl: cambio,
      paridade_porto_r_ton,
      preco_interior_r_ton,
      preco_produtor_r_saca,
    };

    console.log('=== CÁLCULO CONCLUÍDO ===');
    console.log('Resultado:', resultado);

    return c.json(resultado);
  } catch (error) {
    console.log(`=== ERRO NO CÁLCULO DE PARIDADE ===`);
    console.log(`Erro completo: ${error}`);
    console.log(`Stack: ${error.stack}`);
    return c.json({ error: `Erro ao calcular paridade: ${error.message}` }, 500);
  }
});

// ========================================
// ENDPOINT: Cotações da B3
// ========================================

// Endpoint de cotações de futuros da B3
app.post("/make-server-d467efec/futuros-b3-multiplos", async (c) => {
  try {
    const { contrato, frete_r_ton, premio_r_ton } = await c.req.json();
    
    console.log('=== RECEBIDA REQUISIÇÃO DE FUTUROS B3 ===');
    console.log('Payload recebido:', { contrato, frete_r_ton, premio_r_ton });

    // Validações
    if (!contrato) {
      console.log('Erro: Parâmetro contrato é obrigatório');
      return c.json({ error: 'Parâmetro contrato é obrigatório' }, 400);
    }

    const contratosValidos = ['CCM', 'SJC', 'ICF', 'BGI', 'DOL', 'DI1'];
    if (!contratosValidos.includes(contrato.toUpperCase())) {
      console.log('Erro: Contrato inválido:', contrato);
      return c.json({ 
        error: `Contrato inválido. Valores aceitos: ${contratosValidos.join(', ')}` 
      }, 400);
    }

    const contratoUpper = contrato.toUpperCase();
    const freteValor = frete_r_ton || 0;
    const premioValor = premio_r_ton || 0;

    console.log('Parâmetros finais:', { contrato: contratoUpper, frete_r_ton: freteValor, premio_r_ton: premioValor });

    console.log('Buscando cotação da B3 para:', contratoUpper);

    // IMPORTANTE: A B3 não possui API pública REST simples
    // Esta implementação usa Yahoo Finance para contratos futuros brasileiros
    // ou valores de referência quando indisponíveis
    
    let precoB3Raw: number;
    let fontePreco = 'Yahoo Finance (BRL)';
    
    try {
      // Mapear contratos B3 para tickers Yahoo Finance (quando disponíveis)
      const tickersYahooB3: Record<string, string> = {
        'CCM': 'CCM=F',  // Milho Futuro B3
        'SJC': 'SJC=F',  // Soja Futuro B3
        'ICF': 'ICF=F',  // Café Arábica Futuro B3
        'BGI': 'BGI=F',  // Boi Gordo Futuro B3
      };
      
      const tickerYahoo = tickersYahooB3[contratoUpper];
      
      if (tickerYahoo) {
        console.log(`Buscando ${contratoUpper} no Yahoo Finance como ${tickerYahoo}...`);
        
        const yahooResponse = await fetch(
          `https://query1.finance.yahoo.com/v8/finance/chart/${tickerYahoo}`,
          {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            }
          }
        );
        
        if (yahooResponse.ok) {
          const yahooData = await yahooResponse.json();
          const quote = yahooData.chart?.result?.[0]?.meta?.regularMarketPrice;
          
          if (quote && quote > 0) {
            precoB3Raw = quote;
            fontePreco = 'Yahoo Finance (Contrato B3)';
            console.log(`Cotação encontrada no Yahoo: R$ ${precoB3Raw}`);
          } else {
            throw new Error('Preço não encontrado no Yahoo');
          }
        } else {
          throw new Error('Yahoo Finance indisponível');
        }
      } else {
        throw new Error('Contrato não mapeado para Yahoo');
      }
    } catch (error) {
      // Fallback: Usar valores de referência realistas baseados no mercado atual
      console.log(`Erro ao buscar no Yahoo Finance: ${error}. Usando valores de referência.`);
      fontePreco = 'Valor de Referência (Simulado)';
      
      // Valores de referência atualizados (Fevereiro 2026)
      const valoresReferencia: Record<string, number> = {
        'CCM': 68.50,   // Milho: R$ 68,50/saca (referência mercado atual)
        'SJC': 147.80,  // Soja: R$ 147,80/saca (referência mercado atual)
        'ICF': 1285.00, // Café: R$ 1.285,00/saca (referência mercado atual)
        'BGI': 295.50,  // Boi Gordo: R$ 295,50/arroba (referência mercado atual)
        'DOL': 5.85,    // Dólar Futuro: R$ 5,85
        'DI1': 12.75,   // DI Futuro: 12,75% a.a.
      };
      
      precoB3Raw = valoresReferencia[contratoUpper] || 100;
      console.log(`Usando valor de referência: R$ ${precoB3Raw}`);
    }

    console.log('Cotação B3 encontrada:', precoB3Raw, '- Fonte:', fontePreco);

    // 2. Interpretar conforme o tipo de contrato
    let resultadoFinal: any = {
      contrato: contratoUpper,
      preco_b3_raw: precoB3Raw,
      timestamp: new Date().toISOString(),
    };

    switch (contratoUpper) {
      case 'CCM': // Milho B3
        {
          // Preço geralmente em R$/saca de 60kg
          // Converter para R$/ton
          const peso_saca = 60; // kg
          const sacas_por_ton = 1000 / peso_saca; // 16.6667
          
          let preco_r_ton = precoB3Raw;
          let preco_r_saca = precoB3Raw;
          
          // Se o preço veio em R$/saca, converter para R$/ton
          if (precoB3Raw < 500) { // Heurística: se < 500, provavelmente é R$/saca
            preco_r_saca = precoB3Raw;
            preco_r_ton = precoB3Raw * sacas_por_ton;
          } else { // Se >= 500, provavelmente já é R$/ton
            preco_r_ton = precoB3Raw;
            preco_r_saca = precoB3Raw / sacas_por_ton;
          }
          
          const preco_com_premio = preco_r_ton + premioValor;
          const preco_com_frete = preco_com_premio - freteValor;
          const preco_final_saca = preco_com_frete / sacas_por_ton;

          resultadoFinal = {
            ...resultadoFinal,
            tipo: 'Milho B3',
            unidade_b3: 'R$/saca 60kg',
            preco_b3_r_saca: preco_r_saca,
            preco_b3_r_ton: preco_r_ton,
            premio_r_ton: premioValor,
            preco_com_premio_r_ton: preco_com_premio,
            frete_r_ton: freteValor,
            preco_final_r_ton: preco_com_frete,
            preco_final_r_saca: preco_final_saca,
            peso_saca_kg: peso_saca,
          };
        }
        break;

      case 'SJC': // Soja B3
        {
          const peso_saca = 60; // kg
          const sacas_por_ton = 1000 / peso_saca; // 16.6667
          
          let preco_r_ton = precoB3Raw;
          let preco_r_saca = precoB3Raw;
          
          if (precoB3Raw < 500) {
            preco_r_saca = precoB3Raw;
            preco_r_ton = precoB3Raw * sacas_por_ton;
          } else {
            preco_r_ton = precoB3Raw;
            preco_r_saca = precoB3Raw / sacas_por_ton;
          }
          
          const preco_com_premio = preco_r_ton + premioValor;
          const preco_com_frete = preco_com_premio - freteValor;
          const preco_final_saca = preco_com_frete / sacas_por_ton;

          resultadoFinal = {
            ...resultadoFinal,
            tipo: 'Soja B3',
            unidade_b3: 'R$/saca 60kg',
            preco_b3_r_saca: preco_r_saca,
            preco_b3_r_ton: preco_r_ton,
            premio_r_ton: premioValor,
            preco_com_premio_r_ton: preco_com_premio,
            frete_r_ton: freteValor,
            preco_final_r_ton: preco_com_frete,
            preco_final_r_saca: preco_final_saca,
            peso_saca_kg: peso_saca,
          };
        }
        break;

      case 'ICF': // Café Arábica B3
        {
          const peso_saca = 60; // kg
          const sacas_por_ton = 1000 / peso_saca;
          
          const preco_r_saca = precoB3Raw; // Café sempre em R$/saca
          const preco_r_ton = preco_r_saca * sacas_por_ton;
          
          const preco_com_premio_ton = preco_r_ton + premioValor;
          const preco_com_frete_ton = preco_com_premio_ton - freteValor;
          const preco_final_saca = preco_com_frete_ton / sacas_por_ton;

          resultadoFinal = {
            ...resultadoFinal,
            tipo: 'Café Arábica B3',
            unidade_b3: 'R$/saca 60kg',
            preco_b3_r_saca: preco_r_saca,
            preco_b3_r_ton: preco_r_ton,
            premio_r_ton: premioValor,
            preco_com_premio_r_ton: preco_com_premio_ton,
            frete_r_ton: freteValor,
            preco_final_r_ton: preco_com_frete_ton,
            preco_final_r_saca: preco_final_saca,
            peso_saca_kg: peso_saca,
          };
        }
        break;

      case 'BGI': // Boi Gordo
        {
          const preco_r_arroba = precoB3Raw;
          const arrobas_por_ton = 1000 / 15; // 66.6667 arrobas/ton
          const preco_r_ton = preco_r_arroba * arrobas_por_ton;
          
          const preco_com_premio = preco_r_ton + premioValor;
          const preco_com_frete = preco_com_premio - freteValor;
          const preco_final_arroba = preco_com_frete / arrobas_por_ton;

          resultadoFinal = {
            ...resultadoFinal,
            tipo: 'Boi Gordo B3',
            unidade_b3: 'R$/arroba 15kg',
            preco_b3_r_arroba: preco_r_arroba,
            preco_b3_r_ton: preco_r_ton,
            premio_r_ton: premioValor,
            preco_com_premio_r_ton: preco_com_premio,
            frete_r_ton: freteValor,
            preco_final_r_ton: preco_com_frete,
            preco_final_r_arroba: preco_final_arroba,
            peso_arroba_kg: 15,
          };
        }
        break;

      case 'DOL': // Dólar Futuro
        {
          // Cotação em pontos (1 ponto = R$ 0,001)
          // Ex: 5723 pontos = R$ 5,723 por USD
          const cambio_brl_usd = precoB3Raw / 1000;

          resultadoFinal = {
            ...resultadoFinal,
            tipo: 'Dólar Futuro B3',
            unidade_b3: 'pontos',
            preco_b3_pontos: precoB3Raw,
            cambio_brl_usd: cambio_brl_usd,
            observacao: '1 ponto = R$ 0,001',
          };
        }
        break;

      case 'DI1': // Juros DI Futuro
        {
          // Cotação em pontos (100000 - taxa)
          // Ex: 90125 pontos = 9,875% a.a.
          const taxa_aa = (100000 - precoB3Raw) / 1000;

          resultadoFinal = {
            ...resultadoFinal,
            tipo: 'DI Futuro B3',
            unidade_b3: 'pontos',
            preco_b3_pontos: precoB3Raw,
            taxa_juros_aa: taxa_aa,
            observacao: 'Taxa = (100000 - pontos) / 1000',
          };
        }
        break;

      default:
        throw new Error(`Contrato não implementado: ${contratoUpper}`);
    }

    console.log('=== CÁLCULO B3 CONCLUÍDO ===');
    console.log('Resultado:', JSON.stringify(resultadoFinal, null, 2));

    return c.json(resultadoFinal);

  } catch (error) {
    console.log(`=== ERRO NO CÁLCULO DE FUTUROS B3 ===`);
    console.log(`Erro completo: ${error}`);
    console.log(`Stack: ${error.stack}`);
    return c.json({ error: `Erro ao buscar futuros B3: ${error.message}` }, 500);
  }
});

Deno.serve(app.fetch);