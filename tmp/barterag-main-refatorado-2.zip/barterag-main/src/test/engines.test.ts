import { describe, it, expect } from 'vitest';

import { calculateAgronomicSelection } from '@/engines/agronomic';
import { applyComboCascade, getDoseRangeForRef } from '@/engines/combo-cascade';
import { calculateGrossToNet } from '@/engines/pricing';
import { buildWagonStages, canAdvance } from '@/engines/orchestrator';

import type {
  Product,
  AgronomicSelection,
  ComboDefinition,
  ComboActivation,
  PricingResult,
  JourneyModule,
  DocumentType,
} from '@/types/barter';

describe('Agronomic engine', () => {
  it('chooses the package size that minimizes waste (does not always pick the largest)', () => {
    const product: Product = {
      id: 'p1',
      name: 'Produto Teste',
      ref: 'REF1',
      category: 'Herbicida',
      activeIngredient: 'X',
      unitType: 'L',
      packageSizes: [10, 5],
      unitsPerBox: 4,
      boxesPerPallet: 50,
      palletsPerTruck: 20,
      dosePerHectare: 2.5,
      minDose: 1,
      maxDose: 3,
      pricePerUnit: 10,
      currency: 'BRL',
      priceType: 'vista',
      includesMargin: false,
    };

    const sel = calculateAgronomicSelection(product, 500, 2.5);

    // raw = 500 * 2.5 = 1250 L
    // size 5 => units/box = 4*5=20 => boxes=63 => rounded=1260
    expect(sel.boxes).toBe(63);
    expect(sel.roundedQuantity).toBe(1260);
  });
});

describe('Combo cascade engine', () => {
  it('returns the tightest dose range for a REF', () => {
    const combos: ComboDefinition[] = [
      {
        id: 'c1',
        name: 'Combo A',
        discountPercent: 5,
        priority: 0,
        isComplementary: false,
        products: [{ ref: 'REF1', minDosePerHa: 1, maxDosePerHa: 3 }],
      },
      {
        id: 'c2',
        name: 'Combo B',
        discountPercent: 6,
        priority: 0,
        isComplementary: false,
        products: [{ ref: 'REF1', minDosePerHa: 1.5, maxDosePerHa: 2 }],
      },
    ];

    const range = getDoseRangeForRef(combos, 'ref1');
    expect(range?.minDosePerHa).toBe(1.5);
    expect(range?.maxDosePerHa).toBe(2);
  });

  it('computes activated hectares as the minimum area among required products', () => {
    const combos: ComboDefinition[] = [
      {
        id: 'c_main',
        name: 'Combo Principal',
        discountPercent: 10,
        priority: 0,
        isComplementary: false,
        products: [
          { ref: 'REF1', minDosePerHa: 1, maxDosePerHa: 3 },
          { ref: 'REF2', minDosePerHa: 1, maxDosePerHa: 3 },
        ],
      },
    ];

    const mkProduct = (id: string, ref: string): Product => ({
      id,
      name: id,
      ref,
      category: 'X',
      activeIngredient: '',
      unitType: 'L',
      packageSizes: [1],
      unitsPerBox: 1,
      boxesPerPallet: 1,
      palletsPerTruck: 1,
      dosePerHectare: 2,
      minDose: 0,
      maxDose: 10,
      pricePerUnit: 1,
      currency: 'BRL',
      priceType: 'vista',
      includesMargin: false,
    });

    const selections: AgronomicSelection[] = [
      {
        productId: 'p1',
        ref: 'REF1',
        product: mkProduct('p1', 'REF1'),
        areaHectares: 500,
        dosePerHectare: 2,
        rawQuantity: 1000,
        roundedQuantity: 1000,
        boxes: 0,
        pallets: 0,
      },
      {
        productId: 'p2',
        ref: 'REF2',
        product: mkProduct('p2', 'REF2'),
        areaHectares: 400,
        dosePerHectare: 2,
        rawQuantity: 800,
        roundedQuantity: 800,
        boxes: 0,
        pallets: 0,
      },
    ];

    const activations = applyComboCascade(combos, selections);
    const main = activations.find(a => a.comboId === 'c_main');

    expect(main?.applied).toBe(true);
    expect(main?.activatedHectares).toBe(400);
  });
});

describe('Pricing engine', () => {
  it('applies combo discounts only to eligible lines and proportionally by hectares', () => {
    const pricing: PricingResult[] = [
      {
        productId: 'p1',
        basePrice: 10,
        normalizedPrice: 10,
        interestComponent: 0,
        marginComponent: 0,
        commercialPrice: 10,
        quantity: 100,
        subtotal: 1000,
      },
      {
        productId: 'p2',
        basePrice: 20,
        normalizedPrice: 20,
        interestComponent: 0,
        marginComponent: 0,
        commercialPrice: 20,
        quantity: 100,
        subtotal: 2000,
      },
      {
        productId: 'p3',
        basePrice: 5,
        normalizedPrice: 5,
        interestComponent: 0,
        marginComponent: 0,
        commercialPrice: 5,
        quantity: 100,
        subtotal: 500,
      },
    ];

    const mkProduct = (id: string, ref: string): Product => ({
      id,
      name: id,
      ref,
      category: 'X',
      activeIngredient: '',
      unitType: 'L',
      packageSizes: [1],
      unitsPerBox: 1,
      boxesPerPallet: 1,
      palletsPerTruck: 1,
      dosePerHectare: 2,
      minDose: 0,
      maxDose: 10,
      pricePerUnit: 1,
      currency: 'BRL',
      priceType: 'vista',
      includesMargin: false,
    });

    const selections: AgronomicSelection[] = [
      {
        productId: 'p1',
        ref: 'REF1',
        product: mkProduct('p1', 'REF1'),
        areaHectares: 500,
        dosePerHectare: 2,
        rawQuantity: 0,
        roundedQuantity: 0,
        boxes: 0,
        pallets: 0,
      },
      {
        productId: 'p2',
        ref: 'REF2',
        product: mkProduct('p2', 'REF2'),
        areaHectares: 400,
        dosePerHectare: 2,
        rawQuantity: 0,
        roundedQuantity: 0,
        boxes: 0,
        pallets: 0,
      },
      {
        productId: 'p3',
        ref: 'REF3',
        product: mkProduct('p3', 'REF3'),
        areaHectares: 500,
        dosePerHectare: 2,
        rawQuantity: 0,
        roundedQuantity: 0,
        boxes: 0,
        pallets: 0,
      },
    ];

    const activations: ComboActivation[] = [
      {
        comboId: 'main',
        comboName: 'Main',
        discountPercent: 10,
        matchedProducts: ['REF1', 'REF2'],
        applied: true,
        isComplementary: false,
      },
      {
        comboId: 'comp',
        comboName: 'Complementar',
        discountPercent: 5,
        matchedProducts: ['REF3'],
        applied: true,
        isComplementary: true,
        proportionalHectares: 400,
      },
    ];

    const gtn = calculateGrossToNet(pricing, selections, activations, 2);

    // Main discount:
    // p1 (500ha) capped at 400ha => 0.8 => 1000 * 10% * 0.8 = 80
    // p2 (400ha) => 2000 * 10% = 200
    // Complementary on p3 capped at 400/500=0.8 => 500 * 5% * 0.8 = 20
    // total combo = 300
    expect(Math.round(gtn.comboDiscount)).toBe(300);

    // Barter discount 2% after combos: (3500 - 300) * 2% = 64
    expect(Math.round(gtn.barterDiscount)).toBe(64);

    // Net: 3500 - 300 - 64 = 3136
    expect(Math.round(gtn.netRevenue)).toBe(3136);
  });
});

describe('Orchestrator engine', () => {
  it('advances from formalizado to garantido when all current-stage documents are signed', () => {
    const activeModules: JourneyModule[] = ['adesao', 'simulacao', 'formalizacao', 'documentos', 'garantias'];

    const docs: Array<{ doc_type: DocumentType; status: string }> = [
      { doc_type: 'termo_barter', status: 'assinado' },
      { doc_type: 'ccv', status: 'assinado' },
      { doc_type: 'cessao_credito', status: 'assinado' },
    ];

    const next = canAdvance(activeModules, 'formalizado', docs);
    expect(next).toBe('garantido');

    const stages = buildWagonStages(activeModules, 'formalizado', docs);
    const formalizacao = stages.find(s => s.module === 'formalizacao');
    const documentos = stages.find(s => s.module === 'documentos');
    const garantias = stages.find(s => s.module === 'garantias');

    expect(formalizacao?.status).toBe('concluido');
    expect(documentos?.status).toBe('concluido');
    expect(garantias?.status).toBe('pendente');
  });

  it('blocks later stages within the same status until the previous is completed', () => {
    const activeModules: JourneyModule[] = ['formalizacao', 'documentos'];

    const docs: Array<{ doc_type: DocumentType; status: string }> = [
      { doc_type: 'termo_barter', status: 'pendente' },
      { doc_type: 'ccv', status: 'assinado' },
      { doc_type: 'cessao_credito', status: 'assinado' },
    ];

    const stages = buildWagonStages(activeModules, 'formalizado', docs);
    const formalizacao = stages.find(s => s.module === 'formalizacao');
    const documentos = stages.find(s => s.module === 'documentos');

    expect(formalizacao?.status).toBe('em_progresso');
    expect(documentos?.status).toBe('bloqueado');
  });
});
