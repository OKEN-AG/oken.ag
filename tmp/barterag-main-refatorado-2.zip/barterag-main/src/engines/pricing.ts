import type {
  Product,
  Campaign,
  PricingResult,
  AgronomicSelection,
  ChannelSegment,
  GrossToNet,
  ComboActivation,
} from '@/types/barter';

/**
 * PRICING NORMALIZATION ENGINE
 * Normalizes prices from 8 possible formats to target format.
 */
export function normalizePrice(
  product: Product,
  campaign: Campaign,
  targetSegment: ChannelSegment,
  dueMonths: number
): number {
  let price = product.pricePerUnit;

  // 1) Convert USD → BRL if needed
  if (product.currency === 'USD') {
    price *= campaign.exchangeRateProducts;
  }

  // 2) Convert vista → prazo (simple monthly compounding)
  if (product.priceType === 'vista' && dueMonths > 0) {
    price *= Math.pow(1 + campaign.interestRate / 100, dueMonths);
  }

  // 3) Add channel margin if the list price does NOT include it
  if (!product.includesMargin && targetSegment !== 'direto') {
    const margin = campaign.margins.find(m => m.segment === targetSegment);
    if (margin) {
      price *= 1 + margin.marginPercent / 100;
    }
  }

  return price;
}

/**
 * Decompose price into components.
 * Returned components are PER UNIT.
 */
export function decomposePricing(
  product: Product,
  campaign: Campaign,
  targetSegment: ChannelSegment,
  dueMonths: number,
  quantity: number
): PricingResult {
  let basePrice = product.pricePerUnit;
  if (product.currency === 'USD') {
    basePrice *= campaign.exchangeRateProducts;
  }

  const interestMultiplier = product.priceType === 'vista' && dueMonths > 0
    ? Math.pow(1 + campaign.interestRate / 100, dueMonths) - 1
    : 0;

  const margin = campaign.margins.find(m => m.segment === targetSegment);
  const marginPercent = (!product.includesMargin && margin) ? margin.marginPercent / 100 : 0;

  const priceWithInterest = basePrice * (1 + interestMultiplier);
  const normalizedPrice = priceWithInterest * (1 + marginPercent);

  return {
    productId: product.id,
    basePrice,
    normalizedPrice,
    interestComponent: basePrice * interestMultiplier,
    marginComponent: priceWithInterest * marginPercent,
    commercialPrice: normalizedPrice,
    quantity,
    subtotal: normalizedPrice * quantity,
  };
}

function normalizeRef(ref: string): string {
  return (ref || '').toUpperCase().trim();
}

/**
 * Compute the monetary value of combo discounts.
 *
 * IMPORTANT: Discounts are applied only to eligible lines (by REF).
 * - Main combos: for each REF, use the highest main discount that includes it.
 * - Complementary combos: additive, but capped proportionally by hectares.
 */
function calculateComboDiscountValue(
  pricingResults: PricingResult[],
  selections: AgronomicSelection[],
  comboActivations: ComboActivation[]
): number {
  if (pricingResults.length === 0 || selections.length === 0 || comboActivations.length === 0) return 0;

  const selectionByProductId = new Map<string, AgronomicSelection>();
  const selectionByRef = new Map<string, AgronomicSelection>();

  for (const s of selections) {
    selectionByProductId.set(s.productId, s);
    const r = normalizeRef(s.ref || s.product?.ref || '');
    if (r && !selectionByRef.has(r)) selectionByRef.set(r, s);
  }

  // Best main discount per REF
  const bestMainByRef = new Map<string, { percent: number; activatedHa: number }>();

  for (const act of comboActivations.filter(a => a.applied && !a.isComplementary)) {
    const matchedRefs = (act.matchedProducts || []).map(normalizeRef).filter(Boolean);
    if (matchedRefs.length === 0) continue;

    // Activated hectares = min area among the matched products
    const activatedHa = Math.min(
      ...matchedRefs.map(r => selectionByRef.get(r)?.areaHectares ?? Number.POSITIVE_INFINITY)
    );
    const safeActivatedHa = Number.isFinite(activatedHa) ? activatedHa : 0;

    for (const ref of matchedRefs) {
      const current = bestMainByRef.get(ref);
      if (!current || act.discountPercent > current.percent) {
        bestMainByRef.set(ref, { percent: act.discountPercent, activatedHa: safeActivatedHa });
      }
    }
  }

  let total = 0;

  for (const line of pricingResults) {
    const sel = selectionByProductId.get(line.productId);
    const ref = normalizeRef(sel?.ref || sel?.product?.ref || '');
    if (!ref) continue;

    const lineSubtotal = line.subtotal;
    const area = sel?.areaHectares || 0;

    // Main discount (at most one main discount per REF)
    const main = bestMainByRef.get(ref);
    if (main && main.percent > 0) {
      const fraction = area > 0 && main.activatedHa > 0
        ? Math.min(1, main.activatedHa / area)
        : 1;
      total += lineSubtotal * (main.percent / 100) * fraction;
    }

    // Complementary discounts (additive)
    for (const comp of comboActivations.filter(a => a.applied && a.isComplementary)) {
      const matched = (comp.matchedProducts || []).map(normalizeRef);
      if (!matched.includes(ref)) continue;

      const capHa = comp.proportionalHectares || 0;
      const fraction = area > 0 && capHa > 0 ? Math.min(1, capHa / area) : 1;
      total += lineSubtotal * (comp.discountPercent / 100) * fraction;
    }
  }

  return total;
}

/**
 * Calculate Gross-to-Net analysis.
 *
 * Discount semantics (fixed):
 * - Main + complementary combo discounts are applied only to eligible product lines.
 * - Barter discount (internal) is applied AFTER combos, on the remaining gross.
 */
export function calculateGrossToNet(
  pricingResults: PricingResult[],
  selections: AgronomicSelection[],
  comboActivations: ComboActivation[],
  barterDiscountPercent: number = 0
): GrossToNet {
  const grossRevenue = pricingResults.reduce((sum, p) => sum + p.subtotal, 0);
  const totalInterest = pricingResults.reduce((sum, p) => sum + p.interestComponent * p.quantity, 0);
  const totalMargin = pricingResults.reduce((sum, p) => sum + p.marginComponent * p.quantity, 0);

  const comboDiscount = calculateComboDiscountValue(pricingResults, selections, comboActivations);
  const barterDiscount = (grossRevenue - comboDiscount) * (barterDiscountPercent / 100);
  const netRevenue = grossRevenue - comboDiscount - barterDiscount;

  return {
    grossRevenue,
    comboDiscount,
    barterDiscount,
    netRevenue,
    financialRevenue: totalInterest,
    distributorMargin: totalMargin,
    barterCost: barterDiscount,
    // Net net excludes distributor margin (kept as separate KPI)
    netNetRevenue: netRevenue - totalMargin,
  };
}
