import type { ComboDefinition, ComboActivation, AgronomicSelection } from '@/types/barter';

/**
 * COMBO CASCADE ENGINE v2 (refactored)
 *
 * Key rules:
 * 1) Combos match by REF ("Nome Mãe"), not by individual product presentation.
 * 2) Main combos are processed in cascade ("represa"):
 *    - Highest discount first, then broader combos
 *    - If a main combo fully activates, its REFs are consumed
 *    - If NOT fully activated, nothing is consumed
 * 3) Complementary combos:
 *    - Do not consume the main pool
 *    - Only become eligible if at least one main combo was activated
 *    - Their discount should be applied proportionally to the activated offer hectares
 */

function normalizeRef(ref: string): string {
  return (ref || '').toUpperCase().trim();
}

/**
 * Resolve the effective REF for a selection.
 */
function getSelectionRef(sel: AgronomicSelection): string {
  return normalizeRef(sel.ref || sel.product?.ref || '');
}

function isComplementaryCombo(combo: ComboDefinition): boolean {
  return combo.isComplementary || /^COMPLEMENTAR/i.test(combo.name);
}

/**
 * Return the tightest (min..max) dose range found for a given REF across all combos.
 * Tightest = smallest interval width. Ties prefer higher discount.
 */
export function getDoseRangeForRef(
  combos: ComboDefinition[],
  ref: string
): { minDosePerHa: number; maxDosePerHa: number; comboId: string; comboName: string } | null {
  const r = normalizeRef(ref);
  if (!r) return null;

  let best: { minDosePerHa: number; maxDosePerHa: number; comboId: string; comboName: string; width: number; discount: number } | null = null;

  for (const combo of combos) {
    for (const rule of combo.products) {
      const ruleRef = normalizeRef(rule.ref);
      if (ruleRef !== r) continue;

      const minDosePerHa = Number(rule.minDosePerHa);
      const maxDosePerHa = Number(rule.maxDosePerHa);
      if (!Number.isFinite(minDosePerHa) || !Number.isFinite(maxDosePerHa) || maxDosePerHa < minDosePerHa) continue;

      const width = maxDosePerHa - minDosePerHa;
      const discount = Number(combo.discountPercent) || 0;

      if (!best) {
        best = { minDosePerHa, maxDosePerHa, comboId: combo.id, comboName: combo.name, width, discount };
        continue;
      }

      if (width < best.width) {
        best = { minDosePerHa, maxDosePerHa, comboId: combo.id, comboName: combo.name, width, discount };
      } else if (width === best.width && discount > best.discount) {
        best = { minDosePerHa, maxDosePerHa, comboId: combo.id, comboName: combo.name, width, discount };
      }
    }
  }

  return best ? { minDosePerHa: best.minDosePerHa, maxDosePerHa: best.maxDosePerHa, comboId: best.comboId, comboName: best.comboName } : null;
}

/**
 * Suggested dose = midpoint of the tightest dose range.
 */
export function getSuggestedDoseForRef(combos: ComboDefinition[], ref: string): number | null {
  const range = getDoseRangeForRef(combos, ref);
  if (!range) return null;
  return (range.minDosePerHa + range.maxDosePerHa) / 2;
}

/**
 * Find the best selection for a given REF, respecting the available pool.
 *
 * If multiple selections share the same REF, we choose the one with highest dose,
 * and break ties by larger area.
 */
function findBestSelectionByRef(
  ref: string,
  selections: AgronomicSelection[],
  availableRefs: Set<string>,
  doseRange?: { min: number; max: number }
): AgronomicSelection | undefined {
  const r = normalizeRef(ref);
  if (!r || !availableRefs.has(r)) return undefined;

  const matches = selections.filter(s => getSelectionRef(s) === r);
  const inRange = doseRange
    ? matches.filter(s => s.dosePerHectare >= doseRange.min && s.dosePerHectare <= doseRange.max)
    : matches;

  const pool = inRange.length > 0 ? inRange : matches;
  if (pool.length === 0) return undefined;

  return [...pool].sort((a, b) => {
    if (b.dosePerHectare !== a.dosePerHectare) return b.dosePerHectare - a.dosePerHectare;
    return (b.areaHectares || 0) - (a.areaHectares || 0);
  })[0];
}

export function applyComboCascade(combos: ComboDefinition[], selections: AgronomicSelection[]): ComboActivation[] {
  const mainCombos = combos.filter(c => !isComplementaryCombo(c));
  const complementaryCombos = combos.filter(c => isComplementaryCombo(c));

  const sortedMain = [...mainCombos].sort((a, b) => {
    if (b.discountPercent !== a.discountPercent) return b.discountPercent - a.discountPercent;
    return b.products.length - a.products.length;
  });

  const availableRefs = new Set<string>();
  for (const sel of selections) {
    const ref = getSelectionRef(sel);
    if (ref) availableRefs.add(ref);
  }

  const activations: ComboActivation[] = [];
  let activatedOfferHectares = 0; // used as cap for complementary combos

  for (const combo of sortedMain) {
    const matchedRefs: string[] = [];
    const matchedSelections: AgronomicSelection[] = [];
    let allMatch = true;

    for (const rule of combo.products) {
      const ruleRef = normalizeRef(rule.ref);
      if (!ruleRef) {
        allMatch = false;
        break;
      }

      const sel = findBestSelectionByRef(ruleRef, selections, availableRefs, {
        min: rule.minDosePerHa,
        max: rule.maxDosePerHa,
      });

      if (!sel) {
        allMatch = false;
        break;
      }

      // Guarantee dose is within range
      const doseInRange = sel.dosePerHectare >= rule.minDosePerHa && sel.dosePerHectare <= rule.maxDosePerHa;
      if (!doseInRange) {
        allMatch = false;
        break;
      }

      matchedRefs.push(ruleRef);
      matchedSelections.push(sel);
    }

    if (allMatch && matchedRefs.length > 0) {
      matchedRefs.forEach(r => availableRefs.delete(r));

      // Activated hectares = intersection among required products
      const activatedHa = matchedSelections.length > 0
        ? Math.min(...matchedSelections.map(s => s.areaHectares || 0))
        : 0;
      activatedOfferHectares = Math.max(activatedOfferHectares, activatedHa);

      activations.push({
        comboId: combo.id,
        comboName: combo.name,
        discountPercent: combo.discountPercent,
        matchedProducts: matchedRefs,
        applied: true,
        isComplementary: false,
        activatedHectares: activatedHa,
      });
    } else {
      activations.push({
        comboId: combo.id,
        comboName: combo.name,
        discountPercent: combo.discountPercent,
        matchedProducts: [],
        applied: false,
        isComplementary: false,
      });
    }
  }

  const hasActivatedOffers = activations.some(a => a.applied && !a.isComplementary);

  for (const combo of complementaryCombos) {
    if (!hasActivatedOffers) {
      activations.push({
        comboId: combo.id,
        comboName: combo.name,
        discountPercent: combo.discountPercent,
        matchedProducts: [],
        applied: false,
        isComplementary: true,
      });
      continue;
    }

    const matchedRefs: string[] = [];

    for (const rule of combo.products) {
      const ruleRef = normalizeRef(rule.ref);
      if (!ruleRef) continue;

      const sel = selections.find(s => getSelectionRef(s) === ruleRef);
      if (!sel) continue;

      const doseInRange = sel.dosePerHectare >= rule.minDosePerHa && sel.dosePerHectare <= rule.maxDosePerHa;
      if (doseInRange) matchedRefs.push(ruleRef);
    }

    const activated = matchedRefs.length > 0;

    activations.push({
      comboId: combo.id,
      comboName: combo.name,
      discountPercent: combo.discountPercent,
      matchedProducts: matchedRefs,
      applied: activated,
      isComplementary: true,
      proportionalHectares: activated ? activatedOfferHectares : undefined,
    });
  }

  return activations;
}

/**
 * Max possible discount (highest single main combo)
 */
export function getMaxPossibleDiscount(combos: ComboDefinition[]): number {
  const mainCombos = combos.filter(c => !c.isComplementary && !/^COMPLEMENTAR/i.test(c.name));
  if (mainCombos.length === 0) return 0;
  return Math.max(...mainCombos.map(c => c.discountPercent));
}

/**
 * Current activated main discount (highest activated main combo)
 */
export function getActivatedDiscount(activations: ComboActivation[]): number {
  const activatedMain = activations.filter(a => a.applied && !a.isComplementary);
  if (activatedMain.length === 0) return 0;
  return Math.max(...activatedMain.map(a => a.discountPercent));
}

/**
 * Sum of activated complementary discounts (these are additive by design)
 */
export function getComplementaryDiscount(activations: ComboActivation[]): number {
  return activations
    .filter(a => a.applied && a.isComplementary)
    .reduce((sum, a) => sum + a.discountPercent, 0);
}
