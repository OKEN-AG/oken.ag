import type { Product, AgronomicSelection } from '@/types/barter';

/**
 * AGRONOMIC ENGINE
 * Calculates volumes based on area × dose and rounds to full boxes.
 *
 * Notes:
 * - We try all allowed package sizes and choose the one that minimizes waste
 *   (roundedQuantity - rawQuantity). Ties are broken by fewer boxes/pallets.
 * - We never mutate product.packageSizes.
 */

function clampDose(product: Product, dose: number): number {
  const min = Number.isFinite(product.minDose) ? product.minDose : dose;
  const max = Number.isFinite(product.maxDose) ? product.maxDose : dose;
  if (Number.isFinite(min) && Number.isFinite(max) && max >= min) {
    return Math.min(Math.max(dose, min), max);
  }
  return dose;
}

function safePositive(n: number, fallback = 0): number {
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

export function calculateAgronomicSelection(
  product: Product,
  areaHectares: number,
  dosePerHectare?: number
): AgronomicSelection {
  const area = safePositive(areaHectares, 0);
  const baseDose = Number.isFinite(dosePerHectare as number)
    ? (dosePerHectare as number)
    : product.dosePerHectare;

  const dose = clampDose(product, safePositive(baseDose, 0));
  const rawQuantity = area * dose;

  const packageSizes = (product.packageSizes && product.packageSizes.length > 0)
    ? [...product.packageSizes]
    : [1];

  const unitsPerBoxBase = safePositive(product.unitsPerBox, 0);
  const boxesPerPallet = safePositive(product.boxesPerPallet, 1);

  // If we can't compute logistics, return a sane zeroed selection
  if (unitsPerBoxBase <= 0 || rawQuantity <= 0) {
    return {
      productId: product.id,
      ref: product.ref || '',
      product,
      areaHectares: area,
      dosePerHectare: dose,
      rawQuantity,
      roundedQuantity: 0,
      boxes: 0,
      pallets: 0,
    };
  }

  type Candidate = { size: number; unitsPerBox: number; boxes: number; pallets: number; waste: number };
  const candidates: Candidate[] = packageSizes
    .map(size => safePositive(size, 0))
    .filter(size => size > 0)
    .map(size => {
      const unitsPerBox = unitsPerBoxBase * size;
      const boxes = unitsPerBox > 0 ? Math.ceil(rawQuantity / unitsPerBox) : 0;
      const roundedQuantity = boxes * unitsPerBox;
      const waste = Math.max(roundedQuantity - rawQuantity, 0);
      const pallets = boxesPerPallet > 0 ? Math.ceil(boxes / boxesPerPallet) : 0;
      return { size, unitsPerBox, boxes, pallets, waste };
    });

  const best = (candidates.length > 0 ? candidates : [{
    size: 1,
    unitsPerBox: unitsPerBoxBase,
    boxes: Math.ceil(rawQuantity / unitsPerBoxBase),
    pallets: Math.ceil(Math.ceil(rawQuantity / unitsPerBoxBase) / boxesPerPallet),
    waste: 0,
  }]).sort((a, b) => {
    if (a.waste !== b.waste) return a.waste - b.waste;
    if (a.boxes !== b.boxes) return a.boxes - b.boxes;
    if (a.pallets !== b.pallets) return a.pallets - b.pallets;
    // Prefer larger packages if everything else is equal
    return b.size - a.size;
  })[0];

  const boxes = best.boxes;
  const roundedQuantity = boxes * best.unitsPerBox;
  const pallets = best.pallets;

  return {
    productId: product.id,
    ref: product.ref || '',
    product,
    areaHectares: area,
    dosePerHectare: dose,
    rawQuantity,
    roundedQuantity,
    boxes,
    pallets,
  };
}

/**
 * Consolidate total treated area from selections.
 *
 * In most barter scenarios, products are applied on the same cultivated area.
 * We therefore use the maximum area among selections as the effective treated area.
 */
export function consolidateArea(selections: AgronomicSelection[]): number {
  if (selections.length === 0) return 0;
  return Math.max(...selections.map(s => s.areaHectares || 0));
}
