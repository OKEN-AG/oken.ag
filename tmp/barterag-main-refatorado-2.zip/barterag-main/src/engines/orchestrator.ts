import type { WagonStage, JourneyModule, DocumentType, OperationStatus } from '@/types/barter';

/**
 * ORCHESTRATOR ENGINE (refactored)
 *
 * Goal:
 * - Build a deterministic "train track" of stages (wagons)
 * - Gate progression by document completion
 * - Provide nextStatus and blocking reason
 */

const statusOrder: OperationStatus[] = [
  'simulacao',
  'pedido',
  'formalizado',
  'garantido',
  'faturado',
  'monitorando',
  'liquidado',
];

const DOC_LABEL: Record<DocumentType, string> = {
  termo_adesao: 'Termo de Adesão',
  pedido: 'Pedido',
  termo_barter: 'Termo de Barter',
  ccv: 'CCV',
  cessao_credito: 'Cessão de Crédito',
  cpr: 'CPR',
  duplicata: 'Duplicata',
  nota_comercial: 'Nota Comercial',
  certificado_aceite: 'Certificado de Aceite',
};

type StageDefinition = {
  module: JourneyModule;
  name: string;
  requiredDocuments: DocumentType[];
  requiredStatus: OperationStatus;
  nextStatus: OperationStatus;
};

// Current journey supports these 5 core modules
const STAGE_DEFINITIONS: StageDefinition[] = [
  {
    module: 'adesao',
    name: 'Adesão',
    requiredDocuments: ['termo_adesao'],
    requiredStatus: 'simulacao',
    nextStatus: 'pedido',
  },
  {
    module: 'simulacao',
    name: 'Simulação / Pedido',
    requiredDocuments: ['pedido'],
    requiredStatus: 'pedido',
    nextStatus: 'formalizado',
  },
  {
    module: 'formalizacao',
    name: 'Formalização',
    requiredDocuments: ['termo_barter'],
    requiredStatus: 'formalizado',
    // This stage is inside "formalizado"; status transition happens after documents stage.
    nextStatus: 'formalizado',
  },
  {
    module: 'documentos',
    name: 'Documentos',
    requiredDocuments: ['ccv', 'cessao_credito'],
    requiredStatus: 'formalizado',
    nextStatus: 'garantido',
  },
  {
    module: 'garantias',
    name: 'Garantias',
    requiredDocuments: ['cpr'],
    requiredStatus: 'garantido',
    nextStatus: 'faturado',
  },
];

function isDocCompleted(status: string | null | undefined): boolean {
  return status === 'validado' || status === 'assinado';
}

export function buildWagonStages(
  activeModules: JourneyModule[],
  currentStatus: OperationStatus,
  existingDocuments: Array<{ doc_type: DocumentType; status: string }>
): WagonStage[] {
  const defs = STAGE_DEFINITIONS.filter(d => activeModules.includes(d.module));

  const docsByType = new Map<DocumentType, string>();
  for (const d of existingDocuments) {
    docsByType.set(d.doc_type, d.status);
  }

  const currentIdx = statusOrder.indexOf(currentStatus);

  const stages: WagonStage[] = [];

  for (const def of defs) {
    const stageStatusIdx = statusOrder.indexOf(def.requiredStatus);
    const requiredDocuments = def.requiredDocuments;

    const completedDocuments = requiredDocuments.filter(dt => isDocCompleted(docsByType.get(dt)));
    const allDocsComplete = completedDocuments.length === requiredDocuments.length;

    const prevStage = stages[stages.length - 1];
    const prevComplete = !prevStage || prevStage.status === 'concluido';

    let status: WagonStage['status'];

    if (currentIdx > stageStatusIdx) {
      // We already moved beyond the status that hosts this stage
      status = 'concluido';
    } else if (currentIdx < stageStatusIdx) {
      // Future stage: pending unless blocked by previous stage
      status = prevComplete ? 'pendente' : 'bloqueado';
    } else {
      // Current status stage
      if (!prevComplete) {
        status = 'bloqueado';
      } else {
        status = allDocsComplete ? 'concluido' : 'em_progresso';
      }
    }

    stages.push({
      id: def.module,
      module: def.module,
      name: def.name,
      requiredDocuments,
      completedDocuments,
      status,
      // We only set completedAt if we have real timestamps; not available here.
      completedAt: undefined,
      blockingReason: status === 'bloqueado' ? 'Aguardando etapa anterior' : undefined,
    });
  }

  return stages;
}

/**
 * Determine if the operation can advance to the next status.
 */
export function canAdvance(
  activeModules: JourneyModule[],
  currentStatus: OperationStatus,
  existingDocuments: Array<{ doc_type: DocumentType; status: string }>
): OperationStatus | null {
  const defs = STAGE_DEFINITIONS.filter(d => activeModules.includes(d.module));
  const stages = buildWagonStages(activeModules, currentStatus, existingDocuments);

  const currentIdx = statusOrder.indexOf(currentStatus);
  if (currentIdx < 0 || currentIdx >= statusOrder.length - 1) return null;

  const defsAtCurrent = defs.filter(d => d.requiredStatus === currentStatus);
  const stagesAtCurrent = stages.filter(s => {
    const def = defs.find(d => d.module === s.module);
    return def?.requiredStatus === currentStatus;
  });

  if (stagesAtCurrent.length > 0) {
    const allComplete = stagesAtCurrent.every(s => s.status === 'concluido');
    if (!allComplete) return null;

    // Use the last stage at this status to decide the transition
    const lastDef = defsAtCurrent[defsAtCurrent.length - 1];
    if (lastDef && lastDef.nextStatus && lastDef.nextStatus !== currentStatus) {
      return lastDef.nextStatus;
    }

    // If there is no explicit transition (or it is the same status), fallback to linear order
    return statusOrder[currentIdx + 1] ?? null;
  }

  // No gates for this status (module disabled) → allow linear progression
  return statusOrder[currentIdx + 1] ?? null;
}

/**
 * Provide a user-friendly reason why we cannot advance.
 */
export function getBlockingReason(
  activeModules: JourneyModule[],
  currentStatus: OperationStatus,
  existingDocuments: Array<{ doc_type: DocumentType; status: string }>
): string | null {
  const stages = buildWagonStages(activeModules, currentStatus, existingDocuments);

  const firstNotDone = stages.find(s => s.status !== 'concluido');
  if (!firstNotDone) return null;

  if (firstNotDone.status === 'bloqueado') {
    return `Etapa "${firstNotDone.name}" bloqueada: conclua a etapa anterior.`;
  }

  if (firstNotDone.status === 'em_progresso') {
    const missing = firstNotDone.requiredDocuments
      .filter(d => !firstNotDone.completedDocuments.includes(d))
      .map(d => DOC_LABEL[d] || d);

    if (missing.length === 0) return null;
    return `Documentos pendentes em "${firstNotDone.name}": ${missing.join(', ')}`;
  }

  return null;
}
